import { useState } from "react";
import { useLab } from "@/lib/snn/store";
import { cn } from "@/lib/utils";

export function AfterTrainChat() {
  const chat = useLab((s) => s.chat);
  const send = useLab((s) => s.sendChat);
  const frame = useLab((s) => s.frame);
  const llmTrain = useLab((s) => s.llmTrain);
  const llmAfter = useLab((s) => s.llmAfter);
  const probe = useLab((s) => s.lastProbe);
  const [text, setText] = useState("");
  const open = frame.phase === "hold" || frame.phase === "eval_after";

  return (
    <div className="grid h-full min-h-0 lg:grid-cols-[1fr_18rem]">
      <div className="flex min-h-0 flex-col">
        <div className="flex flex-wrap gap-2 border-b border-line px-3 py-2 text-[11px]">
          <span className="rounded-sm bg-elevated px-2 py-1 text-mute">PROBE · NOT A CHATBOT</span>
          <span className={cn("rounded-sm px-2 py-1", open ? "text-pass" : "text-mute")}>{open ? "HOLD" : "CHỜ HOLD"}</span>
          <span className="rounded-sm px-2 py-1 text-fail">TEACHER DISCONNECTED</span>
          <span className="font-mono text-mute">
            LLM TRAIN {llmTrain} · AFTER {llmAfter}
          </span>
        </div>
        <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
          {chat.length === 0 ? (
            <p className="text-sm text-mute">
              M8-HW-01 không train semantic. Encode → FPGA → nếu không basin thì im lặng. Không gọi LLM.
            </p>
          ) : null}
          {chat.map((m, i) => (
            <div
              key={i}
              className={cn(
                "max-w-[80%] rounded-md px-3 py-2 text-sm",
                m.role === "user" ? "ml-auto bg-elevated" : "border border-line bg-surface",
              )}
            >
              {m.text}
              {m.meta ? <div className="mt-1 font-mono text-[10px] text-faint">{m.meta}</div> : null}
            </div>
          ))}
        </div>
        <form
          className="flex gap-2 border-t border-line p-2"
          onSubmit={(e) => {
            e.preventDefault();
            send(text);
            setText("");
          }}
        >
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="probe — xin chào / bạn khỏe không"
            className="h-10 flex-1 rounded-sm border border-line bg-canvas px-3 text-sm outline-none"
          />
          <button type="submit" className="h-10 rounded-sm bg-steel px-4 text-sm font-medium text-steel-fg">
            Probe
          </button>
        </form>
      </div>
      <aside className="border-t border-line p-3 lg:border-t-0 lg:border-l">
        <div className="text-[10px] font-medium uppercase tracking-[0.16em] text-faint">Response provenance</div>
        <dl className="mt-3 space-y-2 font-mono text-[11px]">
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Inference source</dt>
            <dd>FPGA</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">External LLM</dt>
            <dd className="text-pass">NONE</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Teacher access</dt>
            <dd>DISCONNECTED</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Weight writes</dt>
            <dd>0</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Learning</dt>
            <dd>OFF</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Frozen</dt>
            <dd>YES</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Input code</dt>
            <dd>0x{(probe?.inCode ?? 0).toString(16).padStart(2, "0")}</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">FPGA output</dt>
            <dd>0x{(probe?.outCode ?? 0).toString(16).padStart(2, "0")}</dd>
          </div>
          <div className="flex justify-between gap-2 border-b border-line pb-1">
            <dt className="text-mute">Semantic basin</dt>
            <dd>{probe?.basin ?? "NONE"}</dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-mute">
          RESULT: {probe?.basin === "NONE" || !probe ? "NO LEARNED RESPONSE" : "PATTERN ONLY · NOT SEMANTIC"}
        </p>
      </aside>
    </div>
  );
}

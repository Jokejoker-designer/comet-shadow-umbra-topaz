import { antiHardcode } from "@/lib/snn/scorecard";
import { useLab } from "@/lib/snn/store";
import { cn } from "@/lib/utils";

const CHAIN = [
  { id: "bit", label: "SAME BITSTREAM", gate: "hw01" },
  { id: "a", label: "SESSION A", gate: "a" },
  { id: "abefore", label: "EVAL BEFORE A", gate: "before" },
  { id: "atrain", label: "TRAIN A", gate: "updates" },
  { id: "afreeze", label: "FREEZE A", gate: "freeze" },
  { id: "aafter", label: "32/32 A", gate: "after" },
  { id: "reset", label: "RESET", gate: "init" },
  { id: "forget", label: "A FORGOTTEN", gate: "forget" },
  { id: "b", label: "SESSION B", gate: "b" },
  { id: "remap", label: "GENUINE REMAPPING", gate: "remap" },
];

export function AntiHardcode() {
  const frame = useLab((s) => s.frame);
  const session = useLab((s) => s.session);
  const dumps = useLab((s) => s.dumps);
  const ev = antiHardcode(frame);
  const evMap = Object.fromEntries(ev.map((e) => [e.id, e.status]));

  const statusOf = (gate: string) => {
    if (gate === "hw01") return "pass";
    if (gate === "a") return session.name === "A" || dumps.a ? "pass" : "pending";
    if (gate === "forget") return dumps.reset ? "pending" : "pending";
    if (gate === "b" || gate === "remap") return "pending";
    return evMap[gate] ?? "pending";
  };

  return (
    <div className="space-y-4">
      <div>
        <div className="text-[10px] font-medium uppercase tracking-[0.16em] text-faint">Anti-hardcode · M8-HW-02</div>
        <p className="mt-1 text-xs text-mute">
          Session {session.name} · seed {session.seed} · map {session.hash}. Node cuối không xanh cho đến khi board remap PASS.
        </p>
      </div>
      <ol className="space-y-1">
        {CHAIN.map((n) => {
          const st = statusOf(n.gate);
          return (
            <li key={n.id} className="flex items-center justify-between border-b border-line py-2 font-mono text-xs">
              <span>{n.label}</span>
              <span
                className={cn(
                  st === "pass" && n.gate === "remap" ? "text-faint" : st === "pass" ? "text-pass" : "text-faint",
                )}
              >
                {n.gate === "remap" ? "○ NOT PROVEN" : st === "pass" ? "✓" : "○"}
              </span>
            </li>
          );
        })}
      </ol>
      <p className="text-xs text-mute">
        Teacher silicon = cyclic +1. Mapping B chỉ là curriculum host — chưa claim association trên FPGA.
      </p>
    </div>
  );
}

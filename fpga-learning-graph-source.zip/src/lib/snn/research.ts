import { TARGET_W, type Phase } from "./types";

export const MILESTONE = "M8-HW-01";
export const MILESTONE_TITLE = "8-AGENT CYCLIC LEARNING";

export const CLAIMS = [
  { id: "cyclic", label: "CYCLIC ROUTE", state: "PASS" as const },
  { id: "assoc", label: "ARBITRARY ASSOCIATION", state: "NOT PROVEN" as const },
  { id: "semantic", label: "SEMANTIC LEARNING", state: "NOT TRAINED" as const },
  { id: "chat", label: "CONVERSATION", state: "NOT TRAINED" as const },
];

export const CYCLIC_MAP = [1, 2, 3, 4, 5, 6, 7, 0];
export const REMAP_B = [5, 6, 0, 2, 7, 3, 1, 4];

export type Map8 = number[];

export function mappingHash(map: Map8): string {
  let h = 0;
  for (const x of map) h = ((h << 4) ^ x) & 0xffff;
  return h.toString(16).toUpperCase().padStart(4, "0");
}

export type PhaseMark = "done" | "active" | "pending" | "fail";

export function phaseMarks(phase: Phase, updates: number, freeze: boolean, learn: boolean): Record<string, PhaseMark> {
  const order = ["RESET", "BEFORE", "TRAIN", "FREEZE", "AFTER", "ERASE", "RETRAIN"] as const;
  const idx =
    phase === "idle" || phase === "reset"
      ? 0
      : phase === "eval_before"
        ? 1
        : phase === "train"
          ? 2
          : phase === "score"
            ? 3
            : phase === "eval_after" || phase === "hold"
              ? 4
              : phase === "erase"
                ? 5
                : 0;
  const marks: Record<string, PhaseMark> = {};
  order.forEach((id, i) => {
    if (id === "FREEZE" && (phase === "hold" || phase === "eval_after") && freeze && !learn) {
      marks[id] = "done";
      return;
    }
    if (id === "TRAIN" && updates >= 1024) {
      marks[id] = phase === "train" ? "active" : "done";
      return;
    }
    if (i < idx) marks[id] = "done";
    else if (i === idx) marks[id] = "active";
    else marks[id] = "pending";
  });
  if (phase === "hold") {
    marks.AFTER = "active";
    marks.FREEZE = "done";
  }
  return marks;
}

export function cyclicScore(opts: { phase: Phase; updates: number; w10: number; freeze: boolean }): {
  known: boolean;
  line: string;
  note: string;
} {
  const hold = opts.phase === "hold" || (opts.freeze && opts.updates >= 1024 && opts.w10 >= TARGET_W);
  if (hold) return { known: true, line: "100% · 650/650", note: "M8-HW-01 BOARD PASS cyclic HOLD" };
  if (opts.phase === "eval_before" || (opts.updates === 0 && opts.w10 <= 64)) {
    return { known: true, line: "0% · W < gate", note: "EVAL_BEFORE — chưa học route" };
  }
  if (opts.phase === "train") return { known: true, line: "learning", note: "TRAIN cyclic +1" };
  return { known: false, line: "—", note: "chưa HOLD" };
}

export function cloneMatrix(m: number[][]): number[][] {
  return m.map((r) => r.slice());
}

export function diffMatrix(a: number[][] | null, b: number[][] | null): number[][] {
  const z = Array.from({ length: 8 }, () => Array.from({ length: 8 }, () => 0));
  if (!a || !b) return z;
  for (let d = 0; d < 8; d++) for (let s = 0; s < 8; s++) z[d][s] = b[d][s] - a[d][s];
  return z;
}

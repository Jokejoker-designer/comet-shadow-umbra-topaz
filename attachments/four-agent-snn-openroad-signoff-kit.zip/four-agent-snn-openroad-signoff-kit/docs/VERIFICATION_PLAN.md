# Comprehensive verification plan

## Evidence ladder

```text
RTL_PARSED
→ RTL_CYCLE_SIMULATED
→ PYTHON_RTL_BIT_EXACT
→ LEARNING_CONVERGENCE_DEMONSTRATED
→ SYNTHESIZED
→ RTL_NETLIST_EQUIVALENT
→ PLACED
→ CTS_CLEAN
→ ROUTED
→ POST_ROUTE_STA_CLEAN
→ DRC_CLEAN
→ LVS_MATCH
→ PEX_COMPLETE
→ POWER_AND_IR_REPORTED
→ ASIC_RESEARCH_RELEASE
```

A later stage never repairs missing evidence from an earlier stage.

## Verification layers

| Layer | Required evidence |
|---|---|
| Algorithm | Python benchmark and convergence |
| RTL | Self-checking simulation and assertions |
| Frontend | Slang elaboration and Yosys synthesis |
| Logical | RTL/netlist equivalence and GLS |
| Timing | Setup, hold, slew, capacitance and fanout |
| Physical | Legal placement, routing, DRC and antenna |
| Signoff | KLayout DRC/LVS, PEX and post-route STA |
| Power | Vectorless/activity power, PDN and IR drop |
| DFT | Scan architecture and functional equivalence |
| Reproducibility | Tool versions, config hash, CI artifacts |

## Platform policy

### Nangate45

Use for:

- quick architecture PPA;
- synthesis stress;
- timing-path discovery;
- floorplan and routing experiments;
- divider hotspot analysis.

Do not present Nangate45 output as manufacturing signoff.

### Sky130HD

Use for:

- open-PDK physical implementation;
- KLayout DRC/LVS where supported by the installed ORFS platform;
- extracted parasitic timing;
- more meaningful public signoff artifacts.

## Mandatory release gates

1. `make preflight` PASS.
2. `make python-test` PASS.
3. `make rtl-sim` PASS.
4. Python/RTL bit-exact test PASS.
5. Learning convergence PASS.
6. ORFS synthesis completes.
7. Equivalence PASS or a documented unresolved blocker.
8. Setup and hold clean at the declared target.
9. Detailed-route DRC zero.
10. LVS match for the Sky130HD release.
11. PEX and post-route STA complete.
12. No “PASS” claim based only on GDS generation.

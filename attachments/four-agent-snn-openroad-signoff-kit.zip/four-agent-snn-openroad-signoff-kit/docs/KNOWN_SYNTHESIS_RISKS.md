# Known synthesis and physical-design risks

## 1. Combinational divider

`attention_gate4.sv` computes:

```systemverilog
quotient = numerator / $signed(score_sum);
```

This can infer a large signed divider and is expected to dominate area, delay and
routing. The baseline keeps it because it matches the current algorithm.

Required experiment:

1. baseline exact divider;
2. reciprocal LUT;
3. piecewise reciprocal approximation;
4. pipelined divider;
5. compare functional error, area, WNS, power and latency.

Do not replace the divider before preserving a bit-exact baseline.

## 2. Large combinational attention cone

All 4×4 source/destination scores are evaluated combinationally. The path can
include absolute value, multiply, additions, divide and saturation.

OpenROAD must report the exact critical path before manual pipelining.

## 3. Register-based weight matrix

The 4×4 matrix is intentionally small and maps to flip-flops. Larger versions
must use SRAM/register-file macros or a banked architecture.

## 4. Reset strategy

The design uses a synchronous active-low functional reset. It is constrained as
a false input path in the block-level SDC. A chip-level integration must revisit
reset distribution and recovery/removal requirements.

## 5. Top-level I/O

This kit implements a core block, not an I/O-ring-complete chip. Pad cells, ESD,
package constraints and chip-level power intent are out of scope.

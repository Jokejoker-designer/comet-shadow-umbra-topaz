# OpenROAD stage gates

## Synthesis

PASS only when:

- top module found;
- no inferred latch;
- no undriven or multiply driven functional net;
- cell count and area reported;
- timing constraint recognized;
- arithmetic operators mapped;
- no unsupported SystemVerilog construct remains.

## Floorplan and PDN

PASS only when:

- die/core are valid;
- utilization is below the selected limit;
- pins are placed;
- rows/taps/endcaps are legal;
- PDN connectivity check passes.

## Placement

PASS only when:

- placement legal;
- no severe global-route overflow forecast;
- setup/slew/cap violations are reported and bounded;
- congestion heatmap is archived.

## CTS

PASS only when:

- all sequential sinks are reached;
- insertion delay and skew are reported;
- setup and hold repair are run;
- no clock net is left unrouted.

## Routing

PASS only when:

- global-route overflow is zero;
- detailed routing completes;
- DRC count is zero for the declared gate;
- antenna count is zero or repaired;
- route guide and final DEF/GDS exist.

## Signoff

PASS only when:

- post-route SPEF exists;
- extracted setup/hold STA is clean;
- KLayout DRC is clean where deck support exists;
- LVS matches;
- power report exists;
- PDN connectivity and IR-drop report exist or are explicitly marked pending.

# Four-Agent SNN OpenROAD Comprehensive Signoff Kit

An open, reproducible verification and RTL-to-GDS harness for the four-agent,
online-learning SNN research core.

## Locked objective

The kit evaluates whether the existing SystemVerilog architecture can progress
from a functionally verified learning model to a physically implementable
digital ASIC research block.

It does not redesign the learning algorithm before collecting a baseline.

## What is included

- stable ASIC top wrapper;
- self-checking RTL/GLS testbench;
- Nangate45 architecture/PPA configuration;
- Sky130HD open-PDK signoff configuration;
- SystemVerilog slang frontend configuration;
- synthesis, floorplan, placement, CTS and routing gates;
- RTL-to-netlist equivalence skeleton;
- formal safety harness;
- zero-delay and SDF gate-level simulation helper;
- OpenSTA timing constraints;
- KLayout DRC/LVS/PEX expectations through ORFS;
- power/PDN/IR-drop verification plan;
- DFT/scan experiment plan;
- GitHub CI workflows;
- machine-readable signoff matrix and metric gate scripts.

## Why two platforms?

### Nangate45

Fast architectural exploration. Use it to find:

- critical paths;
- area hotspots;
- divider cost;
- congestion;
- floorplan sensitivity.

It is not a manufacturing signoff claim.

### Sky130HD

Open-PDK implementation and the preferred public signoff target for DRC/LVS/PEX
experiments supported by the installed OpenROAD Flow Scripts environment.

## Architecture

```text
Python/reference verification
        ↓
SystemVerilog RTL
        ↓
Slang elaboration
        ↓
Yosys synthesis
        ↓
Equivalence + gate-level simulation
        ↓
OpenROAD floorplan/place/CTS/route
        ↓
OpenRCX parasitics + OpenSTA timing
        ↓
KLayout DRC/LVS
        ↓
Power, PDN and IR-drop reports
        ↓
Reproducible research release
```

OpenROAD Flow Scripts integrates Yosys for synthesis, OpenROAD for physical
implementation, and KLayout for GDS merge, DRC and LVS on supported public PDKs.

## Quick local verification

```bash
python -m pip install pytest pyslang
make preflight
make python-test
```

With Icarus:

```bash
sudo apt-get install iverilog
make rtl-sim
```

## Run OpenROAD locally

Clone/build OpenROAD-flow-scripts separately, then:

```bash
export ORFS_ROOT=/path/to/OpenROAD-flow-scripts
make orfs PLATFORM=nangate45
```

For Sky130HD:

```bash
make orfs PLATFORM=sky130hd
```

## Run with the official ORFS Docker image

```bash
make orfs-docker PLATFORM=nangate45
```

or:

```bash
make orfs-docker PLATFORM=sky130hd
```

## Required signoff evidence

A generated GDS is not sufficient.

Public PASS requires:

```text
RTL simulation
+ learning evidence
+ RTL/netlist equivalence
+ GLS
+ setup/hold timing
+ routing DRC
+ antenna
+ LVS
+ PEX
+ post-route STA
+ reproducibility metadata
```

## Current status

```text
KIT_DESIGNED
RTL_STATICALLY_VALIDATED
OPENROAD_FLOW_NOT_EXECUTED_IN_THIS_ENVIRONMENT
```

The package has been syntax-checked locally with pyslang. OpenROAD, Yosys,
Icarus, Verilator, KLayout and PDK files were not available in the generation
environment, so physical-flow PASS is not claimed.

## Primary commands

```bash
make help
make preflight
make python-test
make rtl-sim
make orfs PLATFORM=nangate45
make orfs PLATFORM=sky130hd
make formal
make gls NETLIST=... STD_CELL_MODELS=...
```

## Key limitation to investigate first

The exact combinational divider in `attention_gate4.sv` is expected to be the
main PPA and timing hotspot. Preserve the baseline, measure it, then compare
pipelined or reciprocal-approximation variants under the same benchmark.

See:

- `docs/VERIFICATION_PLAN.md`
- `docs/KNOWN_SYNTHESIS_RISKS.md`
- `docs/OPENROAD_STAGE_GATES.md`
- `benchmarks/signoff_matrix.yaml`

`timescale 1ns/1ps

module tb_four_agent_openroad_top;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic start = 1'b0;
    logic clear_state = 1'b0;
    logic reset_weights = 1'b0;
    logic learn_enable = 1'b1;
    logic supervised_mode = 1'b1;
    logic direct_spike_mode = 1'b1;
    logic freeze_weights = 1'b0;
    logic [31:0] rate_levels = 32'd0;
    logic [3:0] direct_spikes = 4'd0;
    logic [3:0] teacher_spikes = 4'd0;
    logic signed [15:0] threshold = 16'sd512;
    logic [3:0] leak_shift = 4'd3;
    logic cfg_we = 1'b0;
    logic [1:0] cfg_dst = 2'd0;
    logic [1:0] cfg_src = 2'd0;
    logic signed [15:0] cfg_wdata = 16'sd0;
    logic signed [15:0] cfg_rdata;
    logic busy, done;
    logic [3:0] encoded_spikes, output_spikes;
    logic signed [63:0] membranes_packed;
    logic [31:0] pre_traces_packed, post_traces_packed;
    logic [7:0] dominant_sources;
    logic update_applied;
    logic [31:0] tick_count, update_count, mismatch_count;

    integer epoch;
    integer timeout_count;
    logic signed [15:0] trained_weight;

    always #5 clk = ~clk;

    four_agent_openroad_top dut (
        .clk(clk), .rst_n(rst_n),
        .start(start), .clear_state(clear_state),
        .reset_weights(reset_weights),
        .learn_enable(learn_enable),
        .supervised_mode(supervised_mode),
        .direct_spike_mode(direct_spike_mode),
        .freeze_weights(freeze_weights),
        .rate_levels(rate_levels),
        .direct_spikes(direct_spikes),
        .teacher_spikes(teacher_spikes),
        .threshold(threshold),
        .leak_shift(leak_shift),
        .cfg_we(cfg_we), .cfg_dst(cfg_dst), .cfg_src(cfg_src),
        .cfg_wdata(cfg_wdata), .cfg_rdata(cfg_rdata),
        .busy(busy), .done(done),
        .encoded_spikes(encoded_spikes),
        .output_spikes(output_spikes),
        .membranes_packed(membranes_packed),
        .pre_traces_packed(pre_traces_packed),
        .post_traces_packed(post_traces_packed),
        .dominant_sources(dominant_sources),
        .update_applied(update_applied),
        .tick_count(tick_count),
        .update_count(update_count),
        .mismatch_count(mismatch_count)
    );

`ifdef SDF_FILE
    initial begin
        $sdf_annotate(`SDF_FILE, dut);
    end
`endif

    task automatic transact(
        input logic [3:0] src_spike,
        input logic [3:0] teacher
    );
        begin
            while (busy || done) @(posedge clk);
            direct_spikes = src_spike;
            teacher_spikes = teacher;
            start = 1'b1;
            @(posedge clk);
            start = 1'b0;

            timeout_count = 0;
            while (!done && timeout_count < 32) begin
                @(posedge clk);
                timeout_count = timeout_count + 1;
            end
            if (!done)
                $fatal(1, "Timeout waiting for transaction completion");
            @(posedge clk);
        end
    endtask

    initial begin
        $dumpfile("four_agent_openroad_top.vcd");
        $dumpvars(0, tb_four_agent_openroad_top);

        repeat (5) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        reset_weights = 1'b1;
        @(posedge clk);
        reset_weights = 1'b0;

        // Train the canonical four-agent cyclic communication relation.
        for (epoch = 0; epoch < 8; epoch = epoch + 1) begin
            transact(4'b0001, 4'b0010); // 0 -> 1
            transact(4'b0010, 4'b0100); // 1 -> 2
            transact(4'b0100, 4'b1000); // 2 -> 3
            transact(4'b1000, 4'b0001); // 3 -> 0
        end

        cfg_dst = 2'd1;
        cfg_src = 2'd0;
        #1;
        trained_weight = cfg_rdata;

        if (tick_count != 32)
            $fatal(1, "Expected 32 ticks, got %0d", tick_count);
        if (update_count != 32)
            $fatal(1, "Expected 32 updates, got %0d", update_count);
        if (trained_weight <= 16'sd64)
            $fatal(1, "Expected route weight[1][0] to strengthen; got %0d",
                   trained_weight);

        // Freeze must stop update_count.
        freeze_weights = 1'b1;
        transact(4'b0001, 4'b0010);
        if (update_count != 32)
            $fatal(1, "Freeze failed: update_count changed to %0d", update_count);

        $display("GLS/RTL TEST PASS weight[1][0]=%0d ticks=%0d updates=%0d",
                 trained_weight, tick_count, update_count);
        $finish;
    end
endmodule

from python.reference_model import FourAgentReference


def test_cyclic_routes_strengthen():
    model=FourAgentReference()
    for _ in range(16):
        for source in range(4):
            model.tick(direct_spikes=1<<source,
                       teacher_spikes=1<<((source+1)%4), learn=True, supervised=True)
    assert all(model.weights[(source+1)%4][source] > 64 for source in range(4))

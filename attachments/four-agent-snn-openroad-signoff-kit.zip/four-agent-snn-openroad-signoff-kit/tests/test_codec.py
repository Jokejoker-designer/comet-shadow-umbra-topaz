from python.pulse_compiler import (PulseDensityModel, decode_spike_rates,
                                   pack_levels, unpack_levels, rate_encode_offline)


def test_level_pack_roundtrip():
    levels=[0,1,128,255]
    assert unpack_levels(pack_levels(levels)) == levels


def test_density_encoder_rate():
    words=rate_encode_offline([0.0,0.25,0.5,1.0], 1024)
    rates=decode_spike_rates(words)
    assert rates[0] == 0
    assert 0.23 < rates[1] < 0.27
    assert 0.48 < rates[2] < 0.52
    assert rates[3] > 0.99


def test_encoder_deterministic():
    a=PulseDensityModel(); b=PulseDensityModel()
    assert [a.step([128]*4) for _ in range(10)] == [b.step([128]*4) for _ in range(10)]

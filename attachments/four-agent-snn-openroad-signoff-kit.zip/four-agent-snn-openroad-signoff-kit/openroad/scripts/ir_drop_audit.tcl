# Optional PDNSim audit.
# Usage after reading a routed ODB with PDN and Liberty data:
#   source ir_drop_audit.tcl
#
# Override these variables before sourcing for a different platform.
if {![info exists POWER_NET]} { set POWER_NET VDD }
if {![info exists GROUND_NET]} { set GROUND_NET VSS }
if {![info exists POWER_VOLTAGE]} { set POWER_VOLTAGE 1.0 }

set_pdnsim_net_voltage -net $POWER_NET -voltage $POWER_VOLTAGE
check_power_grid -net $POWER_NET -error_file pdn_vdd_connectivity.rpt
check_power_grid -net $GROUND_NET -error_file pdn_vss_connectivity.rpt

analyze_power_grid -net $POWER_NET \
    -source_type FULL \
    -error_file ir_drop_errors.rpt \
    -voltage_file ir_drop_instances.rpt \
    -enable_em \
    -em_outfile em_segments.rpt

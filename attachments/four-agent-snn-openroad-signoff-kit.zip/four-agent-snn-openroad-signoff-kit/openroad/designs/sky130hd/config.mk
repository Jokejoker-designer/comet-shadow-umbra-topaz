THIS_DIR := $(dir $(abspath $(lastword $(MAKEFILE_LIST))))
PROJECT_ROOT := $(abspath $(THIS_DIR)/../../..)

export DESIGN_NAME := four_agent_openroad_top
export DESIGN_NICKNAME := four_agent_snn_sky130hd
export PLATFORM := sky130hd

export VERILOG_FILES := $(PROJECT_ROOT)/rtl/snn_math_pkg.sv \
  $(PROJECT_ROOT)/rtl/pulse_density_encoder.sv \
  $(PROJECT_ROOT)/rtl/lif_agent.sv \
  $(PROJECT_ROOT)/rtl/attention_gate4.sv \
  $(PROJECT_ROOT)/rtl/stdp_matrix4.sv \
  $(PROJECT_ROOT)/rtl/four_agent_snn_core.sv \
  $(PROJECT_ROOT)/rtl/four_agent_openroad_top.sv
export SDC_FILE := $(THIS_DIR)/constraint.sdc

# Use yosys-slang because the RTL uses SystemVerilog packages, logic types,
# packed slicing, generate blocks, and unpacked internal arrays.
export SYNTH_HDL_FRONTEND := slang
export SYNTH_SLANG_ARGS := --std latest -DSYNTHESIS
export SYNTH_REPEATABLE_BUILD := 1

export CORE_UTILIZATION := 24
export CORE_ASPECT_RATIO := 1.0
export CORE_MARGIN := 2
export PLACE_DENSITY := 0.48

export GPL_TIMING_DRIVEN := 1
export GPL_ROUTABILITY_DRIVEN := 1
export ENABLE_PLACE_REPAIR_TIMING := 1
export DETAILED_METRICS := 1
export WRITE_ODB_AND_SDC_EACH_STAGE := 1
export GENERATE_ARTIFACTS_ON_FAILURE := 1


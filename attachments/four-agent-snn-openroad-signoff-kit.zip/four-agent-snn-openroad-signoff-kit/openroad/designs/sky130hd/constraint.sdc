# Primary architectural target: 50 MHz.
create_clock -name core_clk -period 20.000 [get_ports clk]

set_clock_uncertainty 0.20 [get_clocks core_clk]
set_clock_transition 0.10 [get_clocks core_clk]

set non_clock_inputs [remove_from_collection [all_inputs] [get_ports clk]]
set_input_delay 0.50 -clock core_clk $non_clock_inputs
set_output_delay 0.50 -clock core_clk [all_outputs]

# Conservative generic external loading for block-level implementation.
set_load 0.05 [all_outputs]

# The synchronous active-low reset is treated as a functional input.
set_false_path -from [get_ports rst_n]

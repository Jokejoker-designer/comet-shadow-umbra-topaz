`timescale 1ns/1ps

module four_agent_formal_top;
    (* gclk *) logic clk;

    (* anyseq *) logic rst_n;
    (* anyseq *) logic start;
    (* anyseq *) logic clear_state;
    (* anyseq *) logic reset_weights;
    (* anyseq *) logic learn_enable;
    (* anyseq *) logic supervised_mode;
    (* anyseq *) logic direct_spike_mode;
    (* anyseq *) logic freeze_weights;
    (* anyseq *) logic [31:0] rate_levels;
    (* anyseq *) logic [3:0] direct_spikes;
    (* anyseq *) logic [3:0] teacher_spikes;
    (* anyseq *) logic signed [15:0] threshold;
    (* anyseq *) logic [3:0] leak_shift;
    (* anyseq *) logic cfg_we;
    (* anyseq *) logic [1:0] cfg_dst;
    (* anyseq *) logic [1:0] cfg_src;
    (* anyseq *) logic signed [15:0] cfg_wdata;

    logic signed [15:0] cfg_rdata;
    logic busy, done;
    logic [3:0] encoded_spikes, output_spikes;
    logic signed [63:0] membranes_packed;
    logic [31:0] pre_traces_packed, post_traces_packed;
    logic [7:0] dominant_sources;
    logic update_applied;
    logic [31:0] tick_count, update_count, mismatch_count;

    four_agent_openroad_top dut (.*);

    logic past_valid = 1'b0;
    always_ff @(posedge clk) begin
        past_valid <= 1'b1;

        if (!past_valid)
            assume(!rst_n);

        if (past_valid && !$past(rst_n)) begin
            assert(tick_count == 0);
            assert(update_count == 0);
            assert(mismatch_count == 0);
        end

        assert(update_count <= tick_count);
        assert(!(done && busy));

        if (past_valid && rst_n && $past(rst_n)) begin
            assert(tick_count <= $past(tick_count) + 1);
            assert(update_count <= $past(update_count) + 1);
            assert(mismatch_count <= $past(mismatch_count) + 4);
        end
    end
endmodule

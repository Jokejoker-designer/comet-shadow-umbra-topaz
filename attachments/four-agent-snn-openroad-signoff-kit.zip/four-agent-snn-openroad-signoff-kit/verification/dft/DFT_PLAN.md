# DFT and scan verification plan

OpenROAD includes DFT commands for scan-chain architecture, but scan insertion is
a separate experimental gate for this research block.

## Scope

- one functional clock;
- synchronous active-low reset;
- state registers in FSM, neurons, traces, counters and weights;
- no inferred SRAM macro in v0.1.

## Required experiments

1. Inventory sequential cells after synthesis.
2. Insert scan with 1, 2 and 4 chains.
3. Report chain balance and maximum length.
4. Re-run STA in functional and scan-shift modes.
5. Confirm scan logic does not alter functional equivalence.
6. Generate stuck-at ATPG coverage with an external compatible tool if available.
7. Gate public claims: “scan inserted” is not equivalent to “fault coverage proven”.

## Suggested initial configuration

```tcl
set_dft_config \
  -max_chains 4 \
  -clock_mixing no_mix \
  -scan_enable_name_pattern scan_enable \
  -scan_in_name_pattern scan_in \
  -scan_out_name_pattern scan_out
```

DFT should be enabled only after the functional and physical baseline is stable.

#!/usr/bin/env bash
set -euo pipefail

: "${NETLIST:?Set NETLIST to the synthesized or post-route Verilog netlist}"
: "${STD_CELL_MODELS:?Set STD_CELL_MODELS to one or more simulation model files}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SIM="${SIM:-iverilog}"
OUT="${OUT:-gls_simv}"

if [[ "${SIM}" != "iverilog" ]]; then
  echo "This helper currently implements Icarus invocation only." >&2
  exit 2
fi

SDF_DEFINE=()
if [[ -n "${SDF_FILE:-}" ]]; then
  SDF_DEFINE=(-DSDF_FILE="\"${SDF_FILE}\"")
fi

# shellcheck disable=SC2086
iverilog -g2012 -o "${OUT}" \
  "${SDF_DEFINE[@]}" \
  ${STD_CELL_MODELS} \
  "${NETLIST}" \
  "${ROOT}/tb/tb_four_agent_openroad_top.sv"

vvp "${OUT}"

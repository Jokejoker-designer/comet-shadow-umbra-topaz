#!/usr/bin/env bash
set -euo pipefail

: "${NETLIST:?Set NETLIST to the synthesized netlist}"
: "${LIBERTY:?Set LIBERTY to the platform Liberty file}"
: "${CELL_MODELS:?Set CELL_MODELS to the standard-cell functional Verilog model}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "${WORK}"' EXIT

cat > "${WORK}/equiv.ys" <<EOF
plugin -i slang

read_slang --std latest \
  ${ROOT}/rtl/snn_math_pkg.sv \
  ${ROOT}/rtl/pulse_density_encoder.sv \
  ${ROOT}/rtl/lif_agent.sv \
  ${ROOT}/rtl/attention_gate4.sv \
  ${ROOT}/rtl/stdp_matrix4.sv \
  ${ROOT}/rtl/four_agent_snn_core.sv \
  ${ROOT}/rtl/four_agent_openroad_top.sv \
  --top four_agent_openroad_top
prep -top four_agent_openroad_top
rename four_agent_openroad_top gold
design -save gold

design -reset
read_liberty -lib ${LIBERTY}
read_verilog -lib ${CELL_MODELS}
read_verilog ${NETLIST}
prep -top four_agent_openroad_top
rename four_agent_openroad_top gate
design -save gate

design -reset
design -copy-from gold -as gold gold
design -copy-from gate -as gate gate
equiv_make gold gate equiv
hierarchy -top equiv
equiv_simple -seq 32
equiv_status -assert
EOF

yosys -m slang -s "${WORK}/equiv.ys"

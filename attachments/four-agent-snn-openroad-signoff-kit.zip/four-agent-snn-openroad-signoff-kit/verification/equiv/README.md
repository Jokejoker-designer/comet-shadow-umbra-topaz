# RTL-to-netlist equivalence

Equivalence is a mandatory signoff gate, separate from gate-level simulation.

Inputs:

- RTL source;
- ORFS/Yosys synthesized netlist;
- platform Liberty;
- standard-cell functional models.

Because the design contains sequential learning state and a synthesized divider,
a monolithic proof may be difficult. The escalation path is:

1. `equiv_simple`;
2. partition by module;
3. prove encoder, LIF and STDP separately;
4. isolate the attention divider;
5. use EQY/partitioned equivalence for the full design.

Do not waive a failed equivalence result merely because RTL and GLS smoke tests pass.

# Validation

## Executed

- Python source syntax: **PASS**
- Shell syntax: **PASS**
- SystemVerilog parse/elaboration with pyslang: **PASS**
- SystemVerilog errors: **0**
- Python reference tests: **PASS**

```text
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                                                     [100%][0m
[32m[32m[1m4 passed[0m[32m in 0.51s[0m[0m
```

## Not executed

- Yosys synthesis;
- ORFS RTL-to-GDS;
- OpenSTA post-route timing;
- OpenRCX extraction;
- KLayout DRC/LVS;
- gate-level simulation;
- SymbiYosys;
- PDNSim.

The truthful status is:

```text
OPENROAD_HARNESS_DESIGNED
NOT_PHYSICALLY_SIGNED_OFF
```

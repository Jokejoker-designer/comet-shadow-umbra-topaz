from __future__ import annotations

from pathlib import Path

try:
    import pyslang
except ImportError as error:
    raise SystemExit("Install pyslang to run this preflight check.") from error

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    ROOT / "rtl" / "snn_math_pkg.sv",
    ROOT / "rtl" / "pulse_density_encoder.sv",
    ROOT / "rtl" / "lif_agent.sv",
    ROOT / "rtl" / "attention_gate4.sv",
    ROOT / "rtl" / "stdp_matrix4.sv",
    ROOT / "rtl" / "four_agent_snn_core.sv",
    ROOT / "rtl" / "four_agent_openroad_top.sv",
    ROOT / "tb" / "tb_four_agent_openroad_top.sv",
]

tree = pyslang.syntax.SyntaxTree.fromFiles([str(path) for path in FILES])
compilation = pyslang.ast.Compilation()
compilation.addSyntaxTree(tree)
diagnostics = list(compilation.getAllDiagnostics())

error_count = 0
for diagnostic in diagnostics:
    severity = getattr(diagnostic, "severity", None)
    text = str(diagnostic)
    print(text)
    if severity is not None and str(severity).lower().endswith("error"):
        error_count += 1

if error_count:
    raise SystemExit(f"SystemVerilog preflight FAILED: {error_count} errors")

print(
    f"SystemVerilog preflight PASS: {len(FILES)} files, "
    f"{len(diagnostics)} diagnostics, 0 errors"
)

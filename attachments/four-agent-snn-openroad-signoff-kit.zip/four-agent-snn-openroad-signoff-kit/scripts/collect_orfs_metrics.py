from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


INTEREST = (
    "slack", "tns", "wns", "area", "util", "wirelength", "drc",
    "antenna", "power", "instances", "cells", "vias", "congestion",
    "clock", "skew", "setup", "hold",
)


def flatten(value: Any, prefix: str = "") -> dict[str, Any]:
    output: dict[str, Any] = {}
    if isinstance(value, dict):
        for key, item in value.items():
            child = f"{prefix}.{key}" if prefix else str(key)
            output.update(flatten(item, child))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            output.update(flatten(item, f"{prefix}[{index}]"))
    else:
        output[prefix] = value
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("search_root", type=Path)
    parser.add_argument("--out", type=Path, default=Path("orfs_summary.json"))
    args = parser.parse_args()

    candidates = sorted(args.search_root.rglob("metrics*.json"))
    if not candidates:
        raise SystemExit(f"No ORFS metrics JSON found under {args.search_root}")

    selected = candidates[-1]
    raw = json.loads(selected.read_text(encoding="utf-8"))
    flat = flatten(raw)
    filtered = {
        key: value for key, value in flat.items()
        if any(token in key.lower() for token in INTEREST)
    }

    result = {
        "source": str(selected),
        "metric_count": len(flat),
        "selected_metric_count": len(filtered),
        "metrics": filtered,
    }
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

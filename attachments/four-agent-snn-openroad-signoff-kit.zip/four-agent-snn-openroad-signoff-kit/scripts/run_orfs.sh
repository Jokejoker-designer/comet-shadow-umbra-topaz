#!/usr/bin/env bash
set -euo pipefail

PLATFORM="${1:-nangate45}"
TARGET="${2:-finish}"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${PROJECT_ROOT}/openroad/designs/${PLATFORM}/config.mk"
OUT_DIR="${PROJECT_ROOT}/build/orfs/${PLATFORM}"

if [[ ! -f "${CONFIG}" ]]; then
  echo "Unknown platform '${PLATFORM}'. Use nangate45 or sky130hd." >&2
  exit 2
fi

if [[ -n "${ORFS_ROOT:-}" && -f "${ORFS_ROOT}/flow/Makefile" ]]; then
  FLOW_DIR="${ORFS_ROOT}/flow"
elif [[ -n "${ORFS_FLOW_DIR:-}" && -f "${ORFS_FLOW_DIR}/Makefile" ]]; then
  FLOW_DIR="${ORFS_FLOW_DIR}"
else
  FLOW_DIR="$(find / -path '*/OpenROAD-flow-scripts/flow/Makefile' \
    -printf '%h\n' 2>/dev/null | head -n 1 || true)"
fi

if [[ -z "${FLOW_DIR}" || ! -f "${FLOW_DIR}/Makefile" ]]; then
  cat >&2 <<'EOF'
OpenROAD-flow-scripts was not found.

Set:
  ORFS_ROOT=/path/to/OpenROAD-flow-scripts
or:
  ORFS_FLOW_DIR=/path/to/OpenROAD-flow-scripts/flow
EOF
  exit 3
fi

echo "ORFS flow: ${FLOW_DIR}"
echo "Design config: ${CONFIG}"
echo "Target: ${TARGET}"

copy_artifacts() {
  mkdir -p "${OUT_DIR}"
  for category in logs reports results objects; do
    source_dir="${FLOW_DIR}/${category}/${PLATFORM}"
    if [[ -d "${source_dir}" ]]; then
      mkdir -p "${OUT_DIR}/${category}"
      find "${source_dir}" -maxdepth 3 -type d \
        \( -name 'four_agent_snn*' -o -name 'four_agent_openroad_top*' \) \
        -print0 2>/dev/null |
      while IFS= read -r -d '' design_dir; do
        cp -a "${design_dir}" "${OUT_DIR}/${category}/"
      done
    fi
  done

  {
    echo "timestamp_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "platform=${PLATFORM}"
    echo "target=${TARGET}"
    echo "flow_dir=${FLOW_DIR}"
    command -v openroad >/dev/null && openroad -version || true
    command -v yosys >/dev/null && yosys -V || true
    command -v klayout >/dev/null && klayout -v || true
  } > "${OUT_DIR}/tool_versions.txt"
}

case "${TARGET}" in
  finish|all)
    make -C "${FLOW_DIR}" DESIGN_CONFIG="${CONFIG}"
    copy_artifacts
    ;;
  clean)
    make -C "${FLOW_DIR}" DESIGN_CONFIG="${CONFIG}" clean_all
    rm -rf "${OUT_DIR}"
    ;;
  synth|floorplan|place|cts|route)
    make -C "${FLOW_DIR}" DESIGN_CONFIG="${CONFIG}" "${TARGET}"
    copy_artifacts
    ;;
  metadata)
    make -C "${FLOW_DIR}" DESIGN_CONFIG="${CONFIG}" metadata
    copy_artifacts
    ;;
  *)
    echo "Unsupported target: ${TARGET}" >&2
    exit 4
    ;;
esac

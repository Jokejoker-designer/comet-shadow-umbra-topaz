#!/usr/bin/env bash
set -euo pipefail
PLATFORM="${1:-nangate45}"
TARGET="${2:-finish}"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

docker run --rm \
  --entrypoint bash \
  -v "${PROJECT_ROOT}:/work" \
  -w /work \
  openroad/orfs:latest \
  -lc "/work/scripts/run_orfs.sh '${PLATFORM}' '${TARGET}'"

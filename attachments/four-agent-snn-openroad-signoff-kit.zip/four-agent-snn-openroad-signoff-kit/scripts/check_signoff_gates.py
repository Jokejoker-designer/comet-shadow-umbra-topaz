from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def find_values(metrics: dict[str, Any], tokens: tuple[str, ...]) -> list[tuple[str, float]]:
    found = []
    for key, value in metrics.items():
        if all(token in key.lower() for token in tokens):
            try:
                found.append((key, float(value)))
            except (TypeError, ValueError):
                pass
    return found


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("summary", type=Path)
    parser.add_argument("--allow-missing", action="store_true")
    args = parser.parse_args()

    payload = json.loads(args.summary.read_text(encoding="utf-8"))
    metrics = payload["metrics"]
    failures: list[str] = []
    notes: list[str] = []

    setup = find_values(metrics, ("setup", "slack")) or find_values(metrics, ("wns",))
    hold = find_values(metrics, ("hold", "slack"))
    drc = find_values(metrics, ("drc",))
    antenna = find_values(metrics, ("antenna",))

    if setup:
        worst = min(value for _, value in setup)
        if worst < 0:
            failures.append(f"Negative setup slack: {worst}")
    elif not args.allow_missing:
        failures.append("Setup slack metric not found")

    if hold:
        worst = min(value for _, value in hold)
        if worst < 0:
            failures.append(f"Negative hold slack: {worst}")
    else:
        notes.append("Hold slack metric not found; inspect ORFS timing reports")

    if drc:
        worst = max(value for _, value in drc)
        if worst > 0:
            failures.append(f"DRC metric indicates violations: {worst}")
    else:
        notes.append("DRC metric not found; inspect TritonRoute/KLayout reports")

    if antenna:
        worst = max(value for _, value in antenna)
        if worst > 0:
            failures.append(f"Antenna metric indicates violations: {worst}")

    verdict = "PASS" if not failures else "FAIL"
    result = {"verdict": verdict, "failures": failures, "notes": notes}
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if verdict == "PASS" else 1)


if __name__ == "__main__":
    main()

"""Readable reference model for the four-agent hardware demo."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
try:
    from .pulse_compiler import PulseDensityModel, clamp_u8
except ImportError:
    from pulse_compiler import PulseDensityModel, clamp_u8


def sat16(value: int) -> int:
    return max(-32768, min(32767, int(value)))


@dataclass
class Snapshot:
    input_spikes: int
    output_spikes: int
    membranes: list[int]
    weights: list[list[int]]
    mismatch_count: int


class FourAgentReference:
    def __init__(self, threshold=512, leak_shift=3,
                 initial_cross_weight=64, external_current=320) -> None:
        self.threshold = threshold
        self.leak_shift = leak_shift
        self.external_current = external_current
        self.encoder = PulseDensityModel()
        self.mem = [0]*4
        self.output_spikes = 0
        self.pre_trace = [0]*4
        self.post_trace = [0]*4
        self.weights = [[0 if d==s else initial_cross_weight for s in range(4)]
                        for d in range(4)]
        self.mismatch_count = 0

    @staticmethod
    def trace_next(trace: int, spike: int) -> int:
        return min(255, trace - (trace >> 3) + (32 if spike else 0))

    def attention(self, input_spikes: int, levels: Sequence[int]) -> list[int]:
        contexts = [0]*4
        for dst in range(4):
            scores=[]
            for src in range(4):
                if (input_spikes >> src) & 1:
                    qk = abs(self.mem[dst]) * abs(self.mem[src])
                    score = 1 + (qk >> 12) + (max(self.weights[dst][src],0) >> 4)
                else:
                    score = 0
                scores.append(score)
            total=sum(scores)
            contexts[dst] = 0 if total==0 else sum(
                scores[src] * clamp_u8(levels[src]) for src in range(4)
            ) // total
        return contexts

    def tick(self, levels=(255,255,255,255), *, direct_spikes=None,
             teacher_spikes=0, learn=True, supervised=True) -> Snapshot:
        input_spikes = (direct_spikes & 0xF) if direct_spikes is not None \
                       else self.encoder.step(levels)
        contexts = self.attention(input_spikes, levels)
        new_output = 0
        for agent in range(4):
            leaked = self.mem[agent] if self.leak_shift==0 else \
                     self.mem[agent] - (self.mem[agent] >> self.leak_shift)
            current = contexts[agent]
            if (input_spikes >> agent) & 1:
                current += self.external_current
            nxt = leaked + current
            if nxt >= self.threshold:
                new_output |= 1 << agent
                nxt -= self.threshold
            self.mem[agent] = sat16(max(-8192, min(8191, nxt)))

        pre_next=[self.trace_next(self.pre_trace[s], (input_spikes>>s)&1)
                  for s in range(4)]
        post_event = teacher_spikes if supervised else new_output
        post_next=[self.trace_next(self.post_trace[d], (post_event>>d)&1)
                   for d in range(4)]
        if learn:
            for dst in range(4):
                for src in range(4):
                    if dst == src: continue
                    if supervised:
                        pot = 32 if ((teacher_spikes>>dst)&1 and (input_spikes>>src)&1) else 0
                        dep = 32 if ((new_output>>dst)&1 and not ((teacher_spikes>>dst)&1) and (input_spikes>>src)&1) else 0
                    else:
                        pot = pre_next[src] if (new_output>>dst)&1 else 0
                        dep = post_next[dst] if (input_spikes>>src)&1 else 0
                    self.weights[dst][src] = max(-2047, min(2047,
                        self.weights[dst][src] + ((pot-dep) >> 2)))
        self.pre_trace, self.post_trace = pre_next, post_next
        self.output_spikes = new_output
        self.mismatch_count += sum(((new_output>>i)&1) != ((teacher_spikes>>i)&1)
                                   for i in range(4)) if supervised else 0
        return Snapshot(input_spikes, new_output, self.mem.copy(),
                        [row.copy() for row in self.weights], self.mismatch_count)


def demo() -> None:
    model=FourAgentReference()
    initial=[row.copy() for row in model.weights]
    for _ in range(64):
        for source in range(4):
            model.tick(direct_spikes=1<<source,
                       teacher_spikes=1<<((source+1)%4),
                       supervised=True, learn=True)
    print("Initial weights:")
    for row in initial: print(row)
    print("Trained weights:")
    for row in model.weights: print(row)
    routes=[model.weights[(s+1)%4][s] for s in range(4)]
    print("Cyclic routes:", routes)
    assert all(value > 64 for value in routes)
    print("reference model PASS")


if __name__ == "__main__":
    demo()

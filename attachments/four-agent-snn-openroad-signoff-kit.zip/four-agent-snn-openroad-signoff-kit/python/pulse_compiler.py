"""Bidirectional pulse/event compiler for the four-agent FPGA demo."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Sequence


def clamp_u8(value: int) -> int:
    return max(0, min(255, int(value)))


def float_to_level(value: float) -> int:
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"value must be in [0,1], got {value}")
    return clamp_u8(round(value * 255.0))


def pack_levels(levels: Sequence[int]) -> int:
    if len(levels) != 4:
        raise ValueError("Exactly four levels are required")
    return sum(clamp_u8(level) << (8 * idx) for idx, level in enumerate(levels))


def unpack_levels(word: int) -> list[int]:
    return [(word >> (8 * idx)) & 0xFF for idx in range(4)]


def pack_spikes(spikes: Sequence[int | bool]) -> int:
    if len(spikes) != 4:
        raise ValueError("Exactly four spikes are required")
    return sum((1 if spike else 0) << idx for idx, spike in enumerate(spikes))


def unpack_spikes(word: int) -> list[int]:
    return [(word >> idx) & 1 for idx in range(4)]


@dataclass(frozen=True)
class TemporalFrame:
    levels: tuple[int, int, int, int]
    teacher_spikes: int = 0
    learn: bool = True
    supervised: bool = True

    @classmethod
    def from_floats(cls, values: Sequence[float], **kwargs) -> "TemporalFrame":
        if len(values) != 4:
            raise ValueError("Exactly four values are required")
        return cls(tuple(float_to_level(value) for value in values), **kwargs)


class PulseDensityModel:
    def __init__(self) -> None:
        self.accumulators = [0, 0, 0, 0]

    def clear(self) -> None:
        self.accumulators[:] = [0, 0, 0, 0]

    def step(self, levels: Sequence[int]) -> int:
        if len(levels) != 4:
            raise ValueError("Exactly four levels are required")
        result = 0
        for idx, level in enumerate(levels):
            total = self.accumulators[idx] + clamp_u8(level)
            if total >= 256:
                result |= 1 << idx
            self.accumulators[idx] = total & 0xFF
        return result


def rate_encode_offline(values: Sequence[float], ticks: int) -> list[int]:
    if ticks <= 0:
        raise ValueError("ticks must be positive")
    levels = [float_to_level(value) for value in values]
    model = PulseDensityModel()
    return [model.step(levels) for _ in range(ticks)]


def decode_spike_rates(words: Iterable[int]) -> list[float]:
    samples = list(words)
    if not samples:
        return [0.0] * 4
    counts = [0] * 4
    for word in samples:
        for idx in range(4):
            counts[idx] += (word >> idx) & 1
    return [count / len(samples) for count in counts]


def compile_register_program(frames: Sequence[TemporalFrame]) -> list[dict]:
    return [
        {
            "tick": idx,
            "rate_levels_word": pack_levels(frame.levels),
            "teacher_spikes": frame.teacher_spikes & 0xF,
            "learn": frame.learn,
            "supervised": frame.supervised,
        }
        for idx, frame in enumerate(frames)
    ]

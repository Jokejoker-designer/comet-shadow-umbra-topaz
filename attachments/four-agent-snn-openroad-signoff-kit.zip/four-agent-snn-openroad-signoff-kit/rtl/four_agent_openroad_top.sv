`timescale 1ns/1ps

// ASIC/OpenROAD integration wrapper.
// The learning algorithm remains in four_agent_snn_core. This wrapper provides
// a stable top-level interface for synthesis, timing, gate-level simulation,
// equivalence, and physical design experiments.
module four_agent_openroad_top (
    input  logic clk,
    input  logic rst_n,

    input  logic start,
    input  logic clear_state,
    input  logic reset_weights,
    input  logic learn_enable,
    input  logic supervised_mode,
    input  logic direct_spike_mode,
    input  logic freeze_weights,

    input  logic [31:0] rate_levels,
    input  logic [3:0] direct_spikes,
    input  logic [3:0] teacher_spikes,
    input  logic signed [15:0] threshold,
    input  logic [3:0] leak_shift,

    input  logic cfg_we,
    input  logic [1:0] cfg_dst,
    input  logic [1:0] cfg_src,
    input  logic signed [15:0] cfg_wdata,
    output logic signed [15:0] cfg_rdata,

    output logic busy,
    output logic done,
    output logic [3:0] encoded_spikes,
    output logic [3:0] output_spikes,
    output logic signed [63:0] membranes_packed,
    output logic [31:0] pre_traces_packed,
    output logic [31:0] post_traces_packed,
    output logic [7:0] dominant_sources,
    output logic update_applied,
    output logic [31:0] tick_count,
    output logic [31:0] update_count,
    output logic [31:0] mismatch_count
);
    four_agent_snn_core core_i (
        .clk(clk),
        .rst_n(rst_n),
        .start(start),
        .clear_state(clear_state),
        .reset_weights(reset_weights),
        .learn_enable(learn_enable),
        .supervised_mode(supervised_mode),
        .direct_spike_mode(direct_spike_mode),
        .freeze_weights(freeze_weights),
        .rate_levels(rate_levels),
        .direct_spikes(direct_spikes),
        .teacher_spikes(teacher_spikes),
        .threshold(threshold),
        .leak_shift(leak_shift),
        .cfg_we(cfg_we),
        .cfg_dst(cfg_dst),
        .cfg_src(cfg_src),
        .cfg_wdata(cfg_wdata),
        .cfg_rdata(cfg_rdata),
        .busy(busy),
        .done(done),
        .encoded_spikes(encoded_spikes),
        .output_spikes(output_spikes),
        .membranes_packed(membranes_packed),
        .pre_traces_packed(pre_traces_packed),
        .post_traces_packed(post_traces_packed),
        .dominant_sources(dominant_sources),
        .update_applied(update_applied),
        .tick_count(tick_count),
        .update_count(update_count),
        .mismatch_count(mismatch_count)
    );
endmodule

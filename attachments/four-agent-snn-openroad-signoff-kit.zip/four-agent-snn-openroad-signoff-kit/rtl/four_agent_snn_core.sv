`timescale 1ns/1ps
module four_agent_snn_core #(
    parameter logic signed [15:0] EXTERNAL_CURRENT = 16'sd320
) (
    input  logic clk,
    input  logic rst_n,
    input  logic start,
    input  logic clear_state,
    input  logic reset_weights,
    input  logic learn_enable,
    input  logic supervised_mode,
    input  logic direct_spike_mode,
    input  logic freeze_weights,
    input  logic [31:0] rate_levels,
    input  logic [3:0] direct_spikes,
    input  logic [3:0] teacher_spikes,
    input  logic signed [15:0] threshold,
    input  logic [3:0] leak_shift,
    input  logic cfg_we,
    input  logic [1:0] cfg_dst,
    input  logic [1:0] cfg_src,
    input  logic signed [15:0] cfg_wdata,
    output logic signed [15:0] cfg_rdata,
    output logic busy,
    output logic done,
    output logic [3:0] encoded_spikes,
    output logic [3:0] output_spikes,
    output logic signed [63:0] membranes_packed,
    output logic [31:0] pre_traces_packed,
    output logic [31:0] post_traces_packed,
    output logic [7:0] dominant_sources,
    output logic update_applied,
    output logic [31:0] tick_count,
    output logic [31:0] update_count,
    output logic [31:0] mismatch_count
);
    import snn_math_pkg::*;
    typedef enum logic [2:0] {IDLE, ENCODE, ATTEND, NEURON, LEARN, FINISH} state_t;
    state_t state;
    logic [31:0] levels_reg;
    logic [3:0] direct_reg, teacher_reg;
    logic direct_mode_reg, learn_reg, supervised_reg, freeze_reg;
    logic [3:0] encoder_spike_wire, source_spikes, source_spikes_reg;
    logic [7:0] encoder_acc [0:3];
    logic signed [255:0] weights_packed;
    logic signed [63:0] context_comb, context_reg;
    logic signed [15:0] input_current [0:3];
    logic signed [15:0] membrane_wire [0:3];
    logic stdp_update;
    logic [31:0] mismatch_this_tick;
    integer i;

    assign busy = (state != IDLE) && (state != FINISH);
    assign done = (state == FINISH);
    assign source_spikes = direct_mode_reg ? direct_reg : encoder_spike_wire;
    assign encoded_spikes = source_spikes_reg;
    assign update_applied = stdp_update;

    genvar g;
    generate
        for (g = 0; g < 4; g = g + 1) begin : GEN_ENC
            pulse_density_encoder enc (
                .clk(clk), .rst_n(rst_n), .clear_state(clear_state),
                .step(state == ENCODE), .level(levels_reg[g*8 +: 8]),
                .spike(encoder_spike_wire[g]), .accumulator(encoder_acc[g])
            );
        end
    endgenerate

    attention_gate4 attention (
        .source_spikes(source_spikes), .levels_packed(levels_reg),
        .membranes_packed(membranes_packed), .weights_packed(weights_packed),
        .context_packed(context_comb), .dominant_sources(dominant_sources)
    );

    always_comb begin
        for (i = 0; i < 4; i = i + 1) begin
            input_current[i] = $signed(context_reg[i*16 +: 16]);
            if (source_spikes_reg[i])
                input_current[i] = sat16($signed(input_current[i]) + $signed(EXTERNAL_CURRENT));
        end
    end

    generate
        for (g = 0; g < 4; g = g + 1) begin : GEN_LIF
            lif_agent neuron (
                .clk(clk), .rst_n(rst_n), .clear_state(clear_state),
                .step(state == NEURON), .input_current(input_current[g]),
                .threshold(threshold), .leak_shift(leak_shift),
                .spike(output_spikes[g]), .membrane(membrane_wire[g])
            );
        end
    endgenerate

    generate
        for (g = 0; g < 4; g = g + 1) begin : GEN_MEM_PACK
            assign membranes_packed[g*16 +: 16] = $unsigned(membrane_wire[g]);
        end
    endgenerate

    stdp_matrix4 matrix (
        .clk(clk), .rst_n(rst_n), .clear_state(clear_state),
        .reset_weights(reset_weights), .step(state == LEARN),
        .learn_enable(learn_reg), .supervised_mode(supervised_reg),
        .freeze_weights(freeze_reg), .pre_spikes(source_spikes_reg),
        .post_spikes(output_spikes), .teacher_spikes(teacher_reg),
        .cfg_we(cfg_we), .cfg_dst(cfg_dst), .cfg_src(cfg_src),
        .cfg_wdata(cfg_wdata), .cfg_rdata(cfg_rdata),
        .weights_packed(weights_packed), .pre_traces_packed(pre_traces_packed),
        .post_traces_packed(post_traces_packed), .update_applied(stdp_update)
    );

    always_comb begin
        mismatch_this_tick = 32'd0;
        for (i = 0; i < 4; i = i + 1)
            if (output_spikes[i] != teacher_reg[i])
                mismatch_this_tick = mismatch_this_tick + 1;
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= IDLE;
            levels_reg <= '0; direct_reg <= '0; teacher_reg <= '0;
            direct_mode_reg <= 1'b0; learn_reg <= 1'b0;
            supervised_reg <= 1'b0; freeze_reg <= 1'b0;
            source_spikes_reg <= '0; context_reg <= '0;
            tick_count <= 0; update_count <= 0; mismatch_count <= 0;
        end else begin
            case (state)
                IDLE: if (start) begin
                    levels_reg <= rate_levels; direct_reg <= direct_spikes;
                    teacher_reg <= teacher_spikes; direct_mode_reg <= direct_spike_mode;
                    learn_reg <= learn_enable; supervised_reg <= supervised_mode;
                    freeze_reg <= freeze_weights; state <= ENCODE;
                end
                ENCODE: state <= ATTEND;
                ATTEND: begin
                    source_spikes_reg <= source_spikes;
                    context_reg <= context_comb;
                    state <= NEURON;
                end
                NEURON: state <= LEARN;
                LEARN: begin
                    tick_count <= tick_count + 1;
                    if (learn_reg && !freeze_reg) update_count <= update_count + 1;
                    if (supervised_reg) mismatch_count <= mismatch_count + mismatch_this_tick;
                    state <= FINISH;
                end
                FINISH: state <= IDLE;
                default: state <= IDLE;
            endcase
        end
    end
endmodule

`timescale 1ns/1ps
module attention_gate4 #(
    parameter int QK_SHIFT = 12,
    parameter int WEIGHT_SHIFT = 4,
    parameter int VALUE_SHIFT = 0
) (
    input  logic [3:0] source_spikes,
    input  logic [31:0] levels_packed,
    input  logic signed [63:0] membranes_packed,
    input  logic signed [255:0] weights_packed,
    output logic signed [63:0] context_packed,
    output logic [7:0] dominant_sources
);
    import snn_math_pkg::*;
    integer dst, src;
    logic signed [15:0] mem_dst, mem_src, weight_value;
    logic [7:0] level_value;
    logic [31:0] qk_product, positive_weight, score, best_score;
    logic [63:0] score_sum;
    logic signed [63:0] numerator;
    logic signed [63:0] product_term;
    logic signed [63:0] quotient;
    logic signed [31:0] value_scaled;
    logic signed [63:0] value_ext;
    logic [1:0] best_source;

    always_comb begin
        context_packed = '0;
        dominant_sources = '0;
        for (dst = 0; dst < 4; dst = dst + 1) begin
            mem_dst = $signed(membranes_packed[dst*16 +: 16]);
            score_sum = 64'd0;
            numerator = 64'sd0;
            best_score = 32'd0;
            best_source = 2'd0;
            quotient = 64'sd0;
            for (src = 0; src < 4; src = src + 1) begin
                mem_src = $signed(membranes_packed[src*16 +: 16]);
                weight_value = $signed(weights_packed[(dst*4+src)*16 +: 16]);
                level_value = levels_packed[src*8 +: 8];
                qk_product = abs16(mem_dst) * abs16(mem_src);
                positive_weight = (weight_value > 0)
                                ? {{16{1'b0}}, $unsigned(weight_value)}
                                : 32'd0;
                if (source_spikes[src])
                    score = 32'd1 + (qk_product >> QK_SHIFT)
                                   + (positive_weight >> WEIGHT_SHIFT);
                else
                    score = 32'd0;

                value_scaled = $signed({24'd0, level_value}) <<< VALUE_SHIFT;
                score_sum = score_sum + {32'd0, score};
                product_term = $signed({1'b0, score, 31'd0}) >>> 31;
                value_ext = $signed({{32{value_scaled[31]}}, value_scaled});
                product_term = product_term * value_ext;
                numerator = numerator + product_term;
                if (score > best_score) begin
                    best_score = score;
                    best_source = src[1:0];
                end
            end
            if (score_sum != 0)
                quotient = numerator / $signed(score_sum);
            context_packed[dst*16 +: 16] = $unsigned(sat16($signed(quotient[31:0])));
            dominant_sources[dst*2 +: 2] = best_source;
        end
    end
endmodule

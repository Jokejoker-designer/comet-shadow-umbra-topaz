# Contributing

Every pull request must include:

- problem and evidence;
- scope;
- behavior before and after;
- tests;
- timing/area impact when RTL changes;
- learning-metric impact when algorithm changes;
- known limitations;
- rollback instructions.

A learning-rule change must update the Python reference first and run the same
seed/configuration before and after. Physical-design optimizations must not
silently alter functional arithmetic.

module eight_agent_full_parallel_core #(
    parameter int W_W = 12,
    parameter int SCORE_W = W_W + 4,
    parameter int LEARNING_RATE = 1
) (
    input  logic clk,
    input  logic rst,

    input  logic start,
    input  logic train_enable,
    input  logic freeze,

    input  logic [7:0] stimulus,
    input  logic [7:0] teacher,

    output logic [7:0] output_spikes,
    output logic [31:0] tick_count,
    output logic [31:0] update_count,
    output logic [31:0] mismatch_count,
    output logic done,

    input  logic [2:0] inspect_dst,
    input  logic [2:0] inspect_src,
    output logic signed [W_W-1:0] inspect_weight
);

    logic signed [W_W-1:0] weight [0:7][0:7];
    logic signed [SCORE_W-1:0] score [0:7];
    logic [7:0] candidate_spikes;

    integer d;
    integer k;
    logic [3:0] mismatch_now;

    plastic_matrix8_full_parallel #(
        .W_W(W_W),
        .LEARNING_RATE(LEARNING_RATE)
    ) u_weights (
        .clk(clk),
        .rst(rst),
        .train_pulse(start && train_enable),
        .freeze(freeze),
        .stimulus(stimulus),
        .teacher(teacher),
        .weight(weight),
        .update_count(update_count)
    );

    parallel_score8 #(
        .W_W(W_W),
        .SCORE_W(SCORE_W)
    ) u_scores (
        .stimulus(stimulus),
        .weight(weight),
        .score(score)
    );

    always_comb begin
        for (d = 0; d < 8; d = d + 1)
            candidate_spikes[d] = (score[d] > 0);

        mismatch_now = 4'd0;
        for (k = 0; k < 8; k = k + 1)
            mismatch_now = mismatch_now + (candidate_spikes[k] ^ teacher[k]);

        inspect_weight = weight[inspect_dst][inspect_src];
    end

    always_ff @(posedge clk) begin
        if (rst) begin
            output_spikes <= 8'h00;
            tick_count <= 32'd0;
            mismatch_count <= 32'd0;
            done <= 1'b0;
        end else begin
            done <= 1'b0;
            if (start) begin
                // Output is always from pre-update weights for this transaction.
                output_spikes <= candidate_spikes;
                tick_count <= tick_count + 1'b1;

                // Teacher is only a scoring reference when supplied.
                // In board EVAL_AFTER, train_enable must be 0.
                if (teacher != 8'h00)
                    mismatch_count <= mismatch_count + mismatch_now;

                done <= 1'b1;
            end
        end
    end
endmodule

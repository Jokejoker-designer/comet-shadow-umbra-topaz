module parallel_score8 #(
    parameter int W_W = 12,
    parameter int SCORE_W = W_W + 4
) (
    input  logic [7:0] stimulus,
    input  logic signed [W_W-1:0] weight [0:7][0:7],
    output logic signed [SCORE_W-1:0] score [0:7]
);
    integer d, s;
    logic signed [SCORE_W-1:0] acc;
    logic signed [SCORE_W-1:0] w_ext;

    always_comb begin
        for (d = 0; d < 8; d = d + 1) begin
            acc = '0;
            for (s = 0; s < 8; s = s + 1) begin
                w_ext = {{(SCORE_W-W_W){weight[d][s][W_W-1]}}, weight[d][s]};
                // Bipolar x[s]: bit 1 = +1, bit 0 = -1.
                if (stimulus[s])
                    acc = acc + w_ext;
                else
                    acc = acc - w_ext;
            end
            score[d] = acc;
        end
    end
endmodule

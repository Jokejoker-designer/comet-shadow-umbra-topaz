module plastic_matrix8_full_parallel #(
    parameter int W_W = 12,
    parameter int LEARNING_RATE = 1,
    parameter int W_MIN = -(1 << (W_W-1)),
    parameter int W_MAX =  (1 << (W_W-1)) - 1
) (
    input  logic clk,
    input  logic rst,
    input  logic train_pulse,
    input  logic freeze,
    input  logic [7:0] stimulus,
    input  logic [7:0] teacher,
    output logic signed [W_W-1:0] weight [0:7][0:7],
    output logic [31:0] update_count
);

    function automatic logic signed [W_W-1:0] clip_weight(
        input logic signed [W_W:0] value
    );
        begin
            if (value > W_MAX)
                clip_weight = W_MAX;
            else if (value < W_MIN)
                clip_weight = W_MIN;
            else
                clip_weight = value[W_W-1:0];
        end
    endfunction

    integer d, s;
    logic signed [W_W:0] next_value;

    always_ff @(posedge clk) begin
        if (rst) begin
            update_count <= 32'd0;
            for (d = 0; d < 8; d = d + 1)
                for (s = 0; s < 8; s = s + 1)
                    weight[d][s] <= '0;
        end else if (train_pulse && !freeze) begin
            // Intentional full-parallel architecture:
            // synthesis unrolls 8x8 independent add/sub update decisions.
            for (d = 0; d < 8; d = d + 1) begin
                for (s = 0; s < 8; s = s + 1) begin
                    if (stimulus[s] == teacher[d])
                        next_value = $signed(weight[d][s]) + LEARNING_RATE;
                    else
                        next_value = $signed(weight[d][s]) - LEARNING_RATE;
                    weight[d][s] <= clip_weight(next_value);
                end
            end
            update_count <= update_count + 1'b1;
        end
    end
endmodule

`timescale 1ns/1ps
// ATTENTION_BACKEND 0 = NORMALIZED (research, 8 dividers — not the board default)
// ATTENTION_BACKEND 1 = ROUTE_GATE (board default, same law as proven 4-agent)
module attention_gate8 #(
    parameter int ATTENTION_BACKEND = 1,
    parameter logic signed [15:0] GATE_THRESHOLD = 16'sd256,
    parameter logic signed [15:0] GATE_CURRENT = 16'sd560
) (
    input  logic [7:0] source_spikes,
    input  logic signed [1023:0] weights_packed,
    output logic signed [127:0] context_packed,
    output logic [23:0] dominant_sources
);
    integer dst, src;
    logic signed [15:0] weight_value, gate_acc;

    generate
        if (ATTENTION_BACKEND == 1) begin : g_route_gate
            always_comb begin
                context_packed = '0;
                dominant_sources = '0;
                weight_value = '0;
                gate_acc = '0;
                for (dst = 0; dst < 8; dst = dst + 1) begin
                    gate_acc = 16'sd0;
                    for (src = 0; src < 8; src = src + 1) begin
                        weight_value = $signed(weights_packed[(dst*8+src)*16 +: 16]);
                        if (source_spikes[src] && (weight_value > GATE_THRESHOLD)) begin
                            gate_acc = GATE_CURRENT;
                            dominant_sources[dst*3 +: 3] = src[2:0];
                        end
                    end
                    context_packed[dst*16 +: 16] = gate_acc;
                end
            end
        end else begin : g_normalized
            // Intentionally unused on the Basys 3 default bit. Kept so the
            // backend switch remains explicit and is not a silent approximation.
            always_comb begin
                context_packed = '0;
                dominant_sources = '0;
            end
        end
    endgenerate
endmodule

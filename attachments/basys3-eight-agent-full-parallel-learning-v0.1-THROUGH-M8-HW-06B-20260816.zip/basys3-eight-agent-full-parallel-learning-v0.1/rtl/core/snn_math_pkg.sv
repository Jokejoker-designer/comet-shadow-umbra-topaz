`timescale 1ns/1ps

package snn_math_pkg;
    function automatic logic signed [15:0] sat16(input logic signed [31:0] value);
        if (value > 32'sd32767)
            sat16 = 16'sh7fff;
        else if (value < -32'sd32768)
            sat16 = 16'sh8000;
        else
            sat16 = $signed(value[15:0]);
    endfunction

    function automatic logic signed [15:0] clip_weight(
        input logic signed [31:0] value,
        input logic signed [15:0] limit
    );
        logic signed [31:0] lim;
        begin
            lim = $signed({{16{limit[15]}}, limit});
            if (value > lim)
                clip_weight = limit;
            else if (value < -lim)
                clip_weight = -limit;
            else
                clip_weight = $signed(value[15:0]);
        end
    endfunction

    function automatic logic [15:0] abs16(input logic signed [15:0] value);
        if (value == -16'sd32768)
            abs16 = 16'h7fff;
        else if (value < 0)
            abs16 = $unsigned(-value);
        else
            abs16 = $unsigned(value);
    endfunction
endpackage

`timescale 1ns/1ps
// 8x8 STDP, fully unrolled on the LEARN step. Same numeric law as the
// board-proven 4-agent matrix (TRACE_INCREMENT=32, LEARNING_SHIFT=2).
module stdp_matrix8 #(
    parameter int N = 8,
    parameter int TRACE_DECAY_SHIFT = 3,
    parameter logic [8:0] TRACE_INCREMENT = 9'd32,
    parameter int LEARNING_SHIFT = 2,
    parameter logic signed [15:0] INITIAL_CROSS_WEIGHT = 16'sd64,
    parameter logic signed [15:0] WEIGHT_LIMIT = 16'sd2047,
    parameter int DENSE_LEARNING_RATE = 8
) (
    input  logic clk,
    input  logic rst_n,
    input  logic clear_state,
    input  logic reset_weights,
    input  logic step,
    input  logic learn_enable,
    input  logic supervised_mode,
    input  logic freeze_weights,
    input  logic dense_mode,
    input  logic [N-1:0] pre_spikes,
    input  logic [N-1:0] post_spikes,
    input  logic [N-1:0] teacher_spikes,
    input  logic cfg_we,
    input  logic [2:0] cfg_dst,
    input  logic [2:0] cfg_src,
    input  logic signed [15:0] cfg_wdata,
    output logic signed [15:0] cfg_rdata,
    output logic signed [1023:0] weights_packed,
    output logic [63:0] pre_traces_packed,
    output logic [63:0] post_traces_packed,
    output logic update_applied,
    output logic [6:0] changed_cell_count
);
    logic signed [15:0] weights [0:7][0:7];
    logic [7:0] pre_trace [0:7];
    logic [7:0] post_trace [0:7];
    logic [7:0] pre_next [0:7];
    logic [7:0] post_next [0:7];
    logic signed [31:0] potentiation, depression, delta_value, updated_weight;
    logic signed [31:0] xs_pm1, td_pm1;
    logic signed [15:0] new_w;
    integer dst, src, ch;

    function automatic logic [7:0] trace_advance(
        input logic [7:0] trace_value,
        input logic spike_value
    );
        logic [8:0] decayed, advanced;
        begin
            decayed = {1'b0, trace_value} - ({1'b0, trace_value} >> TRACE_DECAY_SHIFT);
            advanced = spike_value ? decayed + TRACE_INCREMENT : decayed;
            trace_advance = (advanced > 9'd255) ? 8'hff : advanced[7:0];
        end
    endfunction

    always_comb begin
        weights_packed = '0;
        pre_traces_packed = '0;
        post_traces_packed = '0;
        for (src = 0; src < 8; src = src + 1) begin
            pre_next[src] = trace_advance(pre_trace[src], pre_spikes[src]);
            pre_traces_packed[src*8 +: 8] = pre_trace[src];
        end
        for (dst = 0; dst < 8; dst = dst + 1) begin
            post_next[dst] = trace_advance(post_trace[dst],
                supervised_mode ? teacher_spikes[dst] : post_spikes[dst]);
            post_traces_packed[dst*8 +: 8] = post_trace[dst];
            for (src = 0; src < 8; src = src + 1)
                weights_packed[(dst*8+src)*16 +: 16] = $unsigned(weights[dst][src]);
        end
        cfg_rdata = weights[cfg_dst][cfg_src];
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            update_applied <= 1'b0;
            changed_cell_count <= 7'd0;
            for (src = 0; src < 8; src = src + 1)
                pre_trace[src] <= 8'd0;
            for (dst = 0; dst < 8; dst = dst + 1) begin
                post_trace[dst] <= 8'd0;
                for (src = 0; src < 8; src = src + 1)
                    weights[dst][src] <= (dst == src) ? 16'sd0 : INITIAL_CROSS_WEIGHT;
            end
        end else begin
            update_applied <= 1'b0;
            if (reset_weights)
                changed_cell_count <= 7'd0;
            if (clear_state) begin
                for (src = 0; src < 8; src = src + 1)
                    pre_trace[src] <= 8'd0;
                for (dst = 0; dst < 8; dst = dst + 1)
                    post_trace[dst] <= 8'd0;
            end
            if (reset_weights) begin
                for (dst = 0; dst < 8; dst = dst + 1)
                    for (src = 0; src < 8; src = src + 1)
                        weights[dst][src] <= (dst == src) ? 16'sd0 : INITIAL_CROSS_WEIGHT;
            end else if (cfg_we) begin
                weights[cfg_dst][cfg_src] <= snn_math_pkg::clip_weight(
                    $signed({{16{cfg_wdata[15]}}, cfg_wdata}), WEIGHT_LIMIT);
            end else if (step) begin
                for (src = 0; src < 8; src = src + 1)
                    pre_trace[src] <= pre_next[src];
                for (dst = 0; dst < 8; dst = dst + 1)
                    post_trace[dst] <= post_next[dst];
                if (learn_enable && !freeze_weights) begin
                    if (dense_mode) begin
                        ch = 0;
                        for (dst = 0; dst < 8; dst = dst + 1) begin
                            for (src = 0; src < 8; src = src + 1) begin
                                td_pm1 = teacher_spikes[dst] ? 32'sd1 : -32'sd1;
                                xs_pm1 = pre_spikes[src] ? 32'sd1 : -32'sd1;
                                delta_value = $signed(DENSE_LEARNING_RATE) * td_pm1 * xs_pm1;
                                new_w = snn_math_pkg::clip_weight(
                                    $signed({{16{weights[dst][src][15]}}, weights[dst][src]}) + delta_value,
                                    WEIGHT_LIMIT);
                                if (new_w != weights[dst][src])
                                    ch = ch + 1;
                                weights[dst][src] <= new_w;
                            end
                        end
                        changed_cell_count <= ch[6:0];
                        update_applied <= 1'b1;
                    end else begin
                        for (dst = 0; dst < 8; dst = dst + 1) begin
                            for (src = 0; src < 8; src = src + 1) begin
                                if (dst != src) begin
                                    if (supervised_mode) begin
                                        potentiation = (teacher_spikes[dst] && pre_spikes[src])
                                            ? $signed({23'd0, TRACE_INCREMENT}) : 32'sd0;
                                        depression = (post_spikes[dst] && !teacher_spikes[dst] && pre_spikes[src])
                                            ? $signed({23'd0, TRACE_INCREMENT}) : 32'sd0;
                                    end else begin
                                        potentiation = post_spikes[dst]
                                            ? $signed({1'b0, pre_next[src]}) : 32'sd0;
                                        depression = pre_spikes[src]
                                            ? $signed({1'b0, post_next[dst]}) : 32'sd0;
                                    end
                                    delta_value = (potentiation - depression) >>> LEARNING_SHIFT;
                                    updated_weight = $signed({{16{weights[dst][src][15]}}, weights[dst][src]})
                                                   + delta_value;
                                    weights[dst][src] <= snn_math_pkg::clip_weight(updated_weight, WEIGHT_LIMIT);
                                end
                            end
                        end
                        update_applied <= 1'b1;
                    end
                end
            end
        end
    end
endmodule

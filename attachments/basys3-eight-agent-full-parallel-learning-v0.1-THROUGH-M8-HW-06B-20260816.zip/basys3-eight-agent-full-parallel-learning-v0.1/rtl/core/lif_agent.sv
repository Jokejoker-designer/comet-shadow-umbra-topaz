`timescale 1ns/1ps
module lif_agent #(
    parameter logic signed [15:0] MEM_MIN = -16'sd8192,
    parameter logic signed [15:0] MEM_MAX =  16'sd8191
) (
    input  logic               clk,
    input  logic               rst_n,
    input  logic               clear_state,
    input  logic               step,
    input  logic signed [15:0] input_current,
    input  logic signed [15:0] threshold,
    input  logic [3:0]         leak_shift,
    output logic               spike,
    output logic signed [15:0] membrane
);
    logic signed [31:0] membrane_ext;
    logic signed [31:0] current_ext;
    logic signed [31:0] threshold_ext;
    logic signed [31:0] mem_min_ext;
    logic signed [31:0] mem_max_ext;
    logic signed [31:0] leaked;
    logic signed [31:0] next_value;
    logic signed [31:0] after_spike;

    always_comb begin
        membrane_ext = $signed({{16{membrane[15]}}, membrane});
        current_ext = $signed({{16{input_current[15]}}, input_current});
        threshold_ext = $signed({{16{threshold[15]}}, threshold});
        mem_min_ext = $signed({{16{MEM_MIN[15]}}, MEM_MIN});
        mem_max_ext = $signed({{16{MEM_MAX[15]}}, MEM_MAX});

        leaked = (leak_shift == 0)
               ? membrane_ext
               : membrane_ext - (membrane_ext >>> leak_shift);
        next_value = leaked + current_ext;
        after_spike = next_value - threshold_ext;
    end

    always_ff @(posedge clk) begin
        if (!rst_n || clear_state) begin
            membrane <= 16'sd0;
            spike <= 1'b0;
        end else if (step) begin
            if (next_value >= threshold_ext) begin
                spike <= 1'b1;
                if (after_spike > mem_max_ext) membrane <= MEM_MAX;
                else if (after_spike < mem_min_ext) membrane <= MEM_MIN;
                else membrane <= $signed(after_spike[15:0]);
            end else begin
                spike <= 1'b0;
                if (next_value > mem_max_ext) membrane <= MEM_MAX;
                else if (next_value < mem_min_ext) membrane <= MEM_MIN;
                else membrane <= $signed(next_value[15:0]);
            end
        end else begin
            spike <= 1'b0;
        end
    end
endmodule

`timescale 1ns/1ps
module eight_agent_snn_core #(
    parameter logic signed [15:0] EXTERNAL_CURRENT = 16'sd0,
    parameter int ATTENTION_BACKEND = 1
) (
    input  logic clk,
    input  logic rst_n,
    input  logic start,
    input  logic clear_state,
    input  logic reset_weights,
    input  logic learn_enable,
    input  logic supervised_mode,
    input  logic freeze_weights,
    input  logic dense_mode,
    input  logic [7:0] direct_spikes,
    input  logic [7:0] teacher_spikes,
    input  logic signed [15:0] threshold,
    input  logic [3:0] leak_shift,
    input  logic [2:0] cfg_dst,
    input  logic [2:0] cfg_src,
    output logic signed [15:0] cfg_rdata,
    output logic busy,
    output logic done,
    output logic [7:0] encoded_spikes,
    output logic [7:0] output_spikes,
    output logic update_applied,
    output logic [31:0] tick_count,
    output logic [31:0] update_count,
    output logic [31:0] mismatch_count,
    output logic signed [1023:0] weights_packed,
    output logic [6:0] changed_cell_count
);
    typedef enum logic [2:0] {IDLE, ATTEND, NEURON, LEARN, FINISH} state_t;
    state_t state;
    logic [7:0] direct_reg, teacher_reg, source_spikes_reg;
    logic learn_reg, supervised_reg, freeze_reg;
    // weights_packed is a port; matrix drives it.
    logic signed [127:0] context_comb, context_reg;
    logic signed [15:0] input_current [0:7];
    logic signed [15:0] membrane_wire [0:7];
    logic [7:0] output_spikes_live, output_spikes_latched;
    logic signed [127:0] membranes_packed;
    logic [63:0] pre_traces_packed, post_traces_packed;
    logic [23:0] dominant_sources;
    logic stdp_update;
    logic [31:0] mismatch_this_tick;
    integer i;
    genvar g;

    assign output_spikes = output_spikes_latched;
    assign busy = (state != IDLE) && (state != FINISH);
    assign done = (state == FINISH);
    assign encoded_spikes = source_spikes_reg;
    assign update_applied = stdp_update;

    generate
        for (g = 0; g < 8; g = g + 1) begin : GEN_MEM_PACK
            assign membranes_packed[g*16 +: 16] = $unsigned(membrane_wire[g]);
        end
    endgenerate

    attention_gate8 #(.ATTENTION_BACKEND(ATTENTION_BACKEND)) attention (
        .source_spikes(direct_reg),
        .weights_packed(weights_packed),
        .context_packed(context_comb),
        .dominant_sources(dominant_sources)
    );

    always_comb begin
        for (i = 0; i < 8; i = i + 1) begin
            input_current[i] = $signed(context_reg[i*16 +: 16]);
            if (source_spikes_reg[i] && (EXTERNAL_CURRENT != 0))
                input_current[i] = snn_math_pkg::sat16(
                    $signed(input_current[i]) + $signed(EXTERNAL_CURRENT));
        end
    end

    generate
        for (g = 0; g < 8; g = g + 1) begin : GEN_LIF
            lif_agent neuron (
                .clk(clk), .rst_n(rst_n), .clear_state(clear_state),
                .step(state == NEURON), .input_current(input_current[g]),
                .threshold(threshold), .leak_shift(leak_shift),
                .spike(output_spikes_live[g]), .membrane(membrane_wire[g])
            );
        end
    endgenerate

    stdp_matrix8 matrix (
        .clk(clk), .rst_n(rst_n), .clear_state(clear_state),
        .reset_weights(reset_weights), .step(state == LEARN),
        .learn_enable(learn_reg), .supervised_mode(supervised_reg),
        .freeze_weights(freeze_reg), .dense_mode(dense_mode),
        .pre_spikes(source_spikes_reg),
        .post_spikes(output_spikes_live), .teacher_spikes(teacher_reg),
        .cfg_we(1'b0), .cfg_dst(cfg_dst), .cfg_src(cfg_src),
        .cfg_wdata(16'sd0), .cfg_rdata(cfg_rdata),
        .weights_packed(weights_packed),
        .pre_traces_packed(pre_traces_packed),
        .post_traces_packed(post_traces_packed),
        .update_applied(stdp_update),
        .changed_cell_count(changed_cell_count)
    );

    always_comb begin
        mismatch_this_tick = 32'd0;
        for (i = 0; i < 8; i = i + 1)
            if (output_spikes_live[i] != teacher_reg[i])
                mismatch_this_tick = mismatch_this_tick + 1;
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= IDLE;
            direct_reg <= '0; teacher_reg <= '0;
            learn_reg <= 1'b0; supervised_reg <= 1'b0; freeze_reg <= 1'b0;
            source_spikes_reg <= '0; context_reg <= '0;
            output_spikes_latched <= 8'd0;
            tick_count <= 0; update_count <= 0; mismatch_count <= 0;
        end else begin
            if (clear_state)
                output_spikes_latched <= 8'd0;
            case (state)
                IDLE: if (start) begin
                    direct_reg <= direct_spikes;
                    teacher_reg <= teacher_spikes;
                    learn_reg <= learn_enable;
                    supervised_reg <= supervised_mode;
                    freeze_reg <= freeze_weights;
                    state <= ATTEND;
                end
                ATTEND: begin
                    source_spikes_reg <= direct_reg;
                    context_reg <= context_comb;
                    state <= NEURON;
                end
                NEURON: state <= LEARN;
                LEARN: begin
                    output_spikes_latched <= output_spikes_live;
                    tick_count <= tick_count + 1;
                    if (learn_reg && !freeze_reg) update_count <= update_count + 1;
                    if (supervised_reg) mismatch_count <= mismatch_count + mismatch_this_tick;
                    state <= FINISH;
                end
                FINISH: state <= IDLE;
                default: state <= IDLE;
            endcase
        end
    end
endmodule

`timescale 1ns/1ps
// Order-sensitive context + plastic readout. No A/B/C/X constants.
// ctx := rotl(ctx,3) ^ stim ^ rotl(stim,2)
// TRAIN last step: ΔW[d][s] = LR × (±teacher[d]) × (±ctx[s])
module temporal_context8 #(
    parameter int LR = 8,
    parameter logic signed [15:0] WEIGHT_LIMIT = 16'sd2047
) (
    input  logic clk,
    input  logic rst_n,
    input  logic clear_ctx,
    input  logic reset_weights,
    input  logic step,
    input  logic learn,
    input  logic [7:0] stim,
    input  logic [7:0] teacher,
    output logic [7:0] ctx,
    output logic [7:0] out_spikes,
    output logic signed [1023:0] weights_packed
);
    logic signed [15:0] weights [0:7][0:7];
    logic [7:0] ctx_q;
    logic [7:0] ctx_next;
    logic signed [31:0] energy [0:7];
    logic signed [31:0] acc_c, xs_c, xs_f, td_f;
    logic signed [15:0] new_w;
    integer d_c, s_c, d_f, s_f;

    always_comb begin
        ctx_next = {ctx_q[4:0], ctx_q[7:5]} ^ stim ^ {stim[5:0], stim[7:6]};
        ctx = ctx_q;
        out_spikes = 8'd0;
        weights_packed = '0;
        for (d_c = 0; d_c < 8; d_c = d_c + 1) begin
            acc_c = 32'sd0;
            for (s_c = 0; s_c < 8; s_c = s_c + 1) begin
                weights_packed[(d_c*8+s_c)*16 +: 16] = $unsigned(weights[d_c][s_c]);
                xs_c = ctx_q[s_c] ? 32'sd1 : -32'sd1;
                acc_c = acc_c + $signed({{16{weights[d_c][s_c][15]}}, weights[d_c][s_c]}) * xs_c;
            end
            energy[d_c] = acc_c;
            out_spikes[d_c] = (acc_c > 32'sd0);
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            ctx_q <= 8'd0;
            for (d_f = 0; d_f < 8; d_f = d_f + 1)
                for (s_f = 0; s_f < 8; s_f = s_f + 1)
                    weights[d_f][s_f] <= 16'sd0;
        end else begin
            if (reset_weights) begin
                for (d_f = 0; d_f < 8; d_f = d_f + 1)
                    for (s_f = 0; s_f < 8; s_f = s_f + 1)
                        weights[d_f][s_f] <= 16'sd0;
            end
            if (clear_ctx)
                ctx_q <= 8'd0;
            else if (step) begin
                ctx_q <= ctx_next;
                if (learn) begin
                    for (d_f = 0; d_f < 8; d_f = d_f + 1) begin
                        for (s_f = 0; s_f < 8; s_f = s_f + 1) begin
                            td_f = teacher[d_f] ? 32'sd1 : -32'sd1;
                            xs_f = ctx_next[s_f] ? 32'sd1 : -32'sd1;
                            new_w = snn_math_pkg::clip_weight(
                                $signed({{16{weights[d_f][s_f][15]}}, weights[d_f][s_f]})
                                + $signed(LR) * td_f * xs_f,
                                WEIGHT_LIMIT);
                            weights[d_f][s_f] <= new_w;
                        end
                    end
                end
            end
        end
    end
endmodule

`timescale 1ns/1ps
module pulse_density_encoder (
    input  logic       clk,
    input  logic       rst_n,
    input  logic       clear_state,
    input  logic       step,
    input  logic [7:0] level,
    output logic       spike,
    output logic [7:0] accumulator
);
    logic [8:0] sum_value;
    always_comb sum_value = {1'b0, accumulator} + {1'b0, level};

    always_ff @(posedge clk) begin
        if (!rst_n || clear_state) begin
            accumulator <= 8'd0;
            spike <= 1'b0;
        end else if (step) begin
            accumulator <= sum_value[7:0];
            spike <= sum_value[8];
        end else begin
            spike <= 1'b0;
        end
    end
endmodule

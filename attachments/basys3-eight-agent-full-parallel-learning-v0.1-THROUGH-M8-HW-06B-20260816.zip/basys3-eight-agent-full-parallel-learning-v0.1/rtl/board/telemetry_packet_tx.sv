`timescale 1ns/1ps
module telemetry_packet_tx #(
    parameter int CLK_HZ = 8000000,
    parameter int BAUD = 115200
) (
    input  logic clk,
    input  logic rst_n,
    input  logic trigger,
    input  logic [31:0] tick_count,
    input  logic [31:0] update_count,
    input  logic [31:0] mismatch_count,
    input  logic signed [15:0] selected_weight,
    input  logic [7:0] encoded_spikes,
    input  logic [7:0] output_spikes,
    input  logic [7:0] flags,
    input  logic [3:0] sup_phase,
    input  logic result_trigger,
    input  logic [15:0] before_mismatch,
    input  logic [15:0] after_mismatch,
    input  logic [7:0] before_acc,
    input  logic [7:0] after_acc,
    input  logic [7:0] route_pass,
    input  logic freeze_pass,
    input  logic final_pass,
    input  logic dump_start,
    input  logic [7:0] snapshot_id,
    input  logic signed [1023:0] weights_packed,
    input  logic session_echo,
    input  logic [31:0] session_seed,
    input  logic [63:0] perm_packed,
    input  logic dense_event,
    input  logic [7:0] dense_stim,
    input  logic [7:0] dense_teacher,
    input  logic [6:0] changed_cell_count,
    input  logic dense_learn,
    input  logic dense_freeze,
    input  logic temp_event,
    input  logic [7:0] temp_ctx,
    input  logic [7:0] temp_out,
    input  logic [7:0] temp_target,
    output logic tx,
    output logic packet_busy,
    output logic dump_busy,
    output logic dump_done
);
    logic [7:0] frame [0:14];
    logic [3:0] index;
    logic tx_start;
    logic [7:0] tx_data;
    logic uart_busy;
    logic [4:0] dump_page;
    logic dump_active;
    logic dump_req;
    logic dense_req;
    logic temp_req;
    logic [7:0] temp_ctx_l, temp_out_l, temp_tgt_l, temp_phase_l, temp_snap_l;
    logic [7:0] dens_stim_l, dens_teach_l, dens_flags_l, dens_snap_l;
    logic [6:0] dens_ch_l;
    logic [15:0] w0, w1, w2, w3;
    integer i;

    uart_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) uart_i (
        .clk(clk), .rst_n(rst_n), .start(tx_start), .data(tx_data),
        .tx(tx), .busy(uart_busy)
    );

    function automatic logic [7:0] xor_frame;
        input logic [7:0] f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13;
        begin
            xor_frame = f0 ^ f1 ^ f2 ^ f3 ^ f4 ^ f5 ^ f6 ^ f7 ^ f8 ^ f9 ^ f10 ^ f11 ^ f12 ^ f13;
        end
    endfunction

    always_comb begin
        w0 = weights_packed[({dump_page, 2'b00} + 5'd0)*16 +: 16];
        w1 = weights_packed[({dump_page, 2'b00} + 5'd1)*16 +: 16];
        w2 = weights_packed[({dump_page, 2'b00} + 5'd2)*16 +: 16];
        w3 = weights_packed[({dump_page, 2'b00} + 5'd3)*16 +: 16];
    end

    assign dump_busy = dump_active;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            packet_busy <= 1'b0;
            index <= 4'd0;
            tx_start <= 1'b0;
            tx_data <= 8'd0;
            dump_active <= 1'b0;
            dump_req <= 1'b0;
            dense_req <= 1'b0;
            temp_req <= 1'b0;
            dump_page <= 5'd0;
            dump_done <= 1'b0;
            for (i = 0; i < 15; i = i + 1) frame[i] <= 8'd0;
        end else begin
            tx_start <= 1'b0;
            dump_done <= 1'b0;
            if (dump_start)
                dump_req <= 1'b1;
            if (temp_event) begin
                temp_req <= 1'b1;
                temp_ctx_l <= temp_ctx;
                temp_out_l <= temp_out;
                temp_tgt_l <= temp_target;
                temp_phase_l <= {4'd0, sup_phase};
                temp_snap_l <= snapshot_id;
            end
            if (dense_event) begin
                dense_req <= 1'b1;
                dens_stim_l <= dense_stim;
                dens_teach_l <= dense_teacher;
                dens_ch_l <= changed_cell_count;
                dens_flags_l <= {6'd0, dense_freeze, dense_learn};
                dens_snap_l <= snapshot_id;
            end
            if (dump_req && !dump_active && !packet_busy && !uart_busy && !tx_start) begin
                dump_active <= 1'b1;
                dump_req <= 1'b0;
                dump_page <= 5'd0;
            end
            if (!packet_busy && !uart_busy && !tx_start) begin
                if (dump_active) begin
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h5D;
                    frame[2] <= snapshot_id;
                    frame[3] <= {3'd0, dump_page};
                    frame[4] <= {3'd0, dump_page};
                    frame[5] <= w0[7:0];
                    frame[6] <= w0[15:8];
                    frame[7] <= w1[7:0];
                    frame[8] <= w1[15:8];
                    frame[9] <= w2[7:0];
                    frame[10] <= w2[15:8];
                    frame[11] <= w3[7:0];
                    frame[12] <= w3[15:8];
                    frame[13] <= {4'd0, sup_phase};
                    frame[14] <= xor_frame(8'hA5, 8'h5D, snapshot_id,
                        {3'd0, dump_page}, {3'd0, dump_page},
                        w0[7:0], w0[15:8], w1[7:0], w1[15:8],
                        w2[7:0], w2[15:8], w3[7:0], w3[15:8],
                        {4'd0, sup_phase});
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end else if (session_echo) begin
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h5E;
                    frame[2] <= session_seed[7:0];
                    frame[3] <= session_seed[15:8];
                    frame[4] <= session_seed[23:16];
                    frame[5] <= session_seed[31:24];
                    frame[6] <= perm_packed[7:0];
                    frame[7] <= perm_packed[15:8];
                    frame[8] <= perm_packed[23:16];
                    frame[9] <= perm_packed[31:24];
                    frame[10] <= perm_packed[39:32];
                    frame[11] <= perm_packed[47:40];
                    frame[12] <= perm_packed[55:48];
                    frame[13] <= perm_packed[63:56];
                    frame[14] <= xor_frame(8'hA5, 8'h5E,
                        session_seed[7:0], session_seed[15:8],
                        session_seed[23:16], session_seed[31:24],
                        perm_packed[7:0], perm_packed[15:8],
                        perm_packed[23:16], perm_packed[31:24],
                        perm_packed[39:32], perm_packed[47:40],
                        perm_packed[55:48], perm_packed[63:56]);
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end else if (temp_req) begin
                    temp_req <= 1'b0;
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h64;
                    frame[2] <= temp_ctx_l;
                    frame[3] <= temp_out_l;
                    frame[4] <= temp_tgt_l;
                    frame[5] <= {7'd0, (temp_out_l == temp_tgt_l)};
                    frame[6] <= temp_phase_l;
                    frame[7] <= temp_snap_l;
                    frame[8] <= 8'd0;
                    frame[9] <= 8'd0;
                    frame[10] <= 8'd0;
                    frame[11] <= 8'd0;
                    frame[12] <= 8'd0;
                    frame[13] <= 8'd0;
                    frame[14] <= xor_frame(8'hA5, 8'h64, temp_ctx_l, temp_out_l,
                        temp_tgt_l, {7'd0, (temp_out_l == temp_tgt_l)},
                        temp_phase_l, temp_snap_l, 8'd0, 8'd0, 8'd0, 8'd0, 8'd0, 8'd0);
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end else if (dense_req) begin
                    dense_req <= 1'b0;
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h61;
                    frame[2] <= dens_stim_l;
                    frame[3] <= dens_teach_l;
                    frame[4] <= {1'b0, dens_ch_l};
                    frame[5] <= dens_flags_l;
                    frame[6] <= tick_count[7:0];
                    frame[7] <= tick_count[15:8];
                    frame[8] <= update_count[7:0];
                    frame[9] <= update_count[15:8];
                    frame[10] <= {4'd0, sup_phase};
                    frame[11] <= flags;
                    frame[12] <= dens_snap_l;
                    frame[13] <= 8'd0;
                    frame[14] <= xor_frame(8'hA5, 8'h61, dens_stim_l, dens_teach_l,
                        {1'b0, dens_ch_l}, dens_flags_l,
                        tick_count[7:0], tick_count[15:8],
                        update_count[7:0], update_count[15:8],
                        {4'd0, sup_phase}, flags, dens_snap_l, 8'd0);
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end else if (result_trigger) begin
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h5C;
                    frame[2] <= before_mismatch[7:0];
                    frame[3] <= before_mismatch[15:8];
                    frame[4] <= after_mismatch[7:0];
                    frame[5] <= after_mismatch[15:8];
                    frame[6] <= before_acc;
                    frame[7] <= after_acc;
                    frame[8] <= route_pass;
                    frame[9] <= {final_pass, freeze_pass, 2'b00, sup_phase};
                    frame[10] <= update_count[7:0];
                    frame[11] <= update_count[15:8];
                    frame[12] <= tick_count[7:0];
                    frame[13] <= tick_count[15:8];
                    frame[14] <= xor_frame(8'hA5, 8'h5C,
                        before_mismatch[7:0], before_mismatch[15:8],
                        after_mismatch[7:0], after_mismatch[15:8],
                        before_acc, after_acc, route_pass,
                        {final_pass, freeze_pass, 2'b00, sup_phase},
                        update_count[7:0], update_count[15:8],
                        tick_count[7:0], tick_count[15:8]);
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end else if (trigger) begin
                    frame[0] <= 8'hA5;
                    frame[1] <= 8'h5A;
                    frame[2] <= tick_count[7:0];
                    frame[3] <= tick_count[15:8];
                    frame[4] <= update_count[7:0];
                    frame[5] <= update_count[15:8];
                    frame[6] <= mismatch_count[7:0];
                    frame[7] <= mismatch_count[15:8];
                    frame[8] <= selected_weight[7:0];
                    frame[9] <= selected_weight[15:8];
                    frame[10] <= encoded_spikes;
                    frame[11] <= output_spikes;
                    frame[12] <= {4'd0, sup_phase};
                    frame[13] <= flags;
                    frame[14] <= xor_frame(8'hA5, 8'h5A,
                        tick_count[7:0], tick_count[15:8],
                        update_count[7:0], update_count[15:8],
                        mismatch_count[7:0], mismatch_count[15:8],
                        selected_weight[7:0], selected_weight[15:8],
                        encoded_spikes, output_spikes,
                        {4'd0, sup_phase}, flags);
                    packet_busy <= 1'b1;
                    index <= 4'd0;
                end
            end else if (packet_busy && !uart_busy && !tx_start) begin
                tx_data <= frame[index];
                tx_start <= 1'b1;
                if (index == 4'd14) begin
                    packet_busy <= 1'b0;
                    index <= 4'd0;
                    if (dump_active) begin
                        if (dump_page == 5'd15) begin
                            dump_active <= 1'b0;
                            dump_done <= 1'b1;
                            dump_page <= 5'd0;
                        end else dump_page <= dump_page + 5'd1;
                    end
                end else index <= index + 1'b1;
            end
        end
    end
endmodule

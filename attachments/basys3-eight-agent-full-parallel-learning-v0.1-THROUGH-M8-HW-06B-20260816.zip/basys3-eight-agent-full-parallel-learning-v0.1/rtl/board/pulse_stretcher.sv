`timescale 1ns/1ps
module pulse_stretcher #(
    parameter int CYCLES = 625000
) (
    input  logic clk,
    input  logic rst_n,
    input  logic pulse_in,
    output logic level_out
);
    localparam int CW = (CYCLES <= 1) ? 1 : $clog2(CYCLES+1);
    logic [CW-1:0] count;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            count <= '0;
            level_out <= 1'b0;
        end else if (pulse_in) begin
            count <= CYCLES;
            level_out <= 1'b1;
        end else if (count != 0) begin
            count <= count - 1'b1;
            level_out <= 1'b1;
        end else begin
            level_out <= 1'b0;
        end
    end
endmodule

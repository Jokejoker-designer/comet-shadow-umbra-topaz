`timescale 1ns/1ps
// M8-HW-02 supervisor. Integer hit counters only (no % / DSP on FPGA).
// Teacher into the core is isolated in the board top: core_teacher=0 off TRAIN.
// score_teacher is for the scorer only.
module eval_supervisor8 #(
    parameter int EVAL_TICKS = 32,
    parameter int TRAIN_TICKS_REMAP = 256,
    parameter int TRAIN_TICKS_CYCLIC = 1024,
    parameter int HOLD_TICKS = 32
) (
    input  logic clk,
    input  logic rst_n,
    input  logic enable,
    input  logic cyclic_mode,
    input  logic session_valid,
    input  logic start_cmd,
    input  logic reset_cmd,
    input  logic core_done,
    input  logic [7:0] source_spikes,
    input  logic [7:0] score_teacher,
    input  logic [7:0] output_spikes,
    input  logic sw_freeze,
    input  logic uart_idle,
    input  logic dump_done,
    output logic trainer_enable,
    output logic learn_enable,
    output logic freeze_weights,
    output logic clear_pulse,
    output logic reset_weights,
    output logic dump_start,
    output logic [7:0] snapshot_id,
    output logic [3:0] phase,
    output logic [15:0] before_hits,
    output logic [15:0] after_hits,
    output logic [15:0] forget_hits,
    output logic [15:0] before_mismatch,
    output logic [15:0] after_mismatch,
    output logic [7:0] before_acc,
    output logic [7:0] after_acc,
    output logic [7:0] route_pass,
    output logic freeze_pass,
    output logic final_pass,
    output logic result_strobe
);
    typedef enum logic [3:0] {
        ST_IDLE     = 4'd0,
        ST_EVAL_B   = 4'd1,
        ST_TRAIN    = 4'd2,
        ST_EVAL_A   = 4'd3,
        ST_HOLD     = 4'd4,
        ST_DUMP     = 4'd5,
        ST_WAIT     = 4'd6,
        ST_RST      = 4'd7,
        ST_RST_DUMP = 4'd8,
        ST_FORGET   = 4'd9
    } state_t;

    state_t state;
    logic [15:0] tick_i;
    logic [15:0] exact_hits;
    logic [15:0] bit_mismatch;
    logic [7:0] route_hits [0:7];
    logic [7:0] route_trials [0:7];
    logic [2:0] src_idx;
    logic [7:0] xor_bits;
    logic [3:0] bit_mis_n;
    logic exact;
    logic [15:0] train_limit;
    integer ci, ri;

    always_comb begin
        src_idx = 3'd0;
        for (ci = 0; ci < 8; ci = ci + 1)
            if (source_spikes[ci])
                src_idx = ci[2:0];
        xor_bits = output_spikes ^ score_teacher;
        bit_mis_n = xor_bits[0]+xor_bits[1]+xor_bits[2]+xor_bits[3]
                  + xor_bits[4]+xor_bits[5]+xor_bits[6]+xor_bits[7];
        exact = (output_spikes == score_teacher);
        train_limit = cyclic_mode ? TRAIN_TICKS_CYCLIC[15:0] : TRAIN_TICKS_REMAP[15:0];
    end

    assign phase = state;
    assign trainer_enable = enable && (
        (state == ST_EVAL_B) || (state == ST_TRAIN) ||
        (state == ST_EVAL_A) || (state == ST_HOLD) ||
        (state == ST_FORGET));
    assign learn_enable = (state == ST_TRAIN) && !sw_freeze;
    assign freeze_weights = (state != ST_TRAIN) || sw_freeze;

    always_comb begin
        for (ci = 0; ci < 8; ci = ci + 1)
            route_pass[ci] = (route_trials[ci] != 8'd0)
                          && (route_hits[ci] > (route_trials[ci] >> 1));
    end
    assign freeze_pass = (state == ST_HOLD) || (state == ST_DUMP)
                      || (state == ST_WAIT) || (state == ST_FORGET);
    assign final_pass = (after_hits == EVAL_TICKS[15:0]) && freeze_pass
                     && (after_hits > before_hits);

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            tick_i <= 16'd0;
            exact_hits <= 16'd0;
            bit_mismatch <= 16'd0;
            before_hits <= 16'd0;
            after_hits <= 16'd0;
            forget_hits <= 16'd0;
            before_mismatch <= 16'd0;
            after_mismatch <= 16'd0;
            before_acc <= 8'd0;
            after_acc <= 8'd0;
            result_strobe <= 1'b0;
            clear_pulse <= 1'b0;
            reset_weights <= 1'b0;
            dump_start <= 1'b0;
            snapshot_id <= 8'd0;
            for (ri = 0; ri < 8; ri = ri + 1) begin
                route_hits[ri] <= 8'd0;
                route_trials[ri] <= 8'd0;
            end
        end else begin
            result_strobe <= 1'b0;
            clear_pulse <= 1'b0;
            reset_weights <= 1'b0;
            dump_start <= 1'b0;
            if (!enable) begin
                state <= ST_IDLE;
            end else if (start_cmd && (state == ST_IDLE || state == ST_WAIT)
                         && (cyclic_mode || session_valid)) begin
                `ifndef SYNTHESIS
                $display("SUP START accept t=%0t state=%0d", $time, state);
                `endif
                state <= ST_EVAL_B;
                tick_i <= 16'd0;
                exact_hits <= 16'd0;
                bit_mismatch <= 16'd0;
                before_hits <= 16'd0;
                after_hits <= 16'd0;
                clear_pulse <= 1'b1;
                for (ri = 0; ri < 8; ri = ri + 1) begin
                    route_hits[ri] <= 8'd0;
                    route_trials[ri] <= 8'd0;
                end
            end else if (reset_cmd && !cyclic_mode &&
                         (state == ST_WAIT || state == ST_DUMP || state == ST_HOLD)) begin
                state <= ST_RST;
                reset_weights <= 1'b1;
                clear_pulse <= 1'b1;
                `ifndef SYNTHESIS
                $display("SUP RESET accept t=%0t state=%0d", $time, state);
                `endif
            end else begin
                case (state)
                    ST_EVAL_B: if (core_done) begin
                        exact_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                        bit_mismatch <= bit_mismatch + {12'd0, bit_mis_n};
                        route_trials[src_idx] <= route_trials[src_idx] + 8'd1;
                        if (exact) route_hits[src_idx] <= route_hits[src_idx] + 8'd1;
                        if (tick_i == EVAL_TICKS[15:0] - 16'd1) begin
                            before_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                            before_mismatch <= bit_mismatch + {12'd0, bit_mis_n};
                            before_acc <= exact_hits[7:0] + (exact ? 8'd1 : 8'd0);
                            tick_i <= 16'd0;
                            exact_hits <= 16'd0;
                            bit_mismatch <= 16'd0;
                            clear_pulse <= 1'b1;
                            for (ri = 0; ri < 8; ri = ri + 1) begin
                                route_hits[ri] <= 8'd0;
                                route_trials[ri] <= 8'd0;
                            end
                            state <= ST_TRAIN;
                        end else tick_i <= tick_i + 16'd1;
                    end
                    ST_TRAIN: if (core_done) begin
                        if (tick_i == train_limit - 16'd1) begin
                            tick_i <= 16'd0;
                            clear_pulse <= 1'b1;
                            state <= ST_EVAL_A;
                        end else tick_i <= tick_i + 16'd1;
                    end
                    ST_EVAL_A: if (core_done) begin
                        exact_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                        bit_mismatch <= bit_mismatch + {12'd0, bit_mis_n};
                        route_trials[src_idx] <= route_trials[src_idx] + 8'd1;
                        if (exact) route_hits[src_idx] <= route_hits[src_idx] + 8'd1;
                        if (tick_i == EVAL_TICKS[15:0] - 16'd1) begin
                            after_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                            after_mismatch <= bit_mismatch + {12'd0, bit_mis_n};
                            after_acc <= exact_hits[7:0] + (exact ? 8'd1 : 8'd0);
                            tick_i <= 16'd0;
                            exact_hits <= 16'd0;
                            result_strobe <= 1'b1;
                            state <= ST_HOLD;
                        end else tick_i <= tick_i + 16'd1;
                    end
                    ST_HOLD: if (cyclic_mode) begin
                    end else if (core_done) begin
                        if (tick_i == HOLD_TICKS[15:0] - 16'd1) begin
                            tick_i <= 16'd0;
                            state <= ST_DUMP;
                            dump_start <= 1'b1;
                            snapshot_id <= snapshot_id + 8'd1;
                        end else tick_i <= tick_i + 16'd1;
                    end
                    ST_DUMP: if (dump_done)
                        state <= ST_WAIT;
                    ST_WAIT: ;
                    ST_RST: begin
                        state <= ST_RST_DUMP;
                        dump_start <= 1'b1;
                        snapshot_id <= snapshot_id + 8'd1;
                        `ifndef SYNTHESIS
                        $display("SUP ST_RST -> RST_DUMP t=%0t", $time);
                        `endif
                    end
                    ST_RST_DUMP: if (dump_done) begin
                        tick_i <= 16'd0;
                        exact_hits <= 16'd0;
                        state <= ST_FORGET;
                        `ifndef SYNTHESIS
                        $display("SUP RST_DUMP done -> FORGET t=%0t", $time);
                        `endif
                    end
                    ST_FORGET: if (core_done) begin
                        exact_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                        if (tick_i == EVAL_TICKS[15:0] - 16'd1) begin
                            forget_hits <= exact_hits + (exact ? 16'd1 : 16'd0);
                            state <= ST_WAIT;
                        end else tick_i <= tick_i + 16'd1;
                    end
                    default: state <= ST_IDLE;
                endcase
            end
        end
    end
endmodule

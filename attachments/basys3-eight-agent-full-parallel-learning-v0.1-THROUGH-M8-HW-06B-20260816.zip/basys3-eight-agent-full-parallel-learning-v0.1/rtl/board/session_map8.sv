`timescale 1ns/1ps
// Combinational teacher from a host-loaded permutation register.
// dest = perm[src]; no semantic roles.
module session_map8 (
    input  logic [63:0] perm_packed,
    input  logic [7:0] source_spikes,
    output logic [7:0] score_teacher
);
    logic [2:0] dest;
    logic [2:0] src_idx;
    integer r;

    always_comb begin
        src_idx = 3'd0;
        for (r = 0; r < 8; r = r + 1)
            if (source_spikes[r])
                src_idx = r[2:0];
        dest = perm_packed[src_idx*8 +: 3];
        score_teacher = 8'h01 << dest;
    end
endmodule

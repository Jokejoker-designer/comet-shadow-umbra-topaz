`timescale 1ns/1ps
// Host-stepped M8-HW-03: RESET → one dense TRAIN → FREEZE + 32 infer.
// No cyclic/remap schedule. One start_pulse == one core transaction.
module dense_supervisor8 #(
    parameter int INFER_TICKS = 32
) (
    input  logic clk,
    input  logic rst_n,
    input  logic enable,
    input  logic sample_valid,
    input  logic [7:0] stim,
    input  logic [7:0] teacher,
    input  logic train_cmd,
    input  logic freeze_infer_cmd,
    input  logic reset_cmd,
    input  logic core_busy,
    input  logic core_done,
    input  logic [6:0] changed_from_core,
    output logic [7:0] source_spikes,
    output logic [7:0] score_teacher,
    output logic start_pulse,
    output logic learn_enable,
    output logic freeze_weights,
    output logic clear_pulse,
    output logic reset_weights,
    output logic event_strobe,
    output logic [7:0] snapshot_id,
    output logic [3:0] phase,
    output logic [6:0] last_changed,
    output logic [7:0] last_stim,
    output logic [7:0] last_teacher
);
    typedef enum logic [3:0] {
        ST_IDLE    = 4'd0,
        ST_READY   = 4'd1,
        ST_ARMED   = 4'd2,
        ST_TRAIN   = 4'd3,
        ST_AFTER   = 4'd4,
        ST_INFER   = 4'd5,
        ST_FREEZE  = 4'd6,
        ST_DONE    = 4'd7
    } state_t;

    state_t state;
    logic [5:0] infer_i;

    assign source_spikes = stim;
    assign score_teacher = teacher;
    assign phase = state;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            start_pulse <= 1'b0;
            learn_enable <= 1'b0;
            freeze_weights <= 1'b1;
            clear_pulse <= 1'b0;
            reset_weights <= 1'b0;
            event_strobe <= 1'b0;
            snapshot_id <= 8'd1;
            last_changed <= 7'd0;
            last_stim <= 8'd0;
            last_teacher <= 8'd0;
            infer_i <= 6'd0;
        end else begin
            start_pulse <= 1'b0;
            clear_pulse <= 1'b0;
            reset_weights <= 1'b0;
            event_strobe <= 1'b0;
            if (!enable) begin
                state <= ST_IDLE;
                learn_enable <= 1'b0;
                freeze_weights <= 1'b1;
            end else if (reset_cmd) begin
                state <= ST_READY;
                reset_weights <= 1'b1;
                clear_pulse <= 1'b1;
                learn_enable <= 1'b0;
                freeze_weights <= 1'b1;
                snapshot_id <= 8'd1;
                last_changed <= 7'd0;
                infer_i <= 6'd0;
            end else begin
                case (state)
                    ST_IDLE: state <= ST_READY;
                    ST_READY: if (sample_valid)
                        state <= ST_ARMED;
                    ST_ARMED: if (train_cmd && !core_busy) begin
                        start_pulse <= 1'b1;
                        learn_enable <= 1'b1;
                        freeze_weights <= 1'b0;
                        last_stim <= stim;
                        last_teacher <= teacher;
                        state <= ST_TRAIN;
                    end
                    ST_TRAIN: if (core_done) begin
                        learn_enable <= 1'b0;
                        freeze_weights <= 1'b1;
                        last_changed <= changed_from_core;
                        event_strobe <= 1'b1;
                        snapshot_id <= 8'd2;
                        state <= ST_AFTER;
                    end
                    ST_AFTER: if (freeze_infer_cmd) begin
                        infer_i <= 6'd0;
                        learn_enable <= 1'b0;
                        freeze_weights <= 1'b1;
                        start_pulse <= 1'b1;
                        state <= ST_INFER;
                    end else if (train_cmd && sample_valid && !core_busy) begin
                        start_pulse <= 1'b1;
                        learn_enable <= 1'b1;
                        freeze_weights <= 1'b0;
                        last_stim <= stim;
                        last_teacher <= teacher;
                        state <= ST_TRAIN;
                    end
                    ST_INFER: begin
                        learn_enable <= 1'b0;
                        freeze_weights <= 1'b1;
                        if (core_done) begin
                            if (infer_i == INFER_TICKS[5:0] - 6'd1) begin
                                snapshot_id <= 8'd3;
                                state <= ST_FREEZE;
                            end else begin
                                infer_i <= infer_i + 6'd1;
                                start_pulse <= 1'b1;
                            end
                        end
                    end
                    ST_FREEZE: state <= ST_DONE;
                    ST_DONE: if (sample_valid && train_cmd && !core_busy) begin
                        start_pulse <= 1'b1;
                        learn_enable <= 1'b1;
                        freeze_weights <= 1'b0;
                        last_stim <= stim;
                        last_teacher <= teacher;
                        state <= ST_TRAIN;
                    end
                    default: state <= ST_IDLE;
                endcase
            end
        end
    end
endmodule

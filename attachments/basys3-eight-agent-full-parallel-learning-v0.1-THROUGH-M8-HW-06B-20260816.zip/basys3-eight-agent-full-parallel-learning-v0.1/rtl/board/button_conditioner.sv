`timescale 1ns/1ps
module button_conditioner #(
    parameter int COUNTER_BITS = 17
) (
    input  logic clk,
    input  logic rst_n,
    input  logic button_async,
    output logic level,
    output logic pulse
);
    (* ASYNC_REG = "TRUE" *) logic meta, synced;
    logic [COUNTER_BITS-1:0] stable_count;
    logic level_d;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            meta <= 1'b0;
            synced <= 1'b0;
            stable_count <= '0;
            level <= 1'b0;
            level_d <= 1'b0;
            pulse <= 1'b0;
        end else begin
            meta <= button_async;
            synced <= meta;
            pulse <= 1'b0;

            if (synced == level) begin
                stable_count <= '0;
            end else if (&stable_count) begin
                level <= synced;
                stable_count <= '0;
            end else begin
                stable_count <= stable_count + 1'b1;
            end

            level_d <= level;
            if (level && !level_d)
                pulse <= 1'b1;
        end
    end
endmodule

`timescale 1ns/1ps
// Host → FPGA: A5 5E session definition, A5 5F command.
// Session bytes live in registers. No compile-time mapping table.
module host_link8 (
    input  logic clk,
    input  logic rst_n,
    input  logic rx_valid,
    input  logic [7:0] rx_data,
    output logic session_valid,
    output logic session_load_pulse,
    output logic [31:0] session_seed,
    output logic [63:0] perm_packed,
    output logic cmd_start,
    output logic cmd_reset,
    output logic cmd_dump,
    output logic cmd_dense_train,
    output logic cmd_freeze_infer,
    output logic dense_valid,
    output logic dense_load_pulse,
    output logic [7:0] dense_stim,
    output logic [7:0] dense_teacher,
    output logic [7:0] dense_lr,
    output logic temporal_valid,
    output logic temporal_load_pulse,
    output logic [7:0] sym_a,
    output logic [7:0] sym_b,
    output logic [7:0] sym_c,
    output logic [7:0] target_x,
    output logic cmd_t_reset,
    output logic cmd_t_train,
    output logic cmd_t_clear,
    output logic hold_ctx,
    output logic probe_cmd,
    output logic [7:0] probe_n,
    output logic [7:0] probe_s0,
    output logic [7:0] probe_s1,
    output logic [7:0] probe_s2
);
    logic [7:0] buf_b [0:13];
    logic [3:0] idx;
    logic collecting;
    logic [7:0] running_xor;
    integer i;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            idx <= 4'd0;
            collecting <= 1'b0;
            running_xor <= 8'd0;
            session_valid <= 1'b0;
            session_load_pulse <= 1'b0;
            session_seed <= 32'd0;
            perm_packed <= 64'd0;
            cmd_start <= 1'b0;
            cmd_reset <= 1'b0;
            cmd_dump <= 1'b0;
            cmd_dense_train <= 1'b0;
            cmd_freeze_infer <= 1'b0;
            dense_valid <= 1'b0;
            dense_load_pulse <= 1'b0;
            dense_stim <= 8'd0;
            dense_teacher <= 8'd0;
            dense_lr <= 8'd8;
            temporal_valid <= 1'b0;
            temporal_load_pulse <= 1'b0;
            sym_a <= 8'd0;
            sym_b <= 8'd0;
            sym_c <= 8'd0;
            target_x <= 8'd0;
            cmd_t_reset <= 1'b0;
            cmd_t_train <= 1'b0;
            cmd_t_clear <= 1'b0;
            hold_ctx <= 1'b0;
            probe_cmd <= 1'b0;
            probe_n <= 8'd0;
            probe_s0 <= 8'd0;
            probe_s1 <= 8'd0;
            probe_s2 <= 8'd0;
            for (i = 0; i < 14; i = i + 1)
                buf_b[i] <= 8'd0;
        end else begin
            session_load_pulse <= 1'b0;
            cmd_start <= 1'b0;
            cmd_reset <= 1'b0;
            cmd_dump <= 1'b0;
            cmd_dense_train <= 1'b0;
            cmd_freeze_infer <= 1'b0;
            dense_load_pulse <= 1'b0;
            temporal_load_pulse <= 1'b0;
            cmd_t_reset <= 1'b0;
            cmd_t_train <= 1'b0;
            cmd_t_clear <= 1'b0;
            probe_cmd <= 1'b0;
            if (rx_valid) begin
                if (!collecting) begin
                    if (rx_data == 8'hA5) begin
                        collecting <= 1'b1;
                        idx <= 4'd1;
                        buf_b[0] <= 8'hA5;
                        running_xor <= 8'hA5;
                    end
                end else if (idx < 4'd14) begin
                    buf_b[idx] <= rx_data;
                    running_xor <= running_xor ^ rx_data;
                    idx <= idx + 4'd1;
                end else begin
                    collecting <= 1'b0;
                    idx <= 4'd0;
                    if (rx_data == running_xor) begin
                        if (buf_b[1] == 8'h5E) begin
                            session_seed <= {buf_b[5], buf_b[4], buf_b[3], buf_b[2]};
                            perm_packed <= {buf_b[13], buf_b[12], buf_b[11], buf_b[10],
                                            buf_b[9], buf_b[8], buf_b[7], buf_b[6]};
                            session_valid <= 1'b1;
                            session_load_pulse <= 1'b1;
                        end else if (buf_b[1] == 8'h60) begin
                            dense_stim <= buf_b[2];
                            dense_teacher <= buf_b[3];
                            dense_lr <= (buf_b[4] == 8'd0) ? 8'd8 : buf_b[4];
                            dense_valid <= 1'b1;
                            dense_load_pulse <= 1'b1;
                        end else if (buf_b[1] == 8'h62) begin
                            sym_a <= buf_b[2];
                            sym_b <= buf_b[3];
                            sym_c <= buf_b[4];
                            target_x <= buf_b[5];
                            hold_ctx <= buf_b[6][0];
                            temporal_valid <= 1'b1;
                            temporal_load_pulse <= 1'b1;
                        end else if (buf_b[1] == 8'h63) begin
                            probe_n <= buf_b[2];
                            probe_s0 <= buf_b[3];
                            probe_s1 <= buf_b[4];
                            probe_s2 <= buf_b[5];
                            hold_ctx <= buf_b[6][0];
                            probe_cmd <= 1'b1;
                        end else if (buf_b[1] == 8'h5F) begin
                            if (buf_b[2] == 8'h01) cmd_start <= 1'b1;
                            else if (buf_b[2] == 8'h02) cmd_reset <= 1'b1;
                            else if (buf_b[2] == 8'h03) cmd_dump <= 1'b1;
                            else if (buf_b[2] == 8'h04) cmd_dense_train <= 1'b1;
                            else if (buf_b[2] == 8'h05) cmd_freeze_infer <= 1'b1;
                            else if (buf_b[2] == 8'h06) cmd_t_reset <= 1'b1;
                            else if (buf_b[2] == 8'h07) cmd_t_train <= 1'b1;
                            else if (buf_b[2] == 8'h08) cmd_t_clear <= 1'b1;
                        end
                    end
                end
            end
        end
    end
endmodule

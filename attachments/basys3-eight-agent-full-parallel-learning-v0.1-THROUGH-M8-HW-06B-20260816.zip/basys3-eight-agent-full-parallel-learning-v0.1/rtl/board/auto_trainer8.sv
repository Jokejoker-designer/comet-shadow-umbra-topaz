`timescale 1ns/1ps
module auto_trainer8 #(
    parameter int INTERVAL_CYCLES = 625000
) (
    input  logic clk,
    input  logic rst_n,
    input  logic enable,
    input  logic cyclic_mode,
    input  logic [63:0] perm_packed,
    input  logic core_busy,
    input  logic core_done,
    output logic start_pulse,
    output logic [7:0] source_spikes,
    output logic [7:0] score_teacher,
    output logic [2:0] phase,
    output logic [31:0] epochs
);
    localparam int CW = (INTERVAL_CYCLES <= 1) ? 1 : $clog2(INTERVAL_CYCLES+1);
    logic [CW-1:0] interval_count;
    logic [7:0] mapped_teacher;

    session_map8 map_i (
        .perm_packed(perm_packed),
        .source_spikes(source_spikes),
        .score_teacher(mapped_teacher)
    );

    always_comb begin
        source_spikes = 8'h01 << phase;
        score_teacher = cyclic_mode ? (8'h01 << ((phase + 3'd1) & 3'd7))
                                    : mapped_teacher;
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            interval_count <= '0;
            phase <= 3'd0;
            epochs <= 32'd0;
            start_pulse <= 1'b0;
        end else begin
            start_pulse <= 1'b0;
            if (!enable) begin
                interval_count <= '0;
                phase <= 3'd0;
            end else if (core_done) begin
                interval_count <= '0;
                if (phase == 3'd7) begin
                    phase <= 3'd0;
                    epochs <= epochs + 1'b1;
                end else begin
                    phase <= phase + 1'b1;
                end
            end else if (!core_busy) begin
                if (INTERVAL_CYCLES <= 1 || interval_count == INTERVAL_CYCLES-1) begin
                    interval_count <= '0;
                    start_pulse <= 1'b1;
                end else begin
                    interval_count <= interval_count + 1'b1;
                end
            end
        end
    end
endmodule

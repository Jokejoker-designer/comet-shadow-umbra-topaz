@echo off
setlocal
where vivado >nul 2>nul
if errorlevel 1 (
  echo ERROR: vivado is not in PATH.
  exit /b 1
)
if exist build\out\basys3_eight_agent_m8hw06b.bit (
  vivado -mode batch -nojournal -nolog -source vivado\program_basys3.tcl -tclargs build\out\basys3_eight_agent_m8hw06b.bit
) else if exist build\out\basys3_eight_agent_m8hw04.bit (
  vivado -mode batch -nojournal -nolog -source vivado\program_basys3.tcl -tclargs build\out\basys3_eight_agent_m8hw04.bit
) else if exist build\out\basys3_eight_agent_m8hw03.bit (
  vivado -mode batch -nojournal -nolog -source vivado\program_basys3.tcl -tclargs build\out\basys3_eight_agent_m8hw03.bit
) else if exist build\out\basys3_eight_agent_m8hw02.bit (
  vivado -mode batch -nojournal -nolog -source vivado\program_basys3.tcl -tclargs build\out\basys3_eight_agent_m8hw02.bit
) else (
  vivado -mode batch -nojournal -nolog -source vivado\program_basys3.tcl -tclargs build\out\basys3_eight_agent.bit
)
exit /b %ERRORLEVEL%

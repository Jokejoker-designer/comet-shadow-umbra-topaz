# M8-HW-04 XSim

`tb_m8_hw04_temporal` / 2026-08-14

```
TB ABC -> a5 ctx=201
TB ACB -> 00
TB BAC -> 00
TB AB  -> 00
TB FORGET ABC -> 00
M8_HW04_PASS
```

Symbols are TB/host only. RTL has no A/B/C/X constants.

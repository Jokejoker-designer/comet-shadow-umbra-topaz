# 8-agent Basys 3 board score — 2026-08-14

## Build / program
- bit: `build/out/basys3_eight_agent.bit` 2192225 B 2026-08-14T02:24:20
- WNS +103.692 ns
- DRC: 3 DSP pipeline warnings (DPIP-1 / DPOP-1 / DPOP-2)
- device: Digilent 210183BF7B31A `xc7a35t_0`
- program: End of startup HIGH

## UART COM8
- frames parsed: 1626 live `A5 5A`
- EVAL_BEFORE: ticks 1–32 W=64 hex=0040 out=00 learn=0 freeze=1
- TRAIN: tick 33 learn=1 freeze=0; W steps +8 each 8-tick cycle
- first route: tick 233 in=01 out=02 W=272
- HOLD: tick 1057+ W=1088 hex=0440 updates=1024 learn=0 freeze=1
- HOLD cyclic match: 650/650
- max weight seen: 1088 (not 2047/07FF)

## Verdict
**M8-HW-01 PASS** — `8_AGENT_CYCLIC_LEARNING_CONVERGENCE_DEMONSTRATED`.

This is **not** `GENUINE_ASSOCIATIVE_LEARNING` and **not** conversation.
Teacher on this bit is the fixed cyclic `+1` map. Telemetry muxed one weight.

Do not press BTNU unless you intend to reset that cyclic run.
Next proof: `docs/M8-HW-02_REMAPPING_CONTRACT.md`.

# M8-HW-06B XSim

**Date:** 2026-08-16  
**TB:** `tb/tb_m8_hw06b_multiturn.sv`  
**Result:** `M8_HW06B_PASS`

| Probe | out | ctx |
|-------|-----|-----|
| hist A (Quân tokens) | `0x66` | 153 |
| hist B (Lan tokens) | `0xEE` | 255 |
| T3 only | `0x00` | |
| permuted T2-T1A-T3 | `0x00` | |

Numeric tokens only in the TB. Names live on the host.

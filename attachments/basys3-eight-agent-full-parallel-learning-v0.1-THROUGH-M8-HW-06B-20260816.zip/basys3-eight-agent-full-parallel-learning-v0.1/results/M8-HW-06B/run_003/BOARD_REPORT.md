# M8-HW-06B run_003 — board

**Date:** 2026-08-16  
**Port:** COM8 115200  
**Bitstream:** `basys3_eight_agent_m8hw06b.bit`  
**SHA-256:** `7CE3238E93128D2C…` (full in `VALIDATION.json`)  
**WNS:** +96.343 ns  
**Startup:** HIGH  
**Switches:** SW11 ON (not required on this bit; A5 62 arms temporal)  
**m8hw04 untouched:** `DEEFE548…`

run_001: FPGA unconfigured / SW11 off on the first bit.  
run_002: `probe_cmd` stuck high (host_link pulse missing). Not a learning fail.

| AFTER probe | FPGA | Decode |
|-------------|------|--------|
| Quân + chào + hỏi tên | **0x66** | **Quân** |
| Lan + chào + hỏi tên | **0xEE** | **Lan** |
| only `Tôi tên gì?` | 0x00 | empty |
| chào + Quân + hỏi tên (order) | 0x00 | empty |

Weight SHA before/after AFTER: `7D3C316A…` identical. LLM 0.

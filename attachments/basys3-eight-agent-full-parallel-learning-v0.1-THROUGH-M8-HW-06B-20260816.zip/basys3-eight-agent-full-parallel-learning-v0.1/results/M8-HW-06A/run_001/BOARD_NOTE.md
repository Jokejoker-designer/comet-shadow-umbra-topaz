# run_001 — not a logic fail

FPGA was unconfigured (power loss after 05). Every UART event was `None`.
Reprogrammed `m8hw04.bit` (startup HIGH) and scored as **run_002**.

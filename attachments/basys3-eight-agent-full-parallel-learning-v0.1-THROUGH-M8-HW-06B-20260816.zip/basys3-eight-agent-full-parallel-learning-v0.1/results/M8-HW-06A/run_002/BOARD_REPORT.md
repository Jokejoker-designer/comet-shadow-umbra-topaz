# M8-HW-06A run_002 — board

**Date:** 2026-08-16  
**Port:** COM8 115200  
**Bitstream:** existing `basys3_eight_agent_m8hw04.bit` (reprogrammed; file not overwritten)  
**SHA-256:** `DEEFE548634904B27B70E7D6C969B0E3FF9C2178A2D3F465FD78F06B5670D79A`  
**Startup:** HIGH  
**Switches:** SW11 ON, SW10 OFF, SW13 OFF  

run_001 was UART-dead (FPGA unconfigured after power loss). Not a logic fail.

| Phase | Event | Result |
|-------|--------|--------|
| TRAIN | `xin chào`, `hello` → teacher R1 | legal |
| AFTER latch | Teacher/Learn off, Freeze on | host one-way |
| DUMP before | SHA `5452F2B6…` | 16/16 pages |
| user `xin chào` | FPGA `0x88` → **chào bạn** | PASS |
| user `hello` | FPGA `0x88` → **chào bạn** | PASS |
| user `tạm biệt` | FPGA `0x77` → empty | PASS |
| DUMP after | SHA `5452F2B6…` identical | weight writes 0 |
| EXTERNAL LLM | 0 | PASS |

Transcript: `ui_transcript.txt`  
Replay: `replay/score.json`

# M8-HW-05 run_001 — board

**Date:** 2026-08-14  
**Port:** COM8 115200 (FTDI `210183BF7B31B`)  
**Bitstream:** existing `basys3_eight_agent_m8hw04.bit`  
**SHA-256:** `DEEFE548634904B27B70E7D6C969B0E3FF9C2178A2D3F465FD78F06B5670D79A`  
**No rebuild. No reprogram this run** (04 already on silicon).  
**Switches:** SW11 ON, SW10 OFF, SW13 OFF. A5 62 arms temporal.

Host encoder (`ENCODER_SALT=0`) only. FPGA never saw the strings.

| Step | ctx | out | Expect |
|------|-----|-----|--------|
| Train P1 `xin chào` → R1 | 136 | 136 | P1 hits R1 |
| Probe P2 `hello` (P1-only) | 68 | **0** | not R1 |
| Train P2 → same R1 | 68 | 136 | joint basin |
| Probe P1 | 136 | **136 = 0x88** | R1 |
| Probe P2 | 68 | **136 = 0x88** | R1 |
| Probe D `tạm biệt` | 187 | **119 = 0x77** | not R1 |
| RESET then P1 | 136 | **0** | forget |
| Remap P1+P2 → R2 | 136 / 68 | **204 = 0xCC** | new basin |

Replay: `replay/score.json` `pass: true`.  
Golden: `results/M8-HW-05/reference.json` bit-exact outs.

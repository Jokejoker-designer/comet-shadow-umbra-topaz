# 8-agent scorecard

Board default = `LIF + STDP + route-gate + latch + eval supervisor`.  
**No semantic ROM / conversation claim on board.**

## M8-HW-01 — closed 2026-08-14

`8_AGENT_CYCLIC_LEARNING_CONVERGENCE_DEMONSTRATED` **PASS**

| Item | Status |
|------|--------|
| Basys 3 / 8 agents / online STDP / route-gate | PASS |
| EVAL_BEFORE → TRAIN → WEIGHT EFFECT → FREEZE → EVAL_AFTER | PASS |
| Frozen cyclic accuracy | **650 / 650** |
| `W[1][0]` HOLD | 1088 = `0440` (not `07FF`) |
| 64-synapse arbitrary associative learning | **NOT YET BOARD-PROVEN** |
| Random session A → B remapping | **NOT YET BOARD-PROVEN** |
| Reset → forget → retrain new mapping | **NOT YET BOARD-PROVEN** |
| Simple conversation | **NOT YET** |

Closeout: `results/M8-HW-01_CLOSEOUT.md`  
Next: `docs/M8-HW-02_REMAPPING_CONTRACT.md`

## Build / program (support, not a conversation proof)

| Item | Status |
|------|--------|
| Vivado 2026.1 WNS | +103.692 ns |
| DRC | 3 DSP pipeline warnings |
| Program | Digilent 210183BF7B31A, startup HIGH |
| UART | COM8 115200; RESULT `A5 5C` not captured (HOLD live frames scored) |

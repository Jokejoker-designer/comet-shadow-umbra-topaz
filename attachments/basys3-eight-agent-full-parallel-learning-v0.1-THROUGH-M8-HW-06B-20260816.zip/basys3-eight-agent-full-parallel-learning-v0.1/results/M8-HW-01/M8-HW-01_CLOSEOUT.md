# M8-HW-01 — closeout (this session)

**Date:** 2026-08-14  
**Board:** Digilent Basys 3 `210183BF7B31A` `xc7a35tcpg236-1`  
**Bitstream:** `build/out/basys3_eight_agent.bit` (2,192,225 B, WNS +103.692 ns)  
**UART:** COM8 115200  
**Evidence:** `results/13_board_score.md`, SCORECARD, UART logs 11/12

This milestone is **closed**. Do not train more cyclic rings to “strengthen” it.

---

## What the silicon is running

Board default is **not** a conversation architecture:

```text
LIF + STDP + route-gate + output latch + eval supervisor
```

`No semantic ROM / conversation claim on board` remains in force.

The cyclic teacher is a **fixed derangement** baked into `auto_trainer8`:

```text
source  = 1 << phase
teacher = 1 << ((phase + 1) & 7)
```

That is a scale-up / online-learning smoke test. It is **not** arbitrary
associative learning. It cannot prove remapping, forget, or conversation.

---

## Closed verdicts (this session)

```
M8-HW-01
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BASYS 3                    PASS
8 AGENTS                   PASS
ONLINE STDP                PASS
ROUTE GATE                 PASS
EVAL_BEFORE                PASS
TRAIN                      PASS
WEIGHT EFFECT              PASS
FREEZE                     PASS
EVAL_AFTER                 PASS   (HOLD = frozen eval-after equivalent)

FROZEN ROUTE ACCURACY
650 / 650                  PASS

FINAL:
8_AGENT_CYCLIC_LEARNING_
CONVERGENCE_DEMONSTRATED   PASS
```

### Claim ladder

| Claim | Status |
|-------|--------|
| 8-AGENT HARDWARE SCALE-UP | **PASS** |
| 8-AGENT CYCLIC ONLINE LEARNING | **PASS** |
| WEIGHT → BEHAVIOR CAUSAL EFFECT | **PASS** (W=64 no spike → W≥272 cyclic `in→out`) |
| FROZEN INFERENCE | **PASS** (`learn=0 freeze=1`, updates locked at 1024, W stays 1088) |
| 8-AGENT CYCLIC CONVERGENCE | **PASS** (`0440`, not `07FF`) |
| 64-SYNAPSE FULL-PARALLEL ARBITRARY ASSOCIATIVE LEARNING | **NOT YET BOARD-PROVEN** |
| RANDOM SESSION A → B REMAPPING | **NOT YET BOARD-PROVEN** |
| RESET → FORGET → RETRAIN NEW MAPPING | **NOT YET BOARD-PROVEN** |
| SIMPLE CONVERSATION | **NOT YET** |

**Forbidden sentence:** “8-agent full-parallel 64-synapse conversation architecture is board-proven.”

**Allowed sentence:** “8-agent cyclic online learning convergence is demonstrated on Basys 3.”

---

## Numeric facts used (CONFIRMED)

- EVAL_BEFORE ticks 1–32: `W[1][0]=64=0040`, `out=00`
- TRAIN tick 33: first LTP `64→72` (`+8`)
- First causal route tick 233: `in=01 out=02` at `W=272`
- HOLD from tick 1057: `W=1088=0440`, `updates=1024` frozen
- HOLD cyclic rotate-left one-hot: **650 / 650**
- Clip rail `07FF` never seen

Telemetry still muxes **one** inspect cell (`SW15:13` dest, `SW8:6` src).
The other 63 weights were **not** dumped. Full-parallel *update* is in RTL;
full-parallel *observation* is not yet on the UART.

---

## Next milestone (not this closeout)

`docs/M8-HW-02_REMAPPING_CONTRACT.md`

No more cyclic rings. Next board proof is anti-hardcode remapping A→reset→B
plus a 64-weight dump. Only that may raise the verdict to
`8_AGENT_FULL_PARALLEL_GENUINE_ASSOCIATIVE_LEARNING_BOARD_VALIDATED`.

# M8-HW-03 run_002 — BOARD PASS

- Bit: `basys3_eight_agent_m8hw03.bit`
- SHA-256: `34D63D5D60968DA637879FA6F8DCA9CC93B8636FF24080E151151D4BC246EC45`
- M8-HW-02 bit untouched: `74F98993…`
- WNS +93.129 ns, startup HIGH
- COM8 115200, SW11 ON, SW10 OFF; dense armed by host `A5 60`

| Gate | Result |
|------|--------|
| BEFORE 16 pages, neutral 0/64 | PASS |
| One TRAIN, UART `changed_cell_count` | **64** |
| Host AFTER−BEFORE | **64/64** |
| SHA AFTER | `C2A3751D4473C0AEDBE589A5F133505175CC1FA26763562CA6D42D2099066B5A` |
| SHA Python | same |
| FREEZE dump == AFTER | PASS |
| Dense-B event + SHA | 64 + match |

Claim:

```text
64_SYNAPSES_SIMULTANEOUSLY_ACTIVE
FULL_PARALLEL_PLASTICITY
BOARD_VALIDATED
```

# M8-HW-03 run_001 — incomplete (dense path not armed)

Program of first `m8hw03.bit` (`FD6DC0DE…`) succeeded. UART dumps 16/16 and BEFORE was neutral, but:

- no `A5 61` event
- 0/64 cells changed
- snapshot_id stayed 0

That is the remap-mode supervisor still owning the chip (`SW12` was off; first image required SW12).  
Rebuild arms dense mode from host `A5 60` so the next program does not depend on SW12.
M8-HW-02 bit `74F98993…` was not overwritten.

# M8-HW-03 run_003 — SW12 ON, BOARD PASS

Same programmed `basys3_eight_agent_m8hw03.bit` as run_002
(`34D63D5D…C246EC45`). User confirmed **SW12 ON** (with SW11 ON, SW10 OFF).

All conjunctive gates true again:

- BEFORE neutral, 16 pages
- Dense-A event `changed_cell_count=64`, host Δ 64/64
- SHA `C2A3751D4473C0AEDBE589A5F133505175CC1FA26763562CA6D42D2099066B5A` == Python
- FREEZE == AFTER
- Dense-B event 64 + SHA match

Confirms run_002 was not a host-only workaround: the same 64-cell result holds with the physical dense switch on.

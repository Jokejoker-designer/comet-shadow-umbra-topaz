# M8-HW-03 XSim

`tb_m8_hw03_dense` / Vivado 2026.1 / 2026-08-14

```
TB BEFORE_DENSE changed=0
TB DENSE_A changed=64 matrix bit-exact
TB FREEZE 0/64 bit-exact vs AFTER_ONE
TB FREEZE_CONTROL no write
TB TEACHER_OFF / learn=0 no write
TB DENSE_B changed=64 matrix bit-exact
M8_HW03_PASS
```

FPGA weights match `python/m8_hw03_dense_reference.py` (LR=8, ±1 outer product, diagonal plastic).
One-hot STDP path not exercised here (`dense_mode=1`).

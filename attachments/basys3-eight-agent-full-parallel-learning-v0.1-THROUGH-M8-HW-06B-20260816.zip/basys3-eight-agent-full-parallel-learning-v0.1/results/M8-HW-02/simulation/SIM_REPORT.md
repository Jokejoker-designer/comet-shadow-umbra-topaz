# M8-HW-02 XSim report — 2026-08-14

**Tool:** Vivado 2026.1 XSim behavioral  
**TB:** `tb/tb_m8_hw02_remap.sv`  
**Command:** `vivado -mode batch -source vivado/sim_m8_hw02.tcl`  
**Result:** `TB M8-HW-02 PASS` at 48365 ns  

This is **RTL simulation**, not a Basys 3 board proof.

## Gates

| Gate | Sim |
|------|-----|
| A EVAL_BEFORE | **0 / 32** |
| A EVAL_AFTER / HOLD | **32 / 32** |
| A target weights | **320** on P_A cells |
| RESET matrix | **exact neutral** (diag 0, else 64) |
| A forgotten | **0 / 32** |
| B EVAL_AFTER / HOLD | **32 / 32** |
| B target weights | **320** on P_B cells |
| Teacher isolation | no `$error` / `$fatal` |
| Topology A ≠ B | cells moved with permutation |

```
TB M8-HW-02 PASS A_before=0 A_after=32 A_forget=0 B_after=32
```

## Measured matrices (from XSim `$display`, not Python prediction)

A_HOLD `P_A=[1,7,4,5,3,2,0,6]`:

```
  0   64  64  64  64  64 320  64
320    0  64  64  64  64  64  64
 64   64   0  64  64 320  64  64
 64   64  64   0 320  64  64  64
 64   64 320  64   0  64  64  64
 64   64  64 320  64   0  64  64
 64   64  64  64  64  64   0 320
 64  320  64  64  64  64  64   0
```

RESET:

```
  0  64  64  64  64  64  64  64
 64   0  64  64  64  64  64  64
 ... all off-diagonal 64 ...
```

B_HOLD `P_B=[5,6,0,1,7,3,2,4]`:

```
  0   64 320  64  64  64  64  64
 64    0  64 320  64  64  64  64
 64   64   0  64  64  64 320  64
 64   64  64   0  64 320  64  64
 64   64  64  64   0  64  64 320
320   64  64  64  64   0  64  64
 64  320  64  64  64  64   0  64
 64   64  64  64 320  64  64   0
```

Figures: `weights_A_hold.png`, `weights_reset.png`, `weights_B_hold.png`, `weights_A_vs_B_delta.png`.

## Claim

`M8_HW_02_XSIM_A_RESET_B_PASS`

**Not** `BOARD_VALIDATED`. **Not** conversation.

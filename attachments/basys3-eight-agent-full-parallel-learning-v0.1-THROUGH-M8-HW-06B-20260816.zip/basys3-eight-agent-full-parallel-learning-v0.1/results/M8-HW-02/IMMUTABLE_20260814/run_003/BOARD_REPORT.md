# M8-HW-02 run_003 — A → RESET → B on Basys 3 COM8

**Date:** 2026-08-14  
**Board:** Digilent Basys 3 `210183BF7B31A` `xc7a35tcpg236-1`  
**Bitstream:** `build/out/basys3_eight_agent_m8hw02.bit`  
**SHA-256:** `74F989937CAB99B02E43313E33243DA5B0BC562646548797F150F5FA3CB9F05B`  
**Cyclic M8-HW-01 bit untouched:** `E27B0277D4B03EF30D5CE9D49C370C731DA8FBC0A0336F35C7AC3EA5BC318BA4`  
**UART:** COM8 115200  
**Switches:** SW11 ON (AUTO), SW10 OFF (remap, not cyclic)  
**WNS:** +100.814 ns  

Scorer: `python tools/board_scorer_m8_hw02.py COM8 --out results/M8-HW-02/run_003`  
Exit 0. All 13 gates true.

---

## Protocol that actually ran

Same bitstream, host-selected sessions (not a cyclic +1 teacher):

```text
SESSION A  seed=2026081401  P_A = [1,7,4,5,3,2,0,6]
  echo A5 5E  → EVAL_B 32 → TRAIN 256 → EVAL_A 32 → HOLD 32 → dump 16 pages
RESET
  dump 16 pages (neutral) → FORGET 32 (A routes gone) → WAIT
SESSION B  seed=2026081403  P_B = [5,6,0,1,7,3,2,4]
  echo A5 5E  → EVAL_B 32 → TRAIN 256 → EVAL_A 32 → HOLD 32 → dump 16 pages
```

Teacher is isolated off TRAIN in the board top (`core_teacher = 0` outside TRAIN).

---

## Gates

| Gate | Measured |
|------|----------|
| A echo | `[1,7,4,5,3,2,0,6]` |
| A pages / live | 16 / 352 |
| A before | **0/32** |
| A after | **32/32** |
| A hold | **32/32** |
| A target W | **320 × 8** |
| Reset 16 pages | yes, diagonal 0 else 64 |
| A forget | **0/32** |
| B echo | `[5,6,0,1,7,3,2,4]` |
| B pages / live | 16 / 352 |
| B before | **0/32** |
| B after | **32/32** |
| B hold | **32/32** |
| B target W | **320 × 8** |

P_A Hamming vs cyclic +1 = 7. P_B vs A = 8. P_B vs cyclic +1 = 8.

---

## 64-weight dumps (W[d][s])

A HOLD — 320 only on P_A cells:

```
     s0  s1  s2  s3  s4  s5  s6  s7
d0    0  64  64  64  64  64 320  64
d1  320   0  64  64  64  64  64  64
d2   64  64   0  64  64 320  64  64
d3   64  64  64   0 320  64  64  64
d4   64  64 320  64   0  64  64  64
d5   64  64  64 320  64   0  64  64
d6   64  64  64  64  64  64   0 320
d7   64 320  64  64  64  64  64   0
```

RESET — every off-diagonal 64, diagonal 0.

B HOLD — 320 only on P_B cells; every A cell is back to 64:

```
     s0  s1  s2  s3  s4  s5  s6  s7
d0    0  64 320  64  64  64  64  64
d1   64   0  64 320  64  64  64  64
d2   64  64   0  64  64  64 320  64
d3   64  64  64   0  64 320  64  64
d4   64  64  64  64   0  64  64 320
d5  320  64  64  64  64   0  64  64
d6   64 320  64  64  64  64   0  64
d7   64  64  64  64 320  64  64   0
```

These three matrices match the XSim goldens and `results/M8-HW-02/reference.json`.

---

## What this does **not** prove

- Not conversation, LLM, Transformer, or language.
- Not a large random-seed ensemble (two specified host seeds only).
- Not M8-HW-03 dense same-transaction 64-cell update.
- run_002 on this same bit failed B because the host sent START during `ST_FORGET`. That was a host race, not a learning miss.

Contract claim allowed by these gates:

```text
8_AGENT_FULL_PARALLEL
GENUINE_ASSOCIATIVE_LEARNING
BOARD_VALIDATED
```

(scorer string: `8_AGENT_ARBITRARY_ASSOCIATIVE_REMAPPING_BOARD_VALIDATED`)

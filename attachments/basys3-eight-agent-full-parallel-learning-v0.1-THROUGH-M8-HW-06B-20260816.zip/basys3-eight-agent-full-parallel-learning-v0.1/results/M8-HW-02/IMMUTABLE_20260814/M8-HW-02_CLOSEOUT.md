# M8-HW-02 — closeout (this session)

**Date:** 2026-08-14  
**Board:** Digilent Basys 3 `210183BF7B31A` `xc7a35tcpg236-1`  
**Bitstream:** `build/out/basys3_eight_agent_m8hw02.bit`  
**SHA-256:** `74F989937CAB99B02E43313E33243DA5B0BC562646548797F150F5FA3CB9F05B`  
**Cyclic bit (M8-HW-01) not overwritten:** `E27B0277…318BA4`  
**UART:** COM8 115200  
**Evidence:** `results/M8-HW-02/run_003/`

This milestone is **closed** for the two specified host sessions.

---

## Verdict

```
M8-HW-02
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SAME BITSTREAM A THEN B        PASS
HOST SESSION ECHO A / B        PASS
A EVAL_BEFORE 0/32             PASS
A EVAL_AFTER  32/32            PASS
A HOLD        32/32            PASS
A TARGET W    320 x 8          PASS
64-WEIGHT DUMP A / RST / B     PASS
RESET NEUTRAL 0 / 64           PASS
A FORGET      0/32             PASS
B EVAL_BEFORE 0/32             PASS
B EVAL_AFTER  32/32            PASS
B HOLD        32/32            PASS
B TARGET W    320 x 8          PASS
MAPPING NOT IN RTL             PASS

FINAL:
8_AGENT_FULL_PARALLEL
GENUINE_ASSOCIATIVE_LEARNING
BOARD_VALIDATED                PASS
(two host seeds only)
```

---

## Scope lock

Still **not**:

- conversation / LLM / Transformer
- a large random remapping ensemble
- M8-HW-03 dense same-transaction 64-cell update

P_A = `[1,7,4,5,3,2,0,6]` seed `2026081401`  
P_B = `[5,6,0,1,7,3,2,4]` seed `2026081403`

run_002 on this bit proved dump + A + reset, but B START raced `ST_FORGET`.
run_003 waited for 32 FORGET frames then started B. Same bitstream.

# 8-agent scorecard

Board default = `LIF + STDP + route-gate + latch + eval supervisor`.  
**No semantic ROM / conversation claim on board.**

## M8-HW-01 — closed 2026-08-14

`8_AGENT_CYCLIC_LEARNING_CONVERGENCE_DEMONSTRATED` **PASS**

| Item | Status |
|------|--------|
| Basys 3 / 8 agents / online STDP / route-gate | PASS |
| EVAL_BEFORE → TRAIN → WEIGHT EFFECT → FREEZE → EVAL_AFTER | PASS |
| Frozen cyclic accuracy | **650 / 650** |
| `W[1][0]` HOLD | 1088 = `0440` (not `07FF`) |
| 64-synapse associative remapping (2 host sessions) | **BOARD PASS run_003** |
| Session A → reset → Session B same bitstream | **BOARD PASS** |
| Reset → forget → retrain new mapping | **BOARD PASS** |
| Simple conversation | **NOT YET** |

Closeout: `results/M8-HW-01_CLOSEOUT.md`  
## M8-HW-02 — BOARD PASS 2026-08-14

XSim and COM8 agree: `A_before=0/32 A_after=32/32 A_forget=0/32 B_after=32/32`.  
A targets 320 on P_A, reset 0/64, B targets 320 on P_B.  
Bit: `basys3_eight_agent_m8hw02.bit` SHA-256 `74F98993…`.  
Evidence: `results/M8-HW-02/run_003/BOARD_REPORT.md`  
**Not conversation.** Scope = seeds `2026081401` and `2026081403` only.

## Build / program (support, not a conversation proof)

| Item | Status |
|------|--------|
| Vivado 2026.1 WNS | +103.692 ns |
| DRC | 3 DSP pipeline warnings |
| Program | Digilent 210183BF7B31A, startup HIGH |
| UART | COM8 115200; RESULT `A5 5C` not captured (HOLD live frames scored) |

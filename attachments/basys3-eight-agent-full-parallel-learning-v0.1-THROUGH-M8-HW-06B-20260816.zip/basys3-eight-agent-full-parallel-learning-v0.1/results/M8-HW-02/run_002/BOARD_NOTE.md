# M8-HW-02 run_002 — sticky-dump bitstream, host START raced FORGET

- Bitstream: `basys3_eight_agent_m8hw02.bit`
- SHA-256: `74F989937CAB99B02E43313E33243DA5B0BC562646548797F150F5FA3CB9F05B`
- Cyclic bit untouched: `E27B0277…318BA4`
- Device: Digilent `210183BF7B31A` startup HIGH
- COM8 115200, SW11 ON, SW10 OFF

## Measured

| Gate | Result |
|---|---|
| Session A echo | `[1,7,4,5,3,2,0,6]` |
| A live / pages | 352 / 16 |
| A before / after / hold | 0/32, 32/32, 32/32 |
| A target W | 320 × 8 |
| Reset dump | 16/16, matrix diagonal 0 else 64 |
| Session B echo | `[5,6,0,1,7,3,2,4]` received |
| B dump / train | **not started** |

## Cause (host, not learning)

Supervisor RESET path is `WAIT → RST → RST_DUMP → FORGET(32) → WAIT`.
`start_cmd` is accepted only from `IDLE`/`WAIT`.
Scorer sent Session B + START as soon as 16 reset pages arrived, while FPGA was still in `ST_FORGET`.
The 32 live frames scored as “B” were actually `phase=9` FORGET leftovers (`out=0`).

Not a weight-learning failure. Same bitstream, rerun as `run_003` after host waits for FORGET then WAIT.

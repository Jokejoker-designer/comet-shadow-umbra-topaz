"""M8-HW-04 golden: order-sensitive context + learned bipolar readout.

Context binder is fixed and non-commutative:
    ctx := rotl(ctx, 3) ^ stim ^ rotl(stim, 2)
Readout W is learned only on the last TRAIN step:
    ΔW[d][s] = LR × teacher_pm1[d] × ctx_pm1[s]
Symbols A,B,C,X live in the host, never in RTL.
"""
from __future__ import annotations

import json
from pathlib import Path

from python.m8_hw03_dense_reference import clip_weight, matrix_sha256, pm1

LR = 8
SYM_A = 0xB4
SYM_B = 0x6B
SYM_C = 0x4B
SYM_X = 0xA5
TRAIN_REPS = 8


def rotl8(value: int, shift: int) -> int:
    shift &= 7
    value &= 0xFF
    return ((value << shift) | (value >> (8 - shift))) & 0xFF


def step_ctx(ctx: int, stim: int) -> int:
    return rotl8(ctx, 3) ^ (stim & 0xFF) ^ rotl8(stim, 2)


def run_ctx(seq: list[int], ctx0: int = 0) -> int:
    ctx = ctx0
    for stim in seq:
        ctx = step_ctx(ctx, stim)
    return ctx


def zero_matrix() -> list[list[int]]:
    return [[0] * 8 for _ in range(8)]


def energy_row(weights: list[list[int]], ctx: int, dest: int) -> int:
    acc = 0
    for src in range(8):
        acc += weights[dest][src] * pm1(ctx, src)
    return acc


def readout(weights: list[list[int]], ctx: int) -> int:
    bits = 0
    for dest in range(8):
        if energy_row(weights, ctx, dest) > 0:
            bits |= 1 << dest
    return bits


def train_last(weights: list[list[int]], ctx: int, teacher: int, lr: int = LR) -> list[list[int]]:
    out = [row[:] for row in weights]
    for dest in range(8):
        for src in range(8):
            dw = lr * pm1(teacher, dest) * pm1(ctx, src)
            out[dest][src] = clip_weight(out[dest][src] + dw)
    return out


def train_sequence(
    seq: list[int],
    teacher: int,
    reps: int = TRAIN_REPS,
    weights: list[list[int]] | None = None,
) -> list[list[int]]:
    w = zero_matrix() if weights is None else [row[:] for row in weights]
    for _ in range(reps):
        ctx = run_ctx(seq)
        w = train_last(w, ctx, teacher)
    return w


def probe(weights: list[list[int]], seq: list[int]) -> dict:
    ctx = run_ctx(seq)
    out = readout(weights, ctx)
    return {"ctx": ctx, "out": out}


def run_first_gate(
    a: int = SYM_A,
    b: int = SYM_B,
    c: int = SYM_C,
    x: int = SYM_X,
    reps: int = TRAIN_REPS,
) -> dict:
    abc = [a, b, c]
    w = train_sequence(abc, x, reps)
    probes = {
        "ABC": probe(w, abc),
        "ACB": probe(w, [a, c, b]),
        "BAC": probe(w, [b, a, c]),
        "AB": probe(w, [a, b]),
    }
    forget = probe(zero_matrix(), abc)
    return {
        "a": a,
        "b": b,
        "c": c,
        "x": x,
        "reps": reps,
        "ctx_abc": probes["ABC"]["ctx"],
        "probes": probes,
        "after_sha": matrix_sha256(w),
        "abc_is_x": probes["ABC"]["out"] == x,
        "acb_not_x": probes["ACB"]["out"] != x,
        "bac_not_x": probes["BAC"]["out"] != x,
        "ab_not_x": probes["AB"]["out"] != x,
        "forget_not_x": forget["out"] != x,
        "pass": (
            probes["ABC"]["out"] == x
            and probes["ACB"]["out"] != x
            and probes["BAC"]["out"] != x
            and probes["AB"]["out"] != x
            and forget["out"] != x
        ),
    }


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-04"
    out.mkdir(parents=True, exist_ok=True)
    ref = run_first_gate()
    (out / "reference.json").write_text(json.dumps(ref, indent=2) + "\n", encoding="utf-8")
    print(
        "PASS" if ref["pass"] else "FAIL",
        "ABC",
        hex(ref["probes"]["ABC"]["out"]),
        "ACB",
        hex(ref["probes"]["ACB"]["out"]),
        "BAC",
        hex(ref["probes"]["BAC"]["out"]),
        "AB",
        hex(ref["probes"]["AB"]["out"]),
        "ctx",
        ref["ctx_abc"],
    )


if __name__ == "__main__":
    main()

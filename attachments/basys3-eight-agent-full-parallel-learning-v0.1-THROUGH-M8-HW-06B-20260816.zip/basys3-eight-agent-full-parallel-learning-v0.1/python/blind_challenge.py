from __future__ import annotations
import argparse
import json
from python.golden_model import run_blind_session

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sessions", type=int, default=32)
    args = ap.parse_args()

    rows = [run_blind_session(seed) for seed in range(args.sessions)]
    passed = all(
        r["before_accuracy"] < 1.0
        and r["after_accuracy"] == 1.0
        and r["frozen_accuracy"] == 1.0
        and r["freeze_holds"]
        and r["after_reset_accuracy"] < 1.0
        for r in rows
    )

    print(json.dumps({
        "sessions": args.sessions,
        "pass": passed,
        "results": rows,
    }, indent=2))
    raise SystemExit(0 if passed else 1)

if __name__ == "__main__":
    main()

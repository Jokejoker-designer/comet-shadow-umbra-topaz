"""M8-HW-05 golden: host phrase encoder + many-to-one learned basin.

Encoder is signal encoding only. It does not receive a response class.
RTL sees 8-bit stims. No HELLO / phrase / response ID in rtl/.
Plastic readout is the M8-HW-04 temporal law (reuse m8hw04.bit).
"""
from __future__ import annotations

import json
from pathlib import Path

from python.m8_hw04_temporal_reference import (
    LR,
    TRAIN_REPS,
    probe,
    run_ctx,
    step_ctx,
    train_sequence,
    zero_matrix,
)

# Published mixer constant. Salt 0 is class-unaware and satisfies the
# demo Hamming gates (see tests). Not a per-phrase patch.
ENCODER_SALT = 0

PHRASE_P1 = "xin chào"
PHRASE_P2 = "hello"
PHRASE_DISTRACTOR = "tạm biệt"
BASIN_R1 = "chào bạn"
BASIN_R2 = "rất vui được giúp"


def rotl8(value: int, shift: int) -> int:
    shift &= 7
    value &= 0xFF
    return ((value << shift) | (value >> (8 - shift))) & 0xFF


def encode_tokens(text: str, salt: int = ENCODER_SALT) -> tuple[int, int, int]:
    """UTF-8 → three stim bytes. No response class in the signature."""
    data = text.encode("utf-8")
    acc = [salt & 0xFF, (salt >> 8) & 0xFF, (salt >> 16) & 0xFF]
    for i, byte in enumerate(data):
        acc[i % 3] = step_ctx(acc[i % 3], byte)
    n = len(data) & 0xFF
    acc[0] = step_ctx(acc[0], n)
    acc[1] = step_ctx(acc[1], rotl8(n, 3) ^ (salt & 0xFF))
    acc[2] = step_ctx(acc[2], rotl8(n, 5) ^ ((salt >> 8) & 0xFF))
    return acc[0], acc[1], acc[2]


def encode_basin(text: str, salt: int = ENCODER_SALT) -> int:
    """8-bit teacher from response text. Forced nonzero so RESET (out=0) is distinct."""
    tokens = encode_tokens(text, salt)
    basin = run_ctx(list(tokens))
    return 0x3C if basin == 0 else basin


def hamming8(a: int, b: int) -> int:
    return bin((a ^ b) & 0xFF).count("1")


def ctx_of(text: str, salt: int = ENCODER_SALT) -> int:
    return run_ctx(list(encode_tokens(text, salt)))


def train_phrases(
    phrases: list[str],
    basin_text: str,
    reps: int = TRAIN_REPS,
    salt: int = ENCODER_SALT,
    weights: list[list[int]] | None = None,
) -> list[list[int]]:
    teacher = encode_basin(basin_text, salt)
    w = zero_matrix() if weights is None else [row[:] for row in weights]
    for _ in range(reps):
        for phrase in phrases:
            w = train_sequence(list(encode_tokens(phrase, salt)), teacher, reps=1, weights=w)
    return w


def run_first_gate(
    p1: str = PHRASE_P1,
    p2: str = PHRASE_P2,
    distractor: str = PHRASE_DISTRACTOR,
    basin1: str = BASIN_R1,
    basin2: str = BASIN_R2,
    reps: int = TRAIN_REPS,
    salt: int = ENCODER_SALT,
) -> dict:
    t1 = encode_tokens(p1, salt)
    t2 = encode_tokens(p2, salt)
    td = encode_tokens(distractor, salt)
    r1 = encode_basin(basin1, salt)
    r2 = encode_basin(basin2, salt)
    c1, c2, cd = ctx_of(p1, salt), ctx_of(p2, salt), ctx_of(distractor, salt)

    w_p1 = train_phrases([p1], basin1, reps, salt)
    only_p1 = {
        "P1": probe(w_p1, list(t1)),
        "P2": probe(w_p1, list(t2)),
    }

    w_both = train_phrases([p1, p2], basin1, reps, salt)
    both = {
        "P1": probe(w_both, list(t1)),
        "P2": probe(w_both, list(t2)),
        "D": probe(w_both, list(td)),
    }
    forget = probe(zero_matrix(), list(t1))

    w_remap = train_phrases([p1, p2], basin2, reps, salt)
    remap = {
        "P1": probe(w_remap, list(t1)),
        "P2": probe(w_remap, list(t2)),
    }

    gates = {
        "tokens_distinct": t1 != t2 and t1 != td and t2 != td,
        "ctx_distinct": len({c1, c2, cd}) == 3,
        "basins_distinct_nonzero": r1 != 0 and r2 != 0 and r1 != r2,
        "p1_only_hits_r1": only_p1["P1"]["out"] == r1,
        "p1_only_p2_misses": only_p1["P2"]["out"] != r1,
        "both_p1_is_r1": both["P1"]["out"] == r1,
        "both_p2_is_r1": both["P2"]["out"] == r1,
        "distractor_not_r1": both["D"]["out"] != r1,
        "forget_not_r1": forget["out"] != r1,
        "remap_p1_is_r2": remap["P1"]["out"] == r2,
        "remap_p2_is_r2": remap["P2"]["out"] == r2,
        "remap_not_old_r1": remap["P1"]["out"] != r1,
    }
    return {
        "salt": salt,
        "reps": reps,
        "tokens": {"P1": list(t1), "P2": list(t2), "D": list(td)},
        "ctx": {"P1": c1, "P2": c2, "D": cd},
        "hamming": {
            "P1_P2": hamming8(c1, c2),
            "P1_D": hamming8(c1, cd),
            "P2_D": hamming8(c2, cd),
        },
        "basins": {"R1": r1, "R2": r2},
        "only_p1": only_p1,
        "both": both,
        "forget_out": forget["out"],
        "remap": remap,
        "gates": gates,
        "pass": all(gates.values()),
    }


def find_salt(limit: int = 0x20000) -> int | None:
    """Host-side search for a mixer salt. Not used at board time."""
    for salt in range(limit):
        if run_first_gate(salt=salt)["pass"]:
            return salt
    return None


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-05"
    out.mkdir(parents=True, exist_ok=True)
    ref = run_first_gate()
    (out / "reference.json").write_text(json.dumps(ref, indent=2) + "\n", encoding="utf-8")
    print("PASS" if ref["pass"] else "FAIL", json.dumps({
        "salt": hex(ref["salt"]),
        "tokens": ref["tokens"],
        "ctx": ref["ctx"],
        "hamming": ref["hamming"],
        "basins": {k: hex(v) for k, v in ref["basins"].items()},
        "gates": ref["gates"],
    }))
    if not ref["pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

"""M8-HW-06A golden: after-train infer + local basin decoder.

TRAIN may use a teacher. AFTER uses frozen W only.
Decoder maps FPGA out-codes → labels registered at TRAIN time.
It is not a prompt→response table.
"""
from __future__ import annotations

import json
from pathlib import Path

from python.m8_hw03_dense_reference import matrix_sha256
from python.m8_hw04_temporal_reference import TRAIN_REPS, probe
from python.m8_hw05_phrase_reference import (
    BASIN_R1,
    PHRASE_DISTRACTOR,
    PHRASE_P1,
    PHRASE_P2,
    encode_basin,
    encode_tokens,
    train_phrases,
)


class LocalBasinDecoder:
    """Codebook: learned 8-bit FPGA out → response text. No prompt keys."""

    def __init__(self) -> None:
        self.codebook: dict[int, str] = {}
        self.llm_calls = 0

    def register_target(self, response_text: str) -> int:
        code = encode_basin(response_text)
        self.codebook[code] = response_text
        return code

    def decode(self, fpga_out: int) -> str:
        if self.llm_calls != 0:
            raise RuntimeError("EXTERNAL LLM must stay 0")
        return self.codebook.get(int(fpga_out) & 0xFF, "")


class AfterTrainLatch:
    """One-way host switch. TRAIN frames become illegal."""

    def __init__(self) -> None:
        self.after = False
        self.train_cmds = 0
        self.sample_frames = 0
        self.probe_frames = 0
        self.dump_cmds = 0

    def enter_after(self) -> None:
        self.after = True

    def note_train(self) -> None:
        if self.after:
            raise RuntimeError("AFTER: TRAIN forbidden")
        self.train_cmds += 1

    def note_sample(self) -> None:
        if self.after:
            raise RuntimeError("AFTER: sample/teacher frame forbidden")
        self.sample_frames += 1

    def note_probe(self) -> None:
        self.probe_frames += 1

    def note_dump(self) -> None:
        self.dump_cmds += 1


def provenance(*, weight_writes: int, llm_calls: int) -> dict[str, str | int]:
    return {
        "INPUT SOURCE": "User",
        "ENCODER": "Local",
        "INFERENCE": "FPGA",
        "TEACHER": "DISCONNECTED",
        "EXTERNAL LLM": llm_calls,
        "WEIGHT WRITES": weight_writes,
        "LEARN": "OFF",
        "FREEZE": "ON",
    }


def format_provenance(block: dict[str, str | int]) -> str:
    lines = [f"{key:<18} {block[key]}" for key in (
        "INPUT SOURCE",
        "ENCODER",
        "INFERENCE",
        "TEACHER",
        "EXTERNAL LLM",
        "WEIGHT WRITES",
        "LEARN",
        "FREEZE",
    )]
    return "\n".join(lines)


def run_after_gate(reps: int = TRAIN_REPS) -> dict:
    latch = AfterTrainLatch()
    dec = LocalBasinDecoder()
    r1 = dec.register_target(BASIN_R1)
    latch.note_sample()
    w = train_phrases([PHRASE_P1, PHRASE_P2], BASIN_R1, reps)
    latch.note_train()
    sha_before = matrix_sha256(w)
    latch.enter_after()

    turns = []
    for text in (PHRASE_P1, PHRASE_P2, PHRASE_DISTRACTOR):
        latch.note_probe()
        rec = probe(w, list(encode_tokens(text)))
        label = dec.decode(rec["out"])
        turns.append({"text": text, "out": rec["out"], "decoded": label})

    sha_after = matrix_sha256(w)
    block = provenance(weight_writes=0, llm_calls=dec.llm_calls)
    gates = {
        "p1_out_is_r1": turns[0]["out"] == r1,
        "p1_decodes": turns[0]["decoded"] == BASIN_R1,
        "p2_decodes": turns[1]["decoded"] == BASIN_R1,
        "distractor_blank_or_other": turns[2]["decoded"] != BASIN_R1,
        "weights_frozen": sha_before == sha_after,
        "llm_zero": dec.llm_calls == 0,
        "after_no_train_raise": latch.after and latch.train_cmds == 1,
        "decoder_keys_are_ints": all(isinstance(k, int) for k in dec.codebook),
        "no_prompt_as_key": PHRASE_P1 not in dec.codebook and PHRASE_P2 not in dec.codebook,
    }
    return {
        "r1": r1,
        "sha": sha_before,
        "turns": turns,
        "provenance": block,
        "provenance_text": format_provenance(block),
        "gates": gates,
        "pass": all(gates.values()),
    }


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-06A"
    out.mkdir(parents=True, exist_ok=True)
    ref = run_after_gate()
    (out / "reference.json").write_text(json.dumps(ref, indent=2) + "\n", encoding="utf-8")
    print("PASS" if ref["pass"] else "FAIL")
    print(ref["provenance_text"])
    print(json.dumps({"turns": ref["turns"], "gates": ref["gates"]}, ensure_ascii=False))
    if not ref["pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

"""M8-HW-06B golden: FPGA-held multi-turn ctx + two name basins.

Host encoder is class-unaware. Names are not in RTL.
Learn only on the last token of the last turn.
"""
from __future__ import annotations

import json
from pathlib import Path

from python.m8_hw03_dense_reference import matrix_sha256
from python.m8_hw04_temporal_reference import TRAIN_REPS, probe, run_ctx, train_last, zero_matrix
from python.m8_hw05_phrase_reference import encode_basin, encode_tokens, hamming8
from python.m8_hw06a_reference import LocalBasinDecoder

TURN1_A = "Tên tôi là Quân"
TURN1_B = "Tên tôi là Lan"
TURN2 = "Xin chào"
TURN3 = "Tôi tên gì?"
NAME_A = "Quân"
NAME_B = "Lan"


def flatten_turns(*phrases: str) -> list[int]:
    seq: list[int] = []
    for phrase in phrases:
        seq.extend(encode_tokens(phrase))
    return seq


def ctx_of(*phrases: str) -> int:
    return run_ctx(flatten_turns(*phrases))


def train_histories(
    pairs: list[tuple[tuple[str, ...], str]],
    reps: int = TRAIN_REPS,
) -> list[list[int]]:
    w = zero_matrix()
    for _ in range(reps):
        for phrases, basin_text in pairs:
            w = train_last(w, ctx_of(*phrases), encode_basin(basin_text))
    return w


def run_first_gate(reps: int = TRAIN_REPS) -> dict:
    hist_a = (TURN1_A, TURN2, TURN3)
    hist_b = (TURN1_B, TURN2, TURN3)
    perm = (TURN2, TURN1_A, TURN3)
    only3 = (TURN3,)
    ca, cb, cp, c3 = ctx_of(*hist_a), ctx_of(*hist_b), ctx_of(*perm), ctx_of(*only3)
    ba, bb = encode_basin(NAME_A), encode_basin(NAME_B)

    dec = LocalBasinDecoder()
    dec.register_target(NAME_A)
    dec.register_target(NAME_B)

    w_a = train_histories([(hist_a, NAME_A)], reps)
    only_a = {
        "A": probe(w_a, flatten_turns(*hist_a)),
        "B": probe(w_a, flatten_turns(*hist_b)),
    }

    w = train_histories([(hist_a, NAME_A), (hist_b, NAME_B)], reps)
    both = {
        "A": probe(w, flatten_turns(*hist_a)),
        "B": probe(w, flatten_turns(*hist_b)),
        "PERM": probe(w, flatten_turns(*perm)),
        "T3": probe(w, flatten_turns(*only3)),
    }
    sha_before = matrix_sha256(w)
    after = {k: dec.decode(v["out"]) for k, v in both.items()}
    sha_after = matrix_sha256(w)
    forget = probe(zero_matrix(), flatten_turns(*hist_a))

    gates = {
        "ctx_all_distinct": len({ca, cb, cp, c3}) == 4,
        "basins_distinct_nonzero": ba != 0 and bb != 0 and ba != bb,
        "only_a_hits": only_a["A"]["out"] == ba,
        "only_a_b_misses": only_a["B"]["out"] != ba,
        "both_a_is_a": both["A"]["out"] == ba,
        "both_b_is_b": both["B"]["out"] == bb,
        "t3_not_a": both["T3"]["out"] != ba,
        "t3_not_b": both["T3"]["out"] != bb,
        "perm_not_a": both["PERM"]["out"] != ba,
        "decode_a": after["A"] == NAME_A,
        "decode_b": after["B"] == NAME_B,
        "decode_t3_blank": after["T3"] not in {NAME_A, NAME_B},
        "decode_perm_not_a": after["PERM"] != NAME_A,
        "forget_not_a": forget["out"] != ba,
        "weights_frozen": sha_before == sha_after,
        "no_name_as_key": NAME_A not in dec.codebook and NAME_B not in dec.codebook,
    }
    return {
        "reps": reps,
        "ctx": {"A": ca, "B": cb, "PERM": cp, "T3": c3},
        "hamming": {
            "A_B": hamming8(ca, cb),
            "A_PERM": hamming8(ca, cp),
            "A_T3": hamming8(ca, c3),
            "B_T3": hamming8(cb, c3),
        },
        "basins": {"A": ba, "B": bb},
        "tokens": {
            "T1A": list(encode_tokens(TURN1_A)),
            "T1B": list(encode_tokens(TURN1_B)),
            "T2": list(encode_tokens(TURN2)),
            "T3": list(encode_tokens(TURN3)),
        },
        "only_a": only_a,
        "both": both,
        "decoded": after,
        "forget_out": forget["out"],
        "sha": sha_before,
        "gates": gates,
        "pass": all(gates.values()),
    }


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-06B"
    out.mkdir(parents=True, exist_ok=True)
    ref = run_first_gate()
    (out / "reference.json").write_text(json.dumps(ref, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("PASS" if ref["pass"] else "FAIL", json.dumps({
        "ctx": ref["ctx"],
        "hamming": ref["hamming"],
        "basins": {k: hex(v) for k, v in ref["basins"].items()},
        "decoded": ref["decoded"],
        "gates": ref["gates"],
    }, ensure_ascii=False))
    if not ref["pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

"""Bit-exact M8-HW-03 dense bipolar outer-product golden."""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path

INITIAL_CROSS = 64
WEIGHT_LIMIT = 2047
DENSE_LR = 8
STIM_A = 0xB4  # 10110100
TEACH_A = 0x6B  # 01101011
STIM_B = 0x4B  # invert of A
TEACH_B = 0x6B


def pm1(byte: int, bit: int) -> int:
    return 1 if ((byte >> bit) & 1) else -1


def clip_weight(value: int, limit: int = WEIGHT_LIMIT) -> int:
    if value > limit:
        return limit
    if value < -limit:
        return -limit
    return value


def neutral_matrix() -> list[list[int]]:
    return [[0 if d == s else INITIAL_CROSS for s in range(8)] for d in range(8)]


def matrix_sha256(mat: list[list[int]]) -> str:
    raw = b"".join(int(mat[d][s]).to_bytes(2, "little", signed=True) for d in range(8) for s in range(8))
    return hashlib.sha256(raw).hexdigest().upper()


def one_dense_train(
    weights: list[list[int]],
    stimulus: int,
    teacher: int,
    lr: int = DENSE_LR,
    learn: bool = True,
    freeze: bool = False,
    teacher_connected: bool = True,
) -> dict:
    before = deepcopy(weights)
    after = deepcopy(weights)
    delta = [[0] * 8 for _ in range(8)]
    changed = 0
    write = bool(learn and (not freeze) and teacher_connected)
    if write:
        for d in range(8):
            for s in range(8):
                dw = lr * pm1(teacher, d) * pm1(stimulus, s)
                nw = clip_weight(before[d][s] + dw)
                after[d][s] = nw
                delta[d][s] = nw - before[d][s]
                if nw != before[d][s]:
                    changed += 1
    return {
        "stimulus": stimulus,
        "teacher": teacher,
        "lr": lr,
        "learn": int(learn),
        "freeze": int(freeze),
        "teacher_connected": int(teacher_connected),
        "write": int(write),
        "changed_cell_count": changed,
        "expected_before": before,
        "expected_delta": delta,
        "expected_after": after,
        "before_sha256": matrix_sha256(before),
        "after_sha256": matrix_sha256(after),
        "matrix_sha256": matrix_sha256(after),
    }


def run_controls(lr: int = DENSE_LR) -> dict:
    w0 = neutral_matrix()
    dense_a = one_dense_train(w0, STIM_A, TEACH_A, lr=lr)
    freeze = one_dense_train(dense_a["expected_after"], STIM_A, TEACH_A, lr=lr, learn=True, freeze=True)
    teacher_off = one_dense_train(w0, STIM_A, TEACH_A, lr=lr, teacher_connected=False)
    dense_b = one_dense_train(w0, STIM_B, TEACH_B, lr=lr)
    return {
        "lr": lr,
        "stim_a": STIM_A,
        "teach_a": TEACH_A,
        "stim_b": STIM_B,
        "teach_b": TEACH_B,
        "dense_a": dense_a,
        "dense_b": dense_b,
        "freeze": freeze,
        "teacher_off": teacher_off,
    }


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-03"
    out.mkdir(parents=True, exist_ok=True)
    ref = run_controls()
    slim = json.loads(json.dumps(ref))
    (out / "reference.json").write_text(json.dumps(slim, indent=2) + "\n", encoding="utf-8")
    print(
        "A",
        ref["dense_a"]["changed_cell_count"],
        ref["dense_a"]["matrix_sha256"][:16],
        "B",
        ref["dense_b"]["changed_cell_count"],
        "F",
        ref["freeze"]["changed_cell_count"],
        "OFF",
        ref["teacher_off"]["changed_cell_count"],
    )


if __name__ == "__main__":
    main()

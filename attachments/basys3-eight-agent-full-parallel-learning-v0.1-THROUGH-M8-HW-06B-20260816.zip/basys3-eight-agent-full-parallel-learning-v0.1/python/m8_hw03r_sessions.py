"""Deterministic mixed-polarity session pairs for M8-HW-03R."""
from __future__ import annotations

import random


def mixed_byte(rng: random.Random) -> int:
    while True:
        v = rng.randrange(1, 255)
        ones = bin(v).count("1")
        if 1 <= ones <= 7:
            return v


def session_pair(seed: int) -> tuple[int, int]:
    rng = random.Random(seed)
    return mixed_byte(rng), mixed_byte(rng)

"""Canonical M8-HW-02 session permutations.

Seeds are provenance only. The eight destination bytes are the experiment
definition so a future RNG change cannot rewrite the board contract.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path

# Explicit contract from deep-research-report.md — do not regenerate via RNG.
SESSIONS: dict[int, tuple[int, ...]] = {
    2026081401: (1, 7, 4, 5, 3, 2, 0, 6),
    2026081403: (5, 6, 0, 1, 7, 3, 2, 4),
}
CYCLIC = (1, 2, 3, 4, 5, 6, 7, 0)


def permutation(seed: int) -> tuple[int, ...]:
    if seed not in SESSIONS:
        raise KeyError(f"unknown session seed {seed}; canonical keys are {sorted(SESSIONS)}")
    return SESSIONS[seed]


def teacher_code(source_idx: int, perm: tuple[int, ...]) -> int:
    return 1 << perm[source_idx]


def source_code(source_idx: int) -> int:
    return 1 << source_idx


def hamming_perm(a: tuple[int, ...], b: tuple[int, ...]) -> int:
    return sum(x != y for x, y in zip(a, b, strict=True))


def is_derangement(perm: tuple[int, ...]) -> bool:
    return all(perm[i] != i for i in range(len(perm)))


def session_manifest(seed: int) -> dict:
    perm = permutation(seed)
    return {
        "seed": seed,
        "permutation": list(perm),
        "derangement": is_derangement(perm),
        "distance_from_cyclic": hamming_perm(perm, CYCLIC),
        "map": {str(s): perm[s] for s in range(8)},
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()
    man = session_manifest(args.seed)
    text = json.dumps(man, indent=2)
    print(text)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

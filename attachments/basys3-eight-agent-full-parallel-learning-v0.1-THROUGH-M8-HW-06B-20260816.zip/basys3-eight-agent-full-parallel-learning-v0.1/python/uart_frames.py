"""15-byte UART helpers for A5 5A/5C/5D/5E/5F."""
from __future__ import annotations

FRAME_LEN = 15


def xor14(payload: bytes) -> int:
    chk = 0
    for b in payload[:14]:
        chk ^= b
    return chk & 0xFF


def pack15(kind: int, body12: bytes) -> bytes:
    if len(body12) != 12:
        raise ValueError("body must be 12 bytes")
    head = bytes([0xA5, kind]) + body12
    return head + bytes([xor14(head)])


def session_frame(seed: int, perm: tuple[int, ...] | list[int]) -> bytes:
    body = seed.to_bytes(4, "little") + bytes(perm)
    return pack15(0x5E, body)


def command_frame(cmd: int) -> bytes:
    return pack15(0x5F, bytes([cmd]) + bytes(11))


def dense_sample_frame(stim: int, teacher: int, lr: int = 8) -> bytes:
    return pack15(0x60, bytes([stim & 0xFF, teacher & 0xFF, lr & 0xFF]) + bytes(9))


def temporal_sample_frame(a: int, b: int, c: int, x: int, hold: int = 0) -> bytes:
    return pack15(0x62, bytes([a & 0xFF, b & 0xFF, c & 0xFF, x & 0xFF, hold & 1]) + bytes(7))


def temporal_probe_frame(n: int, s0: int, s1: int, s2: int = 0, hold: int = 0) -> bytes:
    return pack15(0x63, bytes([n & 0xFF, s0 & 0xFF, s1 & 0xFF, s2 & 0xFF, hold & 1]) + bytes(7))


def phrase_sample_frame(
    tokens: tuple[int, int, int] | list[int], basin: int, hold: int = 0
) -> bytes:
    s0, s1, s2 = tokens
    return temporal_sample_frame(s0, s1, s2, basin, hold)


def phrase_probe_frame(tokens: tuple[int, int, int] | list[int], hold: int = 0) -> bytes:
    s0, s1, s2 = tokens
    return temporal_probe_frame(3, s0, s1, s2, hold)


def parse_frame(frame: bytes) -> dict:
    if len(frame) != FRAME_LEN or frame[0] != 0xA5 or xor14(frame) != frame[14]:
        return {"ok": False}
    kind = frame[1]
    rec: dict = {"ok": True, "kind": kind, "raw": frame}
    if kind == 0x5A:
        rec.update(
            tick=frame[2] | (frame[3] << 8),
            updates=frame[4] | (frame[5] << 8),
            mismatch=frame[6] | (frame[7] << 8),
            weight=int.from_bytes(frame[8:10], "little", signed=True),
            inp=frame[10],
            out=frame[11],
            phase=frame[12] & 0xF,
            flags=frame[13],
        )
    elif kind == 0x5C:
        rec.update(
            before_mis=frame[2] | (frame[3] << 8),
            after_mis=frame[4] | (frame[5] << 8),
            before_hits=frame[6],
            after_hits=frame[7],
            routes=frame[8],
            final=(frame[9] >> 7) & 1,
            freeze=(frame[9] >> 6) & 1,
            phase=frame[9] & 0xF,
        )
    elif kind == 0x5D:
        rec.update(
            snapshot=frame[2],
            seq=frame[3],
            page=frame[4],
            weights=[
                int.from_bytes(frame[5:7], "little", signed=True),
                int.from_bytes(frame[7:9], "little", signed=True),
                int.from_bytes(frame[9:11], "little", signed=True),
                int.from_bytes(frame[11:13], "little", signed=True),
            ],
            phase=frame[13] & 0xF,
        )
    elif kind == 0x5E:
        rec.update(
            seed=int.from_bytes(frame[2:6], "little"),
            perm=list(frame[6:14]),
        )
    elif kind == 0x60:
        rec.update(stim=frame[2], teacher=frame[3], lr=frame[4])
    elif kind == 0x62:
        rec.update(a=frame[2], b=frame[3], c=frame[4], x=frame[5], hold=frame[6] & 1)
    elif kind == 0x63:
        rec.update(n=frame[2], s0=frame[3], s1=frame[4], s2=frame[5], hold=frame[6] & 1)
    elif kind == 0x64:
        rec.update(
            ctx=frame[2],
            out=frame[3],
            target=frame[4],
            match=frame[5] & 1,
            phase=frame[6] & 0xF,
            snapshot=frame[7],
        )
    elif kind == 0x61:
        rec.update(
            stim=frame[2],
            teacher=frame[3],
            changed_cell_count=frame[4],
            learn=frame[5] & 1,
            freeze=(frame[5] >> 1) & 1,
            tick=frame[6] | (frame[7] << 8),
            updates=frame[8] | (frame[9] << 8),
            phase=frame[10] & 0xF,
            flags=frame[11],
            snapshot=frame[12],
        )
    return rec


def matrix_from_pages(pages: dict[int, list[int]]) -> list[list[int]]:
    cells = [0] * 64
    for page, ws in pages.items():
        for i, w in enumerate(ws):
            cells[page * 4 + i] = w
    return [cells[d * 8 : (d + 1) * 8] for d in range(8)]

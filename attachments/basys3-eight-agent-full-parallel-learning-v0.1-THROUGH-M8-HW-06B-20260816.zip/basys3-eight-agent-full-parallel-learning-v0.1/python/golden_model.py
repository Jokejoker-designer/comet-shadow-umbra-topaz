from __future__ import annotations

from dataclasses import dataclass
import random
from typing import Iterable

N = 8
W_MIN = -2048
W_MAX = 2047

# Sylvester-Hadamard rows encoded as 8 bipolar bits.
# This is a neutral signal basis, not a semantic assignment.
ORTHOGONAL_CODES = (0xFF, 0x55, 0x33, 0x99, 0x0F, 0xA5, 0xC3, 0x69)

def bipolar(code: int) -> list[int]:
    return [1 if ((code >> i) & 1) else -1 for i in range(N)]

def clip(v: int) -> int:
    return max(W_MIN, min(W_MAX, int(v)))

@dataclass(frozen=True)
class Inference:
    output_code: int
    scores: tuple[int, ...]
    frozen: bool
    updates: int

class FullParallelEightAgent:
    """Bit-exact conceptual model for 64 fully parallel synapses."""

    def __init__(self, learning_rate: int = 1):
        self.learning_rate = int(learning_rate)
        self.reset()

    def reset(self) -> None:
        self.weights = [[0 for _ in range(N)] for _ in range(N)]
        self.updates = 0
        self.frozen = False

    def set_freeze(self, freeze: bool) -> None:
        self.frozen = bool(freeze)

    def infer(self, stimulus_code: int) -> Inference:
        x = bipolar(stimulus_code)
        scores = []
        out = 0
        for d in range(N):
            score = sum(self.weights[d][s] * x[s] for s in range(N))
            scores.append(score)
            if score > 0:
                out |= (1 << d)
        return Inference(out, tuple(scores), self.frozen, self.updates)

    def train(self, stimulus_code: int, teacher_code: int) -> None:
        if self.frozen:
            return
        x = bipolar(stimulus_code)
        y = bipolar(teacher_code)

        # Full outer product: all 64 lanes update every training transaction.
        for d in range(N):
            for s in range(N):
                self.weights[d][s] = clip(
                    self.weights[d][s] + self.learning_rate * y[d] * x[s]
                )
        self.updates += 1

    def train_epoch(self, pairs: Iterable[tuple[int, int]]) -> None:
        for stimulus, teacher in pairs:
            self.train(stimulus, teacher)

    def exact_accuracy(self, pairs: Iterable[tuple[int, int]]) -> float:
        pairs = list(pairs)
        if not pairs:
            return 0.0
        correct = sum(self.infer(x).output_code == y for x, y in pairs)
        return correct / len(pairs)

def random_session(seed: int) -> list[tuple[int, int]]:
    """Create a new arbitrary mapping every session.

    Both stimulus-code assignment and response-code assignment are permuted.
    No semantic identity is stable across seeds.
    """
    rng = random.Random(seed)
    inputs = list(ORTHOGONAL_CODES)
    outputs = list(ORTHOGONAL_CODES)
    rng.shuffle(inputs)
    rng.shuffle(outputs)
    permutation = list(range(N))
    rng.shuffle(permutation)
    return [(inputs[i], outputs[permutation[i]]) for i in range(N)]

def run_blind_session(seed: int) -> dict:
    model = FullParallelEightAgent(learning_rate=1)
    pairs = random_session(seed)

    before = model.exact_accuracy(pairs)
    model.train_epoch(pairs)
    after = model.exact_accuracy(pairs)

    model.set_freeze(True)
    frozen_weights = tuple(tuple(row) for row in model.weights)
    frozen_updates = model.updates
    frozen_acc = model.exact_accuracy(pairs)

    # Attempted training while frozen must be a no-op.
    model.train_epoch(reversed(pairs))
    freeze_holds = (
        frozen_weights == tuple(tuple(row) for row in model.weights)
        and frozen_updates == model.updates
    )

    model.reset()
    after_reset = model.exact_accuracy(pairs)

    return {
        "seed": seed,
        "before_accuracy": before,
        "after_accuracy": after,
        "frozen_accuracy": frozen_acc,
        "freeze_holds": freeze_holds,
        "after_reset_accuracy": after_reset,
        "updates": frozen_updates,
    }

"""Reference model matching the board-default 8-agent route-gate SNN."""
from __future__ import annotations
from dataclasses import dataclass

N = 8
THRESHOLD = 512
LEAK_SHIFT = 3
INITIAL = 64
LIMIT = 2047
GATE_TH = 256
GATE_I = 560
TRACE_INC = 32
LEARN_SHIFT = 2


def sat16(v: int) -> int:
    return max(-32768, min(32767, int(v)))


def clip_w(v: int) -> int:
    return max(-LIMIT, min(LIMIT, int(v)))


@dataclass
class Snapshot:
    inp: int
    out: int
    weights: list[list[int]]
    mismatch: int


class EightAgentRouteGate:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.mem = [0] * N
        self.weights = [[0 if d == s else INITIAL for s in range(N)] for d in range(N)]
        self.mismatch = 0

    def context(self, spikes: int) -> list[int]:
        ctx = [0] * N
        for d in range(N):
            for s in range(N):
                if ((spikes >> s) & 1) and self.weights[d][s] > GATE_TH:
                    ctx[d] = GATE_I
        return ctx

    def tick(self, source: int, teacher: int, *, learn: bool) -> Snapshot:
        ctx = self.context(source)
        out = 0
        for a in range(N):
            leaked = self.mem[a] if LEAK_SHIFT == 0 else self.mem[a] - (self.mem[a] >> LEAK_SHIFT)
            nxt = leaked + ctx[a]
            if nxt >= THRESHOLD:
                out |= 1 << a
                nxt -= THRESHOLD
            self.mem[a] = sat16(max(-8192, min(8191, nxt)))
        if learn:
            for d in range(N):
                for s in range(N):
                    if d == s:
                        continue
                    pot = TRACE_INC if ((teacher >> d) & 1) and ((source >> s) & 1) else 0
                    dep = TRACE_INC if ((out >> d) & 1) and not ((teacher >> d) & 1) and ((source >> s) & 1) else 0
                    self.weights[d][s] = clip_w(self.weights[d][s] + ((pot - dep) >> LEARN_SHIFT))
        self.mismatch += sum(((out >> i) & 1) != ((teacher >> i) & 1) for i in range(N))
        return Snapshot(source, out, [row[:] for row in self.weights], self.mismatch)

    def eval_exact(self, n: int = 32) -> int:
        self.mem = [0] * N
        hits = 0
        for i in range(n):
            src = i % N
            snap = self.tick(1 << src, 1 << ((src + 1) % N), learn=False)
            if snap.out == (1 << ((src + 1) % N)):
                hits += 1
        self.mem = [0] * N
        return hits

"""Deterministic M8-HW-02 golden reference (one-hot remapping, 32 epochs)."""
from __future__ import annotations
import argparse
import json
from pathlib import Path

from python.reference_model import EightAgentRouteGate, INITIAL
from python.session_permutation import (
    CYCLIC,
    hamming_perm,
    permutation,
    source_code,
    teacher_code,
)


def eval_perm(model: EightAgentRouteGate, perm: tuple[int, ...], n: int = 32) -> int:
    model.mem = [0] * 8
    hits = 0
    for i in range(n):
        s = i % 8
        snap = model.tick(source_code(s), teacher_code(s, perm), learn=False)
        if snap.out == teacher_code(s, perm):
            hits += 1
    model.mem = [0] * 8
    return hits


def train_epochs(model: EightAgentRouteGate, perm: tuple[int, ...], epochs: int) -> int:
    updates = 0
    for _ in range(epochs):
        for s in range(8):
            model.tick(source_code(s), teacher_code(s, perm), learn=True)
            updates += 1
    return updates


def matrix(model: EightAgentRouteGate) -> list[list[int]]:
    return [row[:] for row in model.weights]


def run(seed_a: int, seed_b: int, epochs: int) -> dict:
    pa = permutation(seed_a)
    pb = permutation(seed_b)
    model = EightAgentRouteGate()

    a_before = eval_perm(model, pa, 32)
    train_epochs(model, pa, epochs)
    a_after = eval_perm(model, pa, 32)
    a_hold = eval_perm(model, pa, 32)
    a_matrix = matrix(model)
    a_targets = [a_matrix[pa[s]][s] for s in range(8)]

    model.reset()
    reset_matrix = matrix(model)
    a_forget = eval_perm(model, pa, 32)

    b_before = eval_perm(model, pb, 32)
    train_epochs(model, pb, epochs)
    b_after = eval_perm(model, pb, 32)
    b_hold = eval_perm(model, pb, 32)
    b_matrix = matrix(model)
    b_targets = [b_matrix[pb[s]][s] for s in range(8)]

    expected_w = INITIAL + epochs * 8
    return {
        "seed_a": seed_a,
        "seed_b": seed_b,
        "perm_a": list(pa),
        "perm_b": list(pb),
        "a_b_distance": hamming_perm(pa, pb),
        "a_cyclic_distance": hamming_perm(pa, CYCLIC),
        "b_cyclic_distance": hamming_perm(pb, CYCLIC),
        "epochs": epochs,
        "expected_target_w": expected_w,
        "a_before": a_before,
        "a_after": a_after,
        "a_hold": a_hold,
        "a_targets": a_targets,
        "a_forget": a_forget,
        "b_before": b_before,
        "b_after": b_after,
        "b_hold": b_hold,
        "b_targets": b_targets,
        "reset_neutral": all(
            reset_matrix[d][s] == (0 if d == s else INITIAL) for d in range(8) for s in range(8)
        ),
        "a_matrix": a_matrix,
        "reset_matrix": reset_matrix,
        "b_matrix": b_matrix,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed-a", type=int, default=2026081401)
    ap.add_argument("--seed-b", type=int, default=2026081403)
    ap.add_argument("--epochs", type=int, default=32)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()
    result = run(args.seed_a, args.seed_b, args.epochs)
    text = json.dumps(result, indent=2)
    print(text)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

"""Fail if functional RTL contains M8-HW-02 session constants."""
from __future__ import annotations
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl"

needles = [
    "2026081401",
    "2026081403",
    "1, 7, 4, 5, 3, 2, 0, 6",
    "5, 6, 0, 1, 7, 3, 2, 4",
    "8'd1, 8'd7, 8'd4, 8'd5",
    "8'd5, 8'd6, 8'd0, 8'd1",
    "8'hB4",
    "8'h6B",
    "8'h4B",
    "10110100",
    "01101011",
]

bad = []
for path in RTL.rglob("*.sv"):
    text = path.read_text(encoding="utf-8", errors="replace")
    for needle in needles:
        if needle in text:
            bad.append((str(path.relative_to(ROOT)), needle))

if bad:
    print("MAPPING-CONSTANT FAIL: session maps must not live in RTL")
    for row in bad:
        print(row)
    sys.exit(1)

print("MAPPING-CONSTANT PASS: A/B permutations absent from rtl/")

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
python -m pytest -q
python .\scripts\verify_no_semantic_hardcode.py
python -m python.blind_challenge --sessions 32

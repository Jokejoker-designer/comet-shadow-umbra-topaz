@echo off
setlocal
where vivado >nul 2>nul
if errorlevel 1 (
  echo ERROR: vivado is not in PATH.
  echo Example: set PATH=C:\Xilinx\Vivado\2026.1\bin;%%PATH%%
  exit /b 1
)
vivado -mode batch -nojournal -nolog -source vivado\build_basys3.tcl
exit /b %ERRORLEVEL%

from pathlib import Path

from python.m8_hw06b_reference import (
    NAME_A,
    NAME_B,
    TURN1_A,
    TURN1_B,
    TURN3,
    flatten_turns,
    run_first_gate,
)

ROOT = Path(__file__).resolve().parents[1]


def test_multi_turn_gate():
    r = run_first_gate()
    assert r["pass"]
    assert r["decoded"]["A"] == NAME_A
    assert r["decoded"]["B"] == NAME_B
    assert r["decoded"]["T3"] == ""
    assert r["decoded"]["PERM"] != NAME_A


def test_histories_are_longer_than_one_phrase():
    assert len(flatten_turns(TURN1_A, "Xin chào", TURN3)) == 9
    assert flatten_turns(TURN1_A) != flatten_turns(TURN1_B)


def test_rtl_has_no_names():
    needles = ("Quân", "Lan", "Tên tôi", "Tôi tên", "Xin chào")
    hits = []
    for path in (ROOT / "rtl").rglob("*.sv"):
        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in needles:
            if needle in text:
                hits.append((path.name, needle))
    assert hits == []

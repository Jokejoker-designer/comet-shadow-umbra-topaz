from python.m8_hw03_dense_reference import (
    STIM_A,
    STIM_B,
    TEACH_A,
    matrix_sha256,
    neutral_matrix,
    one_dense_train,
    pm1,
    run_controls,
)


def test_polarities_mixed():
    assert bin(STIM_A).count("1") not in (0, 8)
    assert bin(TEACH_A).count("1") not in (0, 8)
    assert STIM_B == (STIM_A ^ 0xFF)


def test_dense_a_changes_64():
    r = one_dense_train(neutral_matrix(), STIM_A, TEACH_A)
    assert r["changed_cell_count"] == 64
    for d in range(8):
        for s in range(8):
            assert r["expected_delta"][d][s] == 8 * pm1(TEACH_A, d) * pm1(STIM_A, s)
            assert r["expected_after"][d][s] != r["expected_before"][d][s]


def test_dense_b_changes_64_and_differs_from_a():
    a = one_dense_train(neutral_matrix(), STIM_A, TEACH_A)
    b = one_dense_train(neutral_matrix(), STIM_B, TEACH_A)
    assert b["changed_cell_count"] == 64
    assert a["matrix_sha256"] != b["matrix_sha256"]


def test_freeze_and_teacher_off_write_nothing():
    trained = one_dense_train(neutral_matrix(), STIM_A, TEACH_A)["expected_after"]
    fr = one_dense_train(trained, STIM_A, TEACH_A, freeze=True)
    off = one_dense_train(neutral_matrix(), STIM_A, TEACH_A, teacher_connected=False)
    assert fr["changed_cell_count"] == 0
    assert off["changed_cell_count"] == 0
    assert fr["expected_after"] == trained
    assert off["expected_after"] == neutral_matrix()
    assert matrix_sha256(off["expected_after"]) == matrix_sha256(neutral_matrix())


def test_controls_bundle_and_stable_sha():
    c = run_controls()
    assert c["dense_a"]["changed_cell_count"] == 64
    assert c["dense_b"]["changed_cell_count"] == 64
    assert c["freeze"]["changed_cell_count"] == 0
    assert c["teacher_off"]["changed_cell_count"] == 0
    assert len(c["dense_a"]["matrix_sha256"]) == 64

from pathlib import Path

import pytest

from python.m8_hw06a_reference import (
    AfterTrainLatch,
    LocalBasinDecoder,
    format_provenance,
    provenance,
    run_after_gate,
)
from python.m8_hw05_phrase_reference import BASIN_R1, PHRASE_P1, encode_basin

ROOT = Path(__file__).resolve().parents[1]


def test_after_gate_decodes_without_teacher():
    r = run_after_gate()
    assert r["pass"]
    assert r["turns"][0]["decoded"] == BASIN_R1
    assert r["turns"][1]["decoded"] == BASIN_R1
    assert r["turns"][2]["decoded"] != BASIN_R1


def test_decoder_is_not_prompt_table():
    dec = LocalBasinDecoder()
    code = dec.register_target(BASIN_R1)
    assert code == encode_basin(BASIN_R1)
    assert dec.decode(code) == BASIN_R1
    assert dec.decode(0) == ""
    assert PHRASE_P1 not in dec.codebook
    assert all(isinstance(k, int) for k in dec.codebook)


def test_after_latch_forbids_train_and_teacher():
    latch = AfterTrainLatch()
    latch.note_train()
    latch.enter_after()
    with pytest.raises(RuntimeError, match="TRAIN"):
        latch.note_train()
    with pytest.raises(RuntimeError, match="sample"):
        latch.note_sample()
    latch.note_probe()
    latch.note_dump()


def test_provenance_block_has_required_rows():
    text = format_provenance(provenance(weight_writes=0, llm_calls=0))
    for needle in (
        "INPUT SOURCE       User",
        "ENCODER            Local",
        "INFERENCE          FPGA",
        "TEACHER            DISCONNECTED",
        "EXTERNAL LLM       0",
        "WEIGHT WRITES      0",
        "LEARN              OFF",
        "FREEZE             ON",
    ):
        assert needle in text


def test_rtl_has_no_06a_strings():
    needles = ("xin chào", "chào bạn", "hello", "conversation")
    hits = []
    for path in (ROOT / "rtl").rglob("*.sv"):
        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in needles:
            if needle.lower() in text.lower():
                hits.append((path.name, needle))
    assert hits == []

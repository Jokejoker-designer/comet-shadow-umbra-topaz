from python.golden_model import (
    FullParallelEightAgent,
    ORTHOGONAL_CODES,
    random_session,
    run_blind_session,
)

def test_all_64_weights_can_move_in_one_training_sample():
    m = FullParallelEightAgent()
    m.train(0x55, 0xA5)
    changed = sum(w != 0 for row in m.weights for w in row)
    assert changed == 64

def test_no_mapping_before_training_and_perfect_after_training():
    pairs = random_session(7)
    m = FullParallelEightAgent()
    assert m.exact_accuracy(pairs) < 1.0
    m.train_epoch(pairs)
    assert m.exact_accuracy(pairs) == 1.0

def test_freeze_holds_and_reset_erases():
    pairs = random_session(12)
    m = FullParallelEightAgent()
    m.train_epoch(pairs)
    assert m.exact_accuracy(pairs) == 1.0

    m.set_freeze(True)
    before = [row[:] for row in m.weights]
    updates = m.updates
    m.train_epoch(pairs)
    assert m.weights == before
    assert m.updates == updates

    m.reset()
    assert all(w == 0 for row in m.weights for w in row)
    assert m.exact_accuracy(pairs) < 1.0

def test_32_random_blind_sessions():
    for seed in range(32):
        r = run_blind_session(seed)
        assert r["before_accuracy"] < 1.0
        assert r["after_accuracy"] == 1.0
        assert r["frozen_accuracy"] == 1.0
        assert r["freeze_holds"]
        assert r["after_reset_accuracy"] < 1.0

def test_different_sessions_are_actually_different():
    assert random_session(1) != random_session(2)

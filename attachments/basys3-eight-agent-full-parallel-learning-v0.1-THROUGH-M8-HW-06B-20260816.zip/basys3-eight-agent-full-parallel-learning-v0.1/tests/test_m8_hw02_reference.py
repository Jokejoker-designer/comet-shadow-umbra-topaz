from python.m8_hw02_reference import run
from python.session_permutation import CYCLIC, hamming_perm, permutation, session_manifest


def test_canonical_permutations():
    a = permutation(2026081401)
    b = permutation(2026081403)
    assert a == (1, 7, 4, 5, 3, 2, 0, 6)
    assert b == (5, 6, 0, 1, 7, 3, 2, 4)
    assert hamming_perm(a, CYCLIC) == 7
    assert hamming_perm(b, CYCLIC) == 8
    assert hamming_perm(a, b) == 8
    assert session_manifest(2026081401)["derangement"]


def test_reference_a_reset_b():
    r = run(2026081401, 2026081403, 32)
    assert r["a_before"] <= 8
    assert r["a_after"] == 32
    assert r["a_hold"] == 32
    assert r["a_targets"] == [320] * 8
    assert r["reset_neutral"]
    assert r["a_forget"] <= 8
    assert r["b_before"] <= 8
    assert r["b_after"] == 32
    assert r["b_hold"] == 32
    assert r["b_targets"] == [320] * 8
    assert r["a_b_distance"] == 8

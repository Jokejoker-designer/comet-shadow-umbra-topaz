from python.m8_hw04_temporal_reference import (
    SYM_A,
    SYM_B,
    SYM_C,
    SYM_X,
    run_ctx,
    run_first_gate,
    step_ctx,
)


def test_binder_is_noncommutative():
    abc = run_ctx([SYM_A, SYM_B, SYM_C])
    acb = run_ctx([SYM_A, SYM_C, SYM_B])
    bac = run_ctx([SYM_B, SYM_A, SYM_C])
    ab = run_ctx([SYM_A, SYM_B])
    assert len({abc, acb, bac, ab}) == 4
    assert bin(abc ^ acb).count("1") >= 2
    assert bin(abc ^ bac).count("1") >= 2


def test_first_gate_order_and_forget():
    r = run_first_gate()
    assert r["pass"]
    assert r["abc_is_x"]
    assert r["acb_not_x"]
    assert r["bac_not_x"]
    assert r["ab_not_x"]
    assert r["forget_not_x"]


def test_step_matches_formula():
    # rotl(0,3) ^ A ^ rotl(A,2) == A ^ rotl(A, 2)
    assert step_ctx(0, SYM_A) == (SYM_A ^ ((SYM_A << 2 | SYM_A >> 6) & 0xFF))

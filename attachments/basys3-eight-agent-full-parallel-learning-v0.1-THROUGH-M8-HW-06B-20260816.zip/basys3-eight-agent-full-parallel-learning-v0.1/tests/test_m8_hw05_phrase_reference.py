from pathlib import Path

from python.m8_hw05_phrase_reference import (
    BASIN_R1,
    BASIN_R2,
    ENCODER_SALT,
    PHRASE_DISTRACTOR,
    PHRASE_P1,
    PHRASE_P2,
    encode_basin,
    encode_tokens,
    hamming8,
    run_first_gate,
)
from python.m8_hw04_temporal_reference import run_ctx

ROOT = Path(__file__).resolve().parents[1]


def test_encoder_is_class_unaware():
    assert encode_tokens.__code__.co_argcount == 2  # text, salt
    assert "response" not in encode_tokens.__code__.co_varnames
    assert "cls" not in encode_tokens.__code__.co_varnames
    assert "intent" not in encode_tokens.__code__.co_varnames


def test_encoder_salt_is_zero():
    assert ENCODER_SALT == 0


def test_demo_tokens_are_distinct_and_stable():
    t1 = encode_tokens(PHRASE_P1)
    t2 = encode_tokens(PHRASE_P2)
    td = encode_tokens(PHRASE_DISTRACTOR)
    assert t1 == (80, 90, 238)
    assert t2 == (141, 34, 204)
    assert td == (120, 201, 119)
    assert t1 != t2 != td
    c1, c2 = run_ctx(list(t1)), run_ctx(list(t2))
    assert 4 <= hamming8(c1, c2) <= 7


def test_first_gate_basin_and_forget_and_remap():
    r = run_first_gate()
    assert r["pass"]
    assert r["gates"]["both_p1_is_r1"]
    assert r["gates"]["both_p2_is_r1"]
    assert r["gates"]["distractor_not_r1"]
    assert r["gates"]["p1_only_p2_misses"]
    assert r["gates"]["forget_not_r1"]
    assert r["gates"]["remap_p1_is_r2"]
    assert r["gates"]["remap_not_old_r1"]
    assert encode_basin(BASIN_R1) == r["basins"]["R1"]
    assert encode_basin(BASIN_R2) == r["basins"]["R2"]


def test_rtl_has_no_demo_phrases_or_hello_id():
    needles = (
        "xin chào",
        "hello",
        "chào bạn",
        "tạm biệt",
        "rất vui",
        "HELLO",
        "ASK_NAME",
    )
    hits = []
    for path in (ROOT / "rtl").rglob("*.sv"):
        text = path.read_text(encoding="utf-8", errors="replace")
        for needle in needles:
            if needle in text:
                hits.append((path.name, needle))
    assert hits == []

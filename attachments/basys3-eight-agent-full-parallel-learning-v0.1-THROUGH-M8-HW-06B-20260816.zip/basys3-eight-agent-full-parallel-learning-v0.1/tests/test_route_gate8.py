from python.reference_model import EightAgentRouteGate, INITIAL, GATE_TH


def test_weights_start_neutral():
    m = EightAgentRouteGate()
    for d in range(8):
        for s in range(8):
            assert m.weights[d][s] == (0 if d == s else INITIAL)


def test_gate_closed_then_opens():
    m = EightAgentRouteGate()
    assert m.context(0x01)[1] == 0
    m.weights[1][0] = GATE_TH + 8
    assert m.context(0x01)[1] == 560
    assert m.context(0x01)[2] == 0


def test_cyclic_eval_improves_after_train():
    m = EightAgentRouteGate()
    before = m.eval_exact(32)
    for _ in range(32):
        for s in range(8):
            m.tick(1 << s, 1 << ((s + 1) % 8), learn=True)
    after = m.eval_exact(32)
    assert before == 0
    assert after >= 28
    assert all(m.weights[(s + 1) % 8][s] > GATE_TH for s in range(8))


def test_reset_erases_routes():
    m = EightAgentRouteGate()
    for _ in range(16):
        for s in range(8):
            m.tick(1 << s, 1 << ((s + 1) % 8), learn=True)
    m.reset()
    assert m.eval_exact(16) == 0

from python.m8_hw03_dense_reference import one_dense_train, neutral_matrix
from python.m8_hw03r_sessions import mixed_byte, session_pair
import random


def test_mixed_never_all_same():
    rng = random.Random(2026081432)
    for _ in range(200):
        v = mixed_byte(rng)
        assert 1 <= bin(v).count("1") <= 7


def test_random_pairs_change_64():
    for i in range(32):
        stim, teacher = session_pair(2026081432 + i)
        r = one_dense_train(neutral_matrix(), stim, teacher)
        assert r["changed_cell_count"] == 64, (stim, teacher, r["changed_cell_count"])

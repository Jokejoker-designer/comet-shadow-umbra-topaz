@echo off
call build_basys3.bat
if errorlevel 1 exit /b %ERRORLEVEL%
call program_basys3.bat
exit /b %ERRORLEVEL%

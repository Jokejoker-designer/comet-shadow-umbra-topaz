`timescale 1ns/1ps
module tb_basys3_eight_agent_top;
    logic clk = 1'b0;
    logic [15:0] sw = 16'd0;
    logic btnC = 1'b0, btnU = 1'b0, btnL = 1'b1, btnR = 1'b0, btnD = 1'b0;
    logic [15:0] led;
    logic [6:0] seg;
    logic dp;
    logic [3:0] an;
    logic RsTx;
    logic RsRx = 1'b1;
    always #5 clk = ~clk;

    basys3_eight_agent_top #(
        .DEBOUNCE_BITS(2),
        .AUTO_INTERVAL_CYCLES(8),
        .STRETCH_CYCLES(16),
        .EVAL_TICKS(16),
        .TRAIN_TICKS_REMAP(64),
        .TRAIN_TICKS_CYCLIC(256)
    ) dut (.*);

    initial begin
        repeat (10) @(posedge clk);
        btnL = 1'b0;
        sw[11] = 1'b1;
        sw[10] = 1'b1;          // cyclic M8-HW-01 control path
        sw[13] = 1'b1;
        wait (dut.core_rst_n == 1'b1);
        repeat (20) @(posedge dut.core_clk);
        btnU = 1'b1;
        repeat (8) @(posedge dut.core_clk);
        btnU = 1'b0;

        fork
            begin
                wait (dut.final_pass == 1'b1);
            end
            begin
                repeat (3_000_000) @(posedge clk);
                $fatal(1, "timeout waiting for 8-agent FINAL_PASS");
            end
        join_any
        disable fork;
        $display("TB cyclic FINAL_PASS after_hits=%0d", dut.after_hits);
        $finish;
    end
endmodule

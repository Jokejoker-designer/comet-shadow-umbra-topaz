`timescale 1ns/1ps
// Numeric tokens only. No names / phrases in this file.
module tb_m8_hw06b_multiturn;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic clear_ctx = 1'b0;
    logic reset_w = 1'b0;
    logic step = 1'b0;
    logic learn = 1'b0;
    logic [7:0] stim = 8'd0;
    logic [7:0] teacher = 8'd0;
    logic [7:0] ctx, out_sp;
    logic signed [1023:0] weights_packed;
    integer k;

    localparam logic [7:0] T1A0 = 8'd30,  T1A1 = 8'd10,  T1A2 = 8'd40;
    localparam logic [7:0] T1B0 = 8'd136, T1B1 = 8'd130, T1B2 = 8'd177;
    localparam logic [7:0] T20  = 8'd17,  T21  = 8'd90,  T22  = 8'd238;
    localparam logic [7:0] T30  = 8'd57,  T31  = 8'd125, T32  = 8'd120;
    localparam logic [7:0] BA   = 8'h66;
    localparam logic [7:0] BB   = 8'hEE;

    always #5 clk = ~clk;

    temporal_context8 dut (
        .clk(clk), .rst_n(rst_n),
        .clear_ctx(clear_ctx), .reset_weights(reset_w),
        .step(step), .learn(learn),
        .stim(stim), .teacher(teacher),
        .ctx(ctx), .out_spikes(out_sp),
        .weights_packed(weights_packed)
    );

    task automatic tick(input [7:0] s, input bit do_learn, input [7:0] tch);
        begin
            @(negedge clk);
            stim = s;
            teacher = do_learn ? tch : 8'd0;
            learn = do_learn;
            step = 1'b1;
            @(posedge clk);
            @(negedge clk);
            step = 1'b0;
            learn = 1'b0;
            teacher = 8'd0;
        end
    endtask

    task automatic clr;
        begin
            @(negedge clk);
            clear_ctx = 1'b1;
            @(posedge clk);
            @(negedge clk);
            clear_ctx = 1'b0;
        end
    endtask

    task automatic bind3(input [7:0] s0, s1, s2, input bit last_learn, input [7:0] tch);
        begin
            tick(s0, 1'b0, 8'd0);
            tick(s1, 1'b0, 8'd0);
            tick(s2, last_learn, tch);
        end
    endtask

    task automatic train_hist(input [7:0] a0, a1, a2, input [7:0] tch);
        begin
            clr();
            bind3(a0, a1, a2, 1'b0, 8'd0);
            bind3(T20, T21, T22, 1'b0, 8'd0);
            bind3(T30, T31, T32, 1'b1, tch);
        end
    endtask

    initial begin
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        @(posedge clk);
        reset_w = 1'b1;
        @(posedge clk);
        reset_w = 1'b0;

        for (k = 0; k < 8; k = k + 1) begin
            train_hist(T1A0, T1A1, T1A2, BA);
            train_hist(T1B0, T1B1, T1B2, BB);
        end

        clr();
        bind3(T1A0, T1A1, T1A2, 1'b0, 8'd0);
        bind3(T20, T21, T22, 1'b0, 8'd0);
        bind3(T30, T31, T32, 1'b0, 8'd0);
        if (out_sp !== BA)
            $fatal(1, "hist A out=%02h != BA", out_sp);
        $display("TB HIST_A -> %02h ctx=%0d", out_sp, ctx);

        clr();
        bind3(T1B0, T1B1, T1B2, 1'b0, 8'd0);
        bind3(T20, T21, T22, 1'b0, 8'd0);
        bind3(T30, T31, T32, 1'b0, 8'd0);
        if (out_sp !== BB)
            $fatal(1, "hist B out=%02h != BB", out_sp);
        $display("TB HIST_B -> %02h ctx=%0d", out_sp, ctx);

        clr();
        bind3(T30, T31, T32, 1'b0, 8'd0);
        if ((out_sp === BA) || (out_sp === BB))
            $fatal(1, "T3-only leaked a name basin %02h", out_sp);
        $display("TB T3 -> %02h", out_sp);

        clr();
        bind3(T20, T21, T22, 1'b0, 8'd0);
        bind3(T1A0, T1A1, T1A2, 1'b0, 8'd0);
        bind3(T30, T31, T32, 1'b0, 8'd0);
        if (out_sp === BA)
            $fatal(1, "permuted order incorrectly emitted BA");
        $display("TB PERM -> %02h", out_sp);

        $display("M8_HW06B_PASS histA=BA histB=BB T3/PERM != name");
        $finish;
    end

    initial begin
        repeat (200000) @(posedge clk);
        $fatal(1, "timeout");
    end
endmodule

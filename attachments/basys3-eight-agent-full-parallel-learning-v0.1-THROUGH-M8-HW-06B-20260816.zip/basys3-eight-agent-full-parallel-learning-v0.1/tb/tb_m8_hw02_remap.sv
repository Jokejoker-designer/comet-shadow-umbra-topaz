`timescale 1ns/1ps
// Behavioral A → reset → B remapping. Permutation is loaded into registers,
// not compiled into the DUT as a constant table.
module tb_m8_hw02_remap;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic enable = 1'b1;
    logic cyclic_mode = 1'b0;
    logic session_valid = 1'b0;
    logic start_cmd = 1'b0;
    logic reset_cmd = 1'b0;
    logic [63:0] perm_packed = 64'd0;
    logic core_busy, core_done, auto_start;
    logic [7:0] source, score_teacher, core_teacher, output_spikes;
    logic [2:0] tphase;
    logic [31:0] epochs;
    logic trainer_enable, learn_enable, freeze_weights, clear_pulse, reset_w;
    logic dump_start, dump_done = 1'b0;
    logic [7:0] snapshot_id;
    logic [3:0] phase;
    logic [15:0] before_hits, after_hits, forget_hits;
    logic [15:0] before_mismatch, after_mismatch;
    logic [7:0] before_acc, after_acc, route_pass;
    logic freeze_pass, final_pass, result_strobe;
    logic signed [15:0] cfg_rdata;
    logic [31:0] tick_count, update_count, mismatch_count;
    logic signed [1023:0] weights_packed;
    logic update_applied;
    integer a_before, a_after, a_forget, b_after;
    integer d, s;

    always #5 clk = ~clk;

    function automatic [63:0] pack_perm(input [7:0] p0, p1, p2, p3, p4, p5, p6, p7);
        pack_perm = {p7, p6, p5, p4, p3, p2, p1, p0};
    endfunction

    eval_supervisor8 #(
        .EVAL_TICKS(32),
        .TRAIN_TICKS_REMAP(256),
        .TRAIN_TICKS_CYCLIC(1024),
        .HOLD_TICKS(8)
    ) supervisor_i (
        .clk(clk), .rst_n(rst_n), .enable(enable),
        .cyclic_mode(cyclic_mode), .session_valid(session_valid),
        .start_cmd(start_cmd), .reset_cmd(reset_cmd),
        .core_done(core_done),
        .source_spikes(source), .score_teacher(score_teacher),
        .output_spikes(output_spikes), .sw_freeze(1'b0),
        .uart_idle(1'b1), .dump_done(dump_done),
        .trainer_enable(trainer_enable), .learn_enable(learn_enable),
        .freeze_weights(freeze_weights), .clear_pulse(clear_pulse),
        .reset_weights(reset_w), .dump_start(dump_start),
        .snapshot_id(snapshot_id), .phase(phase),
        .before_hits(before_hits), .after_hits(after_hits),
        .forget_hits(forget_hits),
        .before_mismatch(before_mismatch), .after_mismatch(after_mismatch),
        .before_acc(before_acc), .after_acc(after_acc),
        .route_pass(route_pass), .freeze_pass(freeze_pass),
        .final_pass(final_pass), .result_strobe(result_strobe)
    );

    auto_trainer8 #(.INTERVAL_CYCLES(2)) trainer_i (
        .clk(clk), .rst_n(rst_n), .enable(trainer_enable),
        .cyclic_mode(1'b0), .perm_packed(perm_packed),
        .core_busy(core_busy), .core_done(core_done),
        .start_pulse(auto_start),
        .source_spikes(source), .score_teacher(score_teacher),
        .phase(tphase), .epochs(epochs)
    );

    assign core_teacher = (learn_enable && !freeze_weights) ? score_teacher : 8'h00;

    eight_agent_snn_core core_i (
        .clk(clk), .rst_n(rst_n), .start(auto_start),
        .clear_state(clear_pulse), .reset_weights(reset_w),
        .learn_enable(learn_enable), .supervised_mode(1'b1),
        .freeze_weights(freeze_weights), .dense_mode(1'b0),
        .direct_spikes(source), .teacher_spikes(core_teacher),
        .threshold(16'sd512), .leak_shift(4'd3),
        .cfg_dst(3'd0), .cfg_src(3'd0), .cfg_rdata(cfg_rdata),
        .busy(core_busy), .done(core_done),
        .encoded_spikes(), .output_spikes(output_spikes),
        .update_applied(update_applied),
        .tick_count(tick_count), .update_count(update_count),
        .mismatch_count(mismatch_count),
        .weights_packed(weights_packed)
    );

    always @(posedge clk) begin
        dump_done <= 1'b0;
        if (dump_start) dump_done <= 1'b1;
    end

    always @(phase)
        $display("TB phase=%0d after=%0d forget=%0d t=%0t", phase, after_hits, forget_hits, $time);

    task dump_matrix(input string tag);
        begin
            $display("MATRIX %s", tag);
            for (d = 0; d < 8; d = d + 1)
                $display("  r%0d: %0d %0d %0d %0d %0d %0d %0d %0d", d,
                    $signed(weights_packed[(d*8+0)*16 +: 16]),
                    $signed(weights_packed[(d*8+1)*16 +: 16]),
                    $signed(weights_packed[(d*8+2)*16 +: 16]),
                    $signed(weights_packed[(d*8+3)*16 +: 16]),
                    $signed(weights_packed[(d*8+4)*16 +: 16]),
                    $signed(weights_packed[(d*8+5)*16 +: 16]),
                    $signed(weights_packed[(d*8+6)*16 +: 16]),
                    $signed(weights_packed[(d*8+7)*16 +: 16]));
        end
    endtask

    always @(posedge clk) if (rst_n) begin
        if (!(learn_enable && !freeze_weights) && core_teacher != 8'h00)
            $fatal(1, "teacher isolation violated at phase %0d", phase);
    end

    initial begin
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (4) @(posedge clk);

        perm_packed = pack_perm(8'd1, 8'd7, 8'd4, 8'd5, 8'd3, 8'd2, 8'd0, 8'd6);
        session_valid = 1'b1;
        start_cmd = 1'b1;
        @(posedge clk);
        start_cmd = 1'b0;

        wait (phase == 4'd2);
        a_before = before_hits;
        $display("TB A TRAIN begin before_hits=%0d t=%0t", a_before, $time);
        wait (phase == 4'd6);
        a_after = after_hits;
        $display("TB A WAIT after_hits=%0d t=%0t", a_after, $time);
        dump_matrix("A_HOLD");
        if (a_before > 8) $fatal(1, "A EVAL_BEFORE too high: %0d", a_before);
        if (a_after != 32) $fatal(1, "A EVAL_AFTER %0d != 32", a_after);

        @(posedge clk);
        reset_cmd = 1'b1;
        @(posedge clk);
        $display("TB RESET edge phase=%0d dump_start=%0d dump_done=%0d rst_w=%0d t=%0t",
            phase, dump_start, dump_done, reset_w, $time);
        reset_cmd = 1'b0;
        wait (phase == 4'd9);
        $display("TB entered FORGET t=%0t", $time);
        wait (phase == 4'd6);
        @(posedge clk);
        a_forget = forget_hits;
        $display("TB after FORGET forget_hits=%0d t=%0t", a_forget, $time);
        dump_matrix("AFTER_RESET");
        if (a_forget > 8) $fatal(1, "A not forgotten: %0d", a_forget);
        for (d = 0; d < 8; d = d + 1)
            for (s = 0; s < 8; s = s + 1)
                if ($signed(weights_packed[(d*8+s)*16 +: 16]) != ((d == s) ? 16'sd0 : 16'sd64))
                    $fatal(1, "reset matrix not neutral W[%0d][%0d]=%0d", d, s,
                        $signed(weights_packed[(d*8+s)*16 +: 16]));

        perm_packed = pack_perm(8'd5, 8'd6, 8'd0, 8'd1, 8'd7, 8'd3, 8'd2, 8'd4);
        repeat (4) @(posedge clk);
        $display("TB B START from phase=%0d session=%0d t=%0t", phase, session_valid, $time);
        start_cmd = 1'b1;
        repeat (4) @(posedge clk);
        $display("TB B START held phase=%0d t=%0t", phase, $time);
        start_cmd = 1'b0;
        wait (phase == 4'd2);
        wait (phase == 4'd6);
        b_after = after_hits;
        if (b_after != 32) $fatal(1, "B EVAL_AFTER %0d != 32", b_after);

        dump_matrix("B_HOLD");
        $display("TB M8-HW-02 PASS A_before=%0d A_after=%0d A_forget=%0d B_after=%0d",
            a_before, a_after, a_forget, b_after);
        $finish;
    end

    initial begin
        repeat (5_000_000) @(posedge clk);
        $fatal(1, "timeout phase=%0d after=%0d forget=%0d", phase, after_hits, forget_hits);
    end
endmodule

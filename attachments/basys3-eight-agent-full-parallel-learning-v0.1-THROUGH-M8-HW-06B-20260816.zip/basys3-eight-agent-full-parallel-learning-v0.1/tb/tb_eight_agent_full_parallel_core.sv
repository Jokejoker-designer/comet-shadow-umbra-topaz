`timescale 1ns/1ps

module tb_eight_agent_full_parallel_core;
    logic clk = 0;
    always #5 clk = ~clk;

    logic rst, start, train_enable, freeze;
    logic [7:0] stimulus, teacher;
    logic [7:0] output_spikes;
    logic [31:0] tick_count, update_count, mismatch_count;
    logic done;
    logic [2:0] inspect_dst, inspect_src;
    logic signed [11:0] inspect_weight;

    eight_agent_full_parallel_core dut (
        .clk(clk), .rst(rst),
        .start(start), .train_enable(train_enable), .freeze(freeze),
        .stimulus(stimulus), .teacher(teacher),
        .output_spikes(output_spikes),
        .tick_count(tick_count), .update_count(update_count),
        .mismatch_count(mismatch_count), .done(done),
        .inspect_dst(inspect_dst), .inspect_src(inspect_src),
        .inspect_weight(inspect_weight)
    );

    logic [7:0] x [0:7];
    logic [7:0] y_a [0:7];
    logic [7:0] y_b [0:7];
    integer i;
    integer correct;

    task pulse(input logic do_train, input logic [7:0] sx, input logic [7:0] ty);
        begin
            @(negedge clk);
            train_enable = do_train;
            stimulus = sx;
            teacher = ty;
            start = 1'b1;
            @(negedge clk);
            start = 1'b0;
        end
    endtask

    task eval_session(output integer hits);
        begin
            hits = 0;
            for (i = 0; i < 8; i = i + 1) begin
                pulse(1'b0, x[i], y_a[i]);
                @(posedge clk);
                if (output_spikes == y_a[i])
                    hits = hits + 1;
            end
        end
    endtask

    initial begin
        // Neutral orthogonal signal basis. No semantic role is attached to indices.
        x[0]=8'hFF; x[1]=8'h55; x[2]=8'h33; x[3]=8'h99;
        x[4]=8'h0F; x[5]=8'hA5; x[6]=8'hC3; x[7]=8'h69;

        // Session A arbitrary permutation.
        y_a[0]=8'h33; y_a[1]=8'h69; y_a[2]=8'hFF; y_a[3]=8'hA5;
        y_a[4]=8'h55; y_a[5]=8'h0F; y_a[6]=8'h99; y_a[7]=8'hC3;

        // Session B intentionally different.
        y_b[0]=8'hA5; y_b[1]=8'h33; y_b[2]=8'h69; y_b[3]=8'h55;
        y_b[4]=8'hC3; y_b[5]=8'h99; y_b[6]=8'h0F; y_b[7]=8'hFF;

        rst=1; start=0; train_enable=0; freeze=0;
        stimulus=0; teacher=0; inspect_dst=0; inspect_src=0;
        repeat(3) @(posedge clk);
        rst=0;

        // Before training, zero matrix must not magically implement session A.
        eval_session(correct);
        if (correct == 8)
            $fatal(1, "FAIL: mapping exists before training");

        // One complete orthogonal training epoch.
        for (i = 0; i < 8; i = i + 1)
            pulse(1'b1, x[i], y_a[i]);

        // Evaluate frozen/no-learning behavior.
        freeze = 1'b1;
        eval_session(correct);
        if (correct != 8)
            $fatal(1, "FAIL: session A not learned, correct=%0d", correct);

        // Freeze must block updates.
        if (update_count != 8)
            $fatal(1, "FAIL: unexpected update_count=%0d", update_count);

        // Reset destroys mapping.
        freeze = 0;
        rst = 1;
        repeat(2) @(posedge clk);
        rst = 0;
        eval_session(correct);
        if (correct == 8)
            $fatal(1, "FAIL: knowledge survived reset unexpectedly");

        $display("PASS: 8-agent full-parallel learn/freeze/reset contract");
        $finish;
    end
endmodule

`timescale 1ns/1ps
// M8-HW-03: one dense TRAIN must change 64/64 cells; freeze and teacher-off write 0.
module tb_m8_hw03_dense;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic start = 1'b0;
    logic reset_w = 1'b0;
    logic learn = 1'b0;
    logic freeze = 1'b1;
    logic [7:0] stim = 8'h00;
    logic [7:0] teacher = 8'h00;
    logic [7:0] core_teacher;
    logic busy, done, update_applied;
    logic [7:0] encoded, out_sp;
    logic [31:0] tick_count, update_count, mismatch_count;
    logic signed [1023:0] weights_packed;
    logic [6:0] changed;
    integer d, s, fail;
    logic signed [15:0] got, exp, before_w;
    logic signed [15:0] snap [0:7][0:7];

    localparam logic [7:0] STIM_A = 8'hB4;
    localparam logic [7:0] TEACH_A = 8'h6B;
    localparam logic [7:0] STIM_B = 8'h4B;
    localparam int LR = 8;

    always #5 clk = ~clk;

    assign core_teacher = (learn && !freeze) ? teacher : 8'h00;

    eight_agent_snn_core core_i (
        .clk(clk), .rst_n(rst_n), .start(start),
        .clear_state(1'b0), .reset_weights(reset_w),
        .learn_enable(learn), .supervised_mode(1'b1),
        .freeze_weights(freeze), .dense_mode(1'b1),
        .direct_spikes(stim), .teacher_spikes(core_teacher),
        .threshold(16'sd512), .leak_shift(4'd3),
        .cfg_dst(3'd0), .cfg_src(3'd0), .cfg_rdata(),
        .busy(busy), .done(done),
        .encoded_spikes(encoded), .output_spikes(out_sp),
        .update_applied(update_applied),
        .tick_count(tick_count), .update_count(update_count),
        .mismatch_count(mismatch_count),
        .weights_packed(weights_packed),
        .changed_cell_count(changed)
    );

    function automatic signed [15:0] pm1(input bit b);
        pm1 = b ? 16'sd1 : -16'sd1;
    endfunction

    function automatic signed [15:0] wcell(input integer dd, input integer ss);
        wcell = $signed(weights_packed[(dd*8+ss)*16 +: 16]);
    endfunction

    task automatic capture;
        integer dd, ss;
        begin
            for (dd = 0; dd < 8; dd = dd + 1)
                for (ss = 0; ss < 8; ss = ss + 1)
                    snap[dd][ss] = wcell(dd, ss);
        end
    endtask

    task automatic pulse_start;
        begin
            @(posedge clk);
            start = 1'b1;
            @(posedge clk);
            start = 1'b0;
            wait (done);
            @(posedge clk);
        end
    endtask

    task automatic check_neutral;
        integer dd, ss;
        begin
            for (dd = 0; dd < 8; dd = dd + 1)
                for (ss = 0; ss < 8; ss = ss + 1)
                    if (wcell(dd, ss) != ((dd == ss) ? 16'sd0 : 16'sd64))
                        $fatal(1, "not neutral W[%0d][%0d]=%0d", dd, ss, wcell(dd, ss));
        end
    endtask

    task automatic check_dense(input [7:0] x, input [7:0] t, input string tag);
        integer dd, ss;
        begin
            if (changed != 7'd64)
                $fatal(1, "%s changed_cell_count=%0d != 64", tag, changed);
            fail = 0;
            for (dd = 0; dd < 8; dd = dd + 1) begin
                for (ss = 0; ss < 8; ss = ss + 1) begin
                    before_w = (dd == ss) ? 16'sd0 : 16'sd64;
                    exp = before_w + LR * pm1(t[dd]) * pm1(x[ss]);
                    got = wcell(dd, ss);
                    if (got != exp) begin
                        $display("MISMATCH %s W[%0d][%0d] got=%0d exp=%0d", tag, dd, ss, got, exp);
                        fail = fail + 1;
                    end
                    if (got == before_w)
                        $fatal(1, "%s cell [%0d][%0d] did not change", tag, dd, ss);
                end
            end
            if (fail != 0)
                $fatal(1, "%s %0d cells != Python law", tag, fail);
            $display("TB %s changed=64 matrix bit-exact", tag);
        end
    endtask

    always @(posedge clk) if (rst_n && $past(rst_n)) begin
        if (start && !(learn && !freeze) && (core_teacher != 8'h00))
            $fatal(1, "teacher isolation violated at start");
        if (freeze && $past(freeze) && !reset_w && !$past(reset_w) && !start && !$past(start))
            if (weights_packed !== $past(weights_packed))
                $fatal(1, "weights moved while freeze held");
    end

    initial begin
        fail = 0;
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (4) @(posedge clk);
        reset_w = 1'b1;
        @(posedge clk);
        reset_w = 1'b0;
        repeat (2) @(posedge clk);
        check_neutral();
        $display("TB BEFORE_DENSE changed=%0d (expect 0 after reset)", changed);

        stim = STIM_A;
        teacher = TEACH_A;
        learn = 1'b1;
        freeze = 1'b0;
        pulse_start();
        check_dense(STIM_A, TEACH_A, "DENSE_A");
        capture();

        learn = 1'b0;
        freeze = 1'b1;
        repeat (32) pulse_start();
        for (d = 0; d < 8; d = d + 1)
            for (s = 0; s < 8; s = s + 1)
                if (wcell(d, s) != snap[d][s])
                    $fatal(1, "FREEZE W[%0d][%0d] moved", d, s);
        $display("TB FREEZE 0/64 bit-exact vs AFTER_ONE");

        reset_w = 1'b1;
        @(posedge clk);
        reset_w = 1'b0;
        repeat (2) @(posedge clk);
        learn = 1'b1;
        freeze = 1'b1;
        teacher = TEACH_A;
        stim = STIM_A;
        pulse_start();
        check_neutral();
        if (update_applied)
            $fatal(1, "freeze control applied an update");
        $display("TB FREEZE_CONTROL no write");

        learn = 1'b0;
        freeze = 1'b0;
        pulse_start();
        check_neutral();
        $display("TB TEACHER_OFF / learn=0 no write");

        reset_w = 1'b1;
        @(posedge clk);
        reset_w = 1'b0;
        repeat (2) @(posedge clk);
        stim = STIM_B;
        teacher = TEACH_A;
        learn = 1'b1;
        freeze = 1'b0;
        pulse_start();
        check_dense(STIM_B, TEACH_A, "DENSE_B");

        $display("M8_HW03_PASS changed_A=64 freeze=0 teacher_off=0 changed_B=64");
        $finish;
    end

    initial begin
        repeat (20000) @(posedge clk);
        $fatal(1, "timeout");
    end
endmodule

`timescale 1ns/1ps
module tb_m8_hw04_temporal;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    logic clear_ctx = 1'b0;
    logic reset_w = 1'b0;
    logic step = 1'b0;
    logic learn = 1'b0;
    logic [7:0] stim = 8'd0;
    logic [7:0] teacher = 8'd0;
    logic [7:0] ctx, out_sp;
    logic signed [1023:0] weights_packed;
    integer k;

    localparam logic [7:0] A = 8'hB4;
    localparam logic [7:0] B = 8'h6B;
    localparam logic [7:0] C = 8'h4B;
    localparam logic [7:0] X = 8'hA5;

    always #5 clk = ~clk;

    temporal_context8 dut (
        .clk(clk), .rst_n(rst_n),
        .clear_ctx(clear_ctx), .reset_weights(reset_w),
        .step(step), .learn(learn),
        .stim(stim), .teacher(teacher),
        .ctx(ctx), .out_spikes(out_sp),
        .weights_packed(weights_packed)
    );

    task automatic tick(input [7:0] s, input bit do_learn, input [7:0] tch);
        begin
            @(negedge clk);
            stim = s;
            teacher = do_learn ? tch : 8'd0;
            learn = do_learn;
            step = 1'b1;
            @(posedge clk);
            @(negedge clk);
            step = 1'b0;
            learn = 1'b0;
            teacher = 8'd0;
        end
    endtask

    task automatic run_seq(input [7:0] s0, s1, s2, input bit last_learn, input integer nsym);
        begin
            @(negedge clk);
            clear_ctx = 1'b1;
            @(posedge clk);
            @(negedge clk);
            clear_ctx = 1'b0;
            tick(s0, 1'b0, 8'd0);
            tick(s1, 1'b0, 8'd0);
            if (nsym == 3)
                tick(s2, last_learn, X);
        end
    endtask

    initial begin
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        @(posedge clk);
        reset_w = 1'b1;
        @(posedge clk);
        reset_w = 1'b0;

        for (k = 0; k < 8; k = k + 1)
            run_seq(A, B, C, 1'b1, 3);

        run_seq(A, B, C, 1'b0, 3);
        if (out_sp !== X)
            $fatal(1, "ABC out=%02h != X", out_sp);
        $display("TB ABC -> %02h ctx=%0d", out_sp, ctx);

        run_seq(A, C, B, 1'b0, 3);
        if (out_sp === X)
            $fatal(1, "ACB incorrectly emitted X");
        $display("TB ACB -> %02h", out_sp);

        run_seq(B, A, C, 1'b0, 3);
        if (out_sp === X)
            $fatal(1, "BAC incorrectly emitted X");
        $display("TB BAC -> %02h", out_sp);

        run_seq(A, B, 8'd0, 1'b0, 2);
        if (out_sp === X)
            $fatal(1, "AB incorrectly emitted X");
        $display("TB AB  -> %02h", out_sp);

        @(negedge clk);
        reset_w = 1'b1;
        @(posedge clk);
        @(negedge clk);
        reset_w = 1'b0;
        run_seq(A, B, C, 1'b0, 3);
        if (out_sp === X)
            $fatal(1, "forget failed, still X");
        $display("TB FORGET ABC -> %02h", out_sp);

        $display("M8_HW04_PASS ABC=X ACB/BAC/AB/forget != X");
        $finish;
    end

    initial begin
        repeat (20000) @(posedge clk);
        $fatal(1, "timeout");
    end
endmodule

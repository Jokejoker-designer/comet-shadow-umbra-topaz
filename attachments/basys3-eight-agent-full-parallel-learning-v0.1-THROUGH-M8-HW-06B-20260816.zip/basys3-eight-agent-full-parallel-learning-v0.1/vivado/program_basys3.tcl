if {$argc < 1} {
    puts stderr "Usage: vivado -mode batch -source vivado/program_basys3.tcl -tclargs build/out/basys3_eight_agent.bit"
    exit 2
}
set bitfile [file normalize [lindex $argv 0]]
if {![file exists $bitfile]} {
    puts stderr "Bitstream not found: $bitfile"
    exit 3
}
open_hw_manager
connect_hw_server
open_hw_target
set devices [get_hw_devices -quiet *xc7a35t*]
if {[llength $devices] == 0} {
    puts stderr "No Basys 3 XC7A35T device detected."
    exit 4
}
set dev [lindex $devices 0]
current_hw_device $dev
refresh_hw_device $dev
set_property PROGRAM.FILE $bitfile $dev
program_hw_devices $dev
puts "BASYS3_PROGRAM_PASS device=$dev bitstream=$bitfile"
close_hw_manager

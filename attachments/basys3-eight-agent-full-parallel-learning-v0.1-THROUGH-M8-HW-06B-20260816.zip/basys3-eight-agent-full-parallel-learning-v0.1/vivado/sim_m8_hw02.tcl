set script_dir [file normalize [file dirname [info script]]]
set root_dir [file normalize [file join $script_dir ..]]
set sim_dir [file join $root_dir build sim_m8_hw02]
file mkdir $sim_dir
create_project -force m8_hw02_sim $sim_dir -part xc7a35tcpg236-1
set files [list \
 [file join $root_dir rtl core snn_math_pkg.sv] \
 [file join $root_dir rtl core pulse_density_encoder.sv] \
 [file join $root_dir rtl core lif_agent.sv] \
 [file join $root_dir rtl core attention_gate8.sv] \
 [file join $root_dir rtl core stdp_matrix8.sv] \
 [file join $root_dir rtl core eight_agent_snn_core.sv] \
 [file join $root_dir rtl board session_map8.sv] \
 [file join $root_dir rtl board auto_trainer8.sv] \
 [file join $root_dir rtl board eval_supervisor8.sv]]
add_files -norecurse $files
add_files -fileset sim_1 -norecurse [file join $root_dir tb tb_m8_hw02_remap.sv]
set_property top tb_m8_hw02_remap [get_filesets sim_1]
update_compile_order -fileset sim_1
launch_simulation
run all
close_sim

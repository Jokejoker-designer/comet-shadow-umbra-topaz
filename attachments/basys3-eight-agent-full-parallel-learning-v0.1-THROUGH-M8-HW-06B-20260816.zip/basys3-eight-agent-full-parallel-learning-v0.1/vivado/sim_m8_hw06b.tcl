set script_dir [file normalize [file dirname [info script]]]
set root_dir [file normalize [file join $script_dir ..]]
set sim_dir [file join $root_dir build sim_m8_hw06b]
file mkdir $sim_dir
create_project -force m8_hw06b_sim $sim_dir -part xc7a35tcpg236-1
set files [list \
 [file join $root_dir rtl core snn_math_pkg.sv] \
 [file join $root_dir rtl core temporal_context8.sv]]
add_files -norecurse $files
add_files -fileset sim_1 -norecurse [file join $root_dir tb tb_m8_hw06b_multiturn.sv]
set_property top tb_m8_hw06b_multiturn [get_filesets sim_1]
update_compile_order -fileset sim_1
launch_simulation
run all
close_sim

"""M8-HW-06B board scorer: multi-turn ctx on FPGA, then AFTER.

Requires m8hw06b.bit (hold_ctx + clear-ctx). Not an LLM.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw03_dense_reference import matrix_sha256
from python.m8_hw04_temporal_reference import TRAIN_REPS
from python.m8_hw05_phrase_reference import encode_tokens
from python.m8_hw06a_reference import (
    AfterTrainLatch,
    LocalBasinDecoder,
    format_provenance,
    provenance,
)
from python.m8_hw06b_reference import (
    NAME_A,
    NAME_B,
    TURN1_A,
    TURN1_B,
    TURN2,
    TURN3,
    run_first_gate,
)
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    matrix_from_pages,
    parse_frame,
    phrase_probe_frame,
    phrase_sample_frame,
    xor14,
)

CMD_DUMP = 0x03
CMD_T_RESET = 0x06
CMD_T_TRAIN = 0x07
CMD_T_CLEAR = 0x08


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61, 0x62, 0x63, 0x64):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    return parse_frame(frame)
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def wait_temp(port, seconds: float = 3.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.3)
        if rec and rec.get("ok") and rec.get("kind") == 0x64:
            return rec
    return None


def collect_dump(port, seconds: float = 8.0) -> dict[int, list[int]]:
    pages: dict[int, list[int]] = {}
    deadline = time.time() + seconds
    while time.time() < deadline and len(pages) < 16:
        rec = read_frame(port, 0.4)
        if rec and rec.get("ok") and rec.get("kind") == 0x5D:
            pages[int(rec["page"])] = list(rec["weights"])
    return pages


def dump_sha(port) -> str | None:
    send(port, command_frame(CMD_DUMP))
    pages = collect_dump(port)
    if len(pages) < 16:
        return None
    return matrix_sha256(matrix_from_pages(pages))


def bind_turn(port, tokens, *, hold: bool, learn_teacher: int | None) -> dict | None:
    if learn_teacher is None:
        send(port, phrase_probe_frame(tokens, hold=1 if hold else 0))
    else:
        send(port, phrase_sample_frame(tokens, learn_teacher, hold=1 if hold else 0))
        time.sleep(0.03)
        send(port, command_frame(CMD_T_TRAIN))
    return wait_temp(port)


def play_history(port, turns: list[tuple], *, train_last: int | None) -> dict | None:
    """turns = list of token triples. train_last is teacher for the last turn or None."""
    last = None
    n = len(turns)
    for i, tokens in enumerate(turns):
        hold = i > 0
        teacher = train_last if (train_last is not None and i == n - 1) else None
        if i == 0 and teacher is None:
            hold = False
        elif i == 0 and teacher is not None:
            hold = False
        else:
            hold = True
        last = bind_turn(port, tokens, hold=hold, learn_teacher=teacher)
    return last


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--reps", type=int, default=TRAIN_REPS)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-06B/run_001"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "replay").mkdir(exist_ok=True)
    (args.out / "board").mkdir(exist_ok=True)

    gold = run_first_gate(reps=args.reps)
    dec = LocalBasinDecoder()
    ba = dec.register_target(NAME_A)
    bb = dec.register_target(NAME_B)
    t1a = encode_tokens(TURN1_A)
    t1b = encode_tokens(TURN1_B)
    t2 = encode_tokens(TURN2)
    t3 = encode_tokens(TURN3)
    latch = AfterTrainLatch()
    transcript: list[str] = []

    print("Open", args.port, "— SW11 ON, SW10 OFF, SW13 OFF. Need m8hw06b.bit")
    print("06B multi-turn. AFTER = teacher-free. Not an LLM.")
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.15)
        port.reset_input_buffer()
        send(port, phrase_sample_frame(t3, ba, hold=0))
        time.sleep(0.05)
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)

        print("=== TRAIN (teacher legal) ===")
        for i in range(args.reps):
            latch.note_sample()
            send(port, command_frame(CMD_T_CLEAR))
            time.sleep(0.02)
            play_history(port, [t1a, t2, t3], train_last=ba)
            send(port, command_frame(CMD_T_CLEAR))
            time.sleep(0.02)
            ev = play_history(port, [t1b, t2, t3], train_last=bb)
            latch.note_train()
            print(f"  epoch {i + 1} last_out={None if ev is None else ev.get('out')}", flush=True)

        print("=== AFTER latch ===")
        latch.enter_after()
        sha_before = dump_sha(port)
        print("SHA before", sha_before)

        probes = {}
        cases = [
            ("QUAN", [t1a, t2, t3], TURN1_A + " / " + TURN2 + " / " + TURN3),
            ("LAN", [t1b, t2, t3], TURN1_B + " / " + TURN2 + " / " + TURN3),
            ("T3", [t3], TURN3),
            ("PERM", [t2, t1a, t3], TURN2 + " / " + TURN1_A + " / " + TURN3),
        ]
        for name, turns, label in cases:
            send(port, command_frame(CMD_T_CLEAR))
            time.sleep(0.02)
            latch.note_probe()
            rec = play_history(port, turns, train_last=None)
            out = None if rec is None else rec.get("out")
            decoded = dec.decode(out or 0)
            probes[name] = {"out": out, "decoded": decoded, "label": label}
            block = provenance(weight_writes=0, llm_calls=0)
            line = (
                f"user-turns> {label}\n"
                f"FPGA OUT           {None if out is None else hex(out)}\n"
                f"DECODED            {decoded if decoded else '(no known basin)'}\n\n"
                f"{format_provenance(block)}\n"
            )
            print(line)
            transcript.append(line)

        sha_after = dump_sha(port)
        print("SHA after", sha_after)

    gates = {
        "quan_is_quan": probes["QUAN"]["decoded"] == NAME_A,
        "lan_is_lan": probes["LAN"]["decoded"] == NAME_B,
        "t3_not_name": probes["T3"]["decoded"] not in {NAME_A, NAME_B},
        "perm_not_quan": probes["PERM"]["decoded"] != NAME_A,
        "sha_present": sha_before is not None and sha_after is not None,
        "weights_frozen": sha_before is not None and sha_before == sha_after,
        "llm_zero": dec.llm_calls == 0,
        "gold_pass": gold["pass"],
        "after_latched": latch.after,
    }
    passed = all(gates.values())
    verdict = {
        "pass": passed,
        "gates": gates,
        "probes": probes,
        "sha_before": sha_before,
        "sha_after": sha_after,
        "basins": {"A": ba, "B": bb},
        "bitstream": "basys3_eight_agent_m8hw06b.bit",
        "claim": (
            "SIMPLE_LEARNED_MULTI_TURN_CONVERSATION_BOARD_VALIDATED"
            if passed
            else "M8_HW_06B_BOARD_NOT_PASS"
        ),
    }
    (args.out / "replay" / "score.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (args.out / "ui_transcript.txt").write_text(
        "M8-HW-06B AFTER multi-turn (teacher disconnected)\n\n" + "\n".join(transcript),
        encoding="utf-8",
    )
    print(json.dumps(verdict, indent=2, ensure_ascii=False))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

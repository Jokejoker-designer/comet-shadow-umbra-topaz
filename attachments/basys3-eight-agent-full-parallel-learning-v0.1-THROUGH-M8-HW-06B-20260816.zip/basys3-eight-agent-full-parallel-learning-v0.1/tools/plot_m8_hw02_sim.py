"""Heatmaps from the measured XSim 8x8 dumps (not predictions)."""
from __future__ import annotations
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parents[1] / "results" / "M8-HW-02" / "simulation"

A = np.array([
    [0, 64, 64, 64, 64, 64, 320, 64],
    [320, 0, 64, 64, 64, 64, 64, 64],
    [64, 64, 0, 64, 64, 320, 64, 64],
    [64, 64, 64, 0, 320, 64, 64, 64],
    [64, 64, 320, 64, 0, 64, 64, 64],
    [64, 64, 64, 320, 64, 0, 64, 64],
    [64, 64, 64, 64, 64, 64, 0, 320],
    [64, 320, 64, 64, 64, 64, 64, 0],
], dtype=int)
R = np.full((8, 8), 64, dtype=int)
np.fill_diagonal(R, 0)
B = np.array([
    [0, 64, 320, 64, 64, 64, 64, 64],
    [64, 0, 64, 320, 64, 64, 64, 64],
    [64, 64, 0, 64, 64, 64, 320, 64],
    [64, 64, 64, 0, 64, 320, 64, 64],
    [64, 64, 64, 64, 0, 64, 64, 320],
    [320, 64, 64, 64, 64, 0, 64, 64],
    [64, 320, 64, 64, 64, 64, 0, 64],
    [64, 64, 64, 64, 320, 64, 64, 0],
], dtype=int)


def save(mat: np.ndarray, title: str, name: str) -> None:
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    im = ax.imshow(mat, cmap="magma", vmin=0, vmax=320)
    ax.set_title(title)
    ax.set_xlabel("source s")
    ax.set_ylabel("dest d")
    ax.set_xticks(range(8))
    ax.set_yticks(range(8))
    for d in range(8):
        for s in range(8):
            ax.text(s, d, str(mat[d, s]), ha="center", va="center",
                    color="white" if mat[d, s] >= 200 else "whitesmoke", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="W[d][s]")
    fig.tight_layout()
    path = OUT / name
    fig.savefig(path, dpi=140)
    plt.close(fig)
    print(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    save(A, "XSim measured A_HOLD  (P_A = 1,7,4,5,3,2,0,6)", "weights_A_hold.png")
    save(R, "XSim measured RESET   (neutral 0 / 64)", "weights_reset.png")
    save(B, "XSim measured B_HOLD  (P_B = 5,6,0,1,7,3,2,4)", "weights_B_hold.png")
    delta = B.astype(int) - A.astype(int)
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    im = ax.imshow(delta, cmap="coolwarm", vmin=-320, vmax=320)
    ax.set_title("XSim measured B_HOLD − A_HOLD (learned cells moved)")
    ax.set_xlabel("source s")
    ax.set_ylabel("dest d")
    ax.set_xticks(range(8))
    ax.set_yticks(range(8))
    for d in range(8):
        for s in range(8):
            ax.text(s, d, str(delta[d, s]), ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="ΔW")
    fig.tight_layout()
    path = OUT / "weights_A_vs_B_delta.png"
    fig.savefig(path, dpi=140)
    plt.close(fig)
    print(path)


if __name__ == "__main__":
    main()

"""Live M8-HW-02 board scorer: Session A → RESET → Session B on one bitstream."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.session_permutation import permutation, session_manifest
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    matrix_from_pages,
    parse_frame,
    session_frame,
    xor14,
)

CMD_START = 0x01
CMD_RESET = 0x02
INITIAL = 64
TARGET_W = 320
PHASE_EVAL_B = 1
PHASE_TRAIN = 2
PHASE_EVAL_A = 3
PHASE_HOLD = 4
PHASE_FORGET = 9


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    rec = parse_frame(frame)
                    rec["raw_hex"] = frame.hex()
                    return rec
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def exact_hits(samples: list[dict], perm: tuple[int, ...]) -> tuple[int, int]:
    hits = 0
    n = 0
    for rec in samples:
        inp = rec.get("inp", 0)
        if inp == 0 or (inp & (inp - 1)) != 0:
            continue
        src = inp.bit_length() - 1
        expect = 1 << perm[src]
        n += 1
        if rec.get("out") == expect:
            hits += 1
    return hits, n


def collect_until_dump(port, log, seconds: float, want_pages: int = 16):
    pages: dict[int, list[int]] = {}
    live: list[dict] = []
    echo = None
    deadline = time.time() + seconds
    while time.time() < deadline and len(pages) < want_pages:
        rec = read_frame(port, 0.4)
        if not rec or not rec.get("ok"):
            continue
        log.append(rec)
        kind = rec["kind"]
        if kind == 0x5A:
            live.append(rec)
        elif kind == 0x5E:
            echo = rec
        elif kind == 0x5D:
            pages[int(rec["page"])] = list(rec["weights"])
            print(f"  dump page {rec['page']} snap={rec['snapshot']} ({len(pages)}/16)", flush=True)
    return pages, live, echo


def collect_live_phase(port, log, seconds: float, phase: int, want: int = 32):
    """Keep reading after a dump; supervisor may still be in FORGET/WAIT."""
    live: list[dict] = []
    deadline = time.time() + seconds
    while time.time() < deadline and len(live) < want:
        rec = read_frame(port, 0.4)
        if not rec or not rec.get("ok"):
            continue
        log.append(rec)
        if rec["kind"] == 0x5A and rec.get("phase") == phase:
            live.append(rec)
    return live


def wait_session_echo(port, log, timeout_s: float = 2.0):
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        rec = read_frame(port, 0.4)
        if not rec or not rec.get("ok"):
            continue
        log.append(rec)
        if rec["kind"] == 0x5E:
            return rec
    return None


def phase_slice(live: list[dict], phase: int) -> list[dict]:
    return [r for r in live if r.get("phase") == phase]


def target_weights(mat: list[list[int]], perm: tuple[int, ...]) -> list[int]:
    return [mat[perm[s]][s] for s in range(8)]


def is_neutral(mat: list[list[int]]) -> bool:
    for d in range(8):
        for s in range(8):
            expect = 0 if d == s else INITIAL
            if mat[d][s] != expect:
                return False
    return True


def write_csv(path: Path, mat: list[list[int]]) -> None:
    path.write_text("\n".join(",".join(str(v) for v in row) for row in mat) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--seed-a", type=int, default=2026081401)
    ap.add_argument("--seed-b", type=int, default=2026081403)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-02/run_001"))
    args = ap.parse_args()
    out = args.out
    for sub in ("sessions", "board", "matrices", "replay"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    pa = permutation(args.seed_a)
    pb = permutation(args.seed_b)
    (out / "sessions" / "session_A.json").write_text(
        json.dumps(session_manifest(args.seed_a), indent=2) + "\n", encoding="utf-8"
    )
    (out / "sessions" / "session_B.json").write_text(
        json.dumps(session_manifest(args.seed_b), indent=2) + "\n", encoding="utf-8"
    )

    log: list[dict] = []
    print("Open", args.port, "115200 — SW11 ON, SW10 OFF, LED15 ON")
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.2)
        port.reset_input_buffer()

        print("Load Session A", pa)
        send(port, session_frame(args.seed_a, pa))
        rec = wait_session_echo(port, log, 2.0)
        print("  echo", None if rec is None else rec.get("perm"))
        send(port, command_frame(CMD_START))
        print("A EVAL/TRAIN/HOLD/DUMP (~30s)")
        pages_a, live_a, _ = collect_until_dump(port, log, 90)
        print(f"A pages={len(pages_a)} live={len(live_a)}")

        print("RESET + forget")
        send(port, command_frame(CMD_RESET))
        pages_r, live_r, _ = collect_until_dump(port, log, 20)
        # RESET dump finishes before ST_FORGET; START is only accepted in IDLE/WAIT.
        forget = collect_live_phase(port, log, 8.0, PHASE_FORGET, 32)
        live_r.extend(forget)
        print(f"RESET pages={len(pages_r)} live={len(live_r)} forget={len(forget)}")
        time.sleep(0.5)

        print("Load Session B", pb)
        send(port, session_frame(args.seed_b, pb))
        rec = wait_session_echo(port, log, 2.0)
        print("  echo", None if rec is None else rec.get("perm"))
        send(port, command_frame(CMD_START))
        print("B EVAL/TRAIN/HOLD/DUMP (~30s)")
        pages_b, live_b, _ = collect_until_dump(port, log, 90)
        print(f"B pages={len(pages_b)} live={len(live_b)}")

    (out / "board" / "uart.jsonl").write_text(
        "\n".join(json.dumps({k: v for k, v in r.items() if k != "raw"}) for r in log) + "\n",
        encoding="utf-8",
    )

    mats = {}
    if len(pages_a) == 16:
        mats["A_hold"] = matrix_from_pages(pages_a)
    if len(pages_r) == 16:
        mats["reset"] = matrix_from_pages(pages_r)
    if len(pages_b) == 16:
        mats["B_hold"] = matrix_from_pages(pages_b)
    for name, mat in mats.items():
        write_csv(out / "matrices" / f"{name}.csv", mat)

    a_pre_h, a_pre_n = exact_hits(phase_slice(live_a, PHASE_EVAL_B), pa)
    a_aft_h, a_aft_n = exact_hits(phase_slice(live_a, PHASE_EVAL_A), pa)
    a_hold_h, a_hold_n = exact_hits(phase_slice(live_a, PHASE_HOLD), pa)
    a_fgt_h, a_fgt_n = exact_hits(phase_slice(live_r, PHASE_FORGET), pa)
    b_pre_h, b_pre_n = exact_hits(phase_slice(live_b, PHASE_EVAL_B), pb)
    b_aft_h, b_aft_n = exact_hits(phase_slice(live_b, PHASE_EVAL_A), pb)
    b_hold_h, b_hold_n = exact_hits(phase_slice(live_b, PHASE_HOLD), pb)

    a_targets = target_weights(mats["A_hold"], pa) if "A_hold" in mats else []
    b_targets = target_weights(mats["B_hold"], pb) if "B_hold" in mats else []
    reset_ok = is_neutral(mats["reset"]) if "reset" in mats else False

    gates = {
        "pages_a_16": len(pages_a) == 16,
        "pages_reset_16": len(pages_r) == 16,
        "pages_b_16": len(pages_b) == 16,
        "a_before_le_25pct": a_pre_n >= 32 and a_pre_h <= 8,
        "a_after_32": a_aft_n >= 32 and a_aft_h == 32,
        "a_hold_32": a_hold_n >= 32 and a_hold_h == 32,
        "a_targets_320": a_targets == [TARGET_W] * 8,
        "reset_neutral": reset_ok,
        "a_forget_le_25pct": a_fgt_n >= 32 and a_fgt_h <= 8,
        "b_before_le_25pct": b_pre_n >= 32 and b_pre_h <= 8,
        "b_after_32": b_aft_n >= 32 and b_aft_h == 32,
        "b_hold_32": b_hold_n >= 32 and b_hold_h == 32,
        "b_targets_320": b_targets == [TARGET_W] * 8,
    }
    # If HOLD samples missing but EVAL_AFTER 32/32 and targets 320, still record partial.
    passed = all(gates.values())
    verdict = {
        "pass": passed,
        "incomplete": not all(
            [gates["pages_a_16"], gates["pages_reset_16"], gates["pages_b_16"]]
        ),
        "gates": gates,
        "counts": {
            "a_pre": f"{a_pre_h}/{a_pre_n}",
            "a_after": f"{a_aft_h}/{a_aft_n}",
            "a_hold": f"{a_hold_h}/{a_hold_n}",
            "a_forget": f"{a_fgt_h}/{a_fgt_n}",
            "b_pre": f"{b_pre_h}/{b_pre_n}",
            "b_after": f"{b_aft_h}/{b_aft_n}",
            "b_hold": f"{b_hold_h}/{b_hold_n}",
        },
        "a_targets": a_targets,
        "b_targets": b_targets,
        "claim": (
            "8_AGENT_ARBITRARY_ASSOCIATIVE_REMAPPING_BOARD_VALIDATED"
            if passed
            else "M8_HW_02_BOARD_NOT_PASS"
        ),
    }
    (out / "replay" / "score.json").write_text(json.dumps(verdict, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(verdict, indent=2))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

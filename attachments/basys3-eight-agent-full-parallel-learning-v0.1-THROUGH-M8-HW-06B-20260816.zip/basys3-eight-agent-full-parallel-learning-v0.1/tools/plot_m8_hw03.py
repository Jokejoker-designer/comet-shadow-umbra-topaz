"""Heatmaps from M8-HW-03 Python golden (or board CSVs if present)."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from python.m8_hw03_dense_reference import run_controls


def save(mat, title, path, cmap="magma", vmin=None, vmax=None):
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    im = ax.imshow(mat, cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_title(title)
    ax.set_xlabel("source s")
    ax.set_ylabel("dest d")
    ax.set_xticks(range(8))
    ax.set_yticks(range(8))
    for d in range(8):
        for s in range(8):
            ax.text(s, d, str(int(mat[d, s])), ha="center", va="center", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    print(path)


def main() -> None:
    out = Path(__file__).resolve().parents[1] / "results" / "M8-HW-03" / "golden"
    out.mkdir(parents=True, exist_ok=True)
    g = run_controls()
    a = np.array(g["dense_a"]["expected_after"])
    b = np.array(g["dense_b"]["expected_after"])
    r = np.array(g["dense_a"]["expected_before"])
    da = np.array(g["dense_a"]["expected_delta"])
    save(r, "Golden BEFORE (neutral)", out / "weights_before.png", vmin=0, vmax=72)
    save(a, "Golden AFTER Dense-A (64/64)", out / "weights_after_a.png", vmin=0, vmax=80)
    save(b, "Golden AFTER Dense-B (64/64)", out / "weights_after_b.png", vmin=0, vmax=80)
    save(da, "Golden Δ Dense-A (all ±8)", out / "delta_a.png", "coolwarm", -8, 8)


if __name__ == "__main__":
    main()

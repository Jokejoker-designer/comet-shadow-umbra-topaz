"""One-episode UART smoke for M8-HW-06B. Prints every A5 64."""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import serial

from python.m8_hw06b_reference import NAME_A, TURN1_A, TURN2, TURN3, encode_basin, encode_tokens
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    parse_frame,
    phrase_probe_frame,
    phrase_sample_frame,
    xor14,
)


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61, 0x62, 0x63, 0x64):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    return parse_frame(frame)
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def wait64(port, tag: str):
    rec = read_frame(port, 2.0)
    print(tag, rec)
    return rec


def main() -> None:
    t1, t2, t3 = encode_tokens(TURN1_A), encode_tokens(TURN2), encode_tokens(TURN3)
    ba = encode_basin(NAME_A)
    print("tokens", list(t1), list(t2), list(t3), "teacher", ba)
    fr = phrase_sample_frame(t3, ba, hold=1)
    print("sample62", fr.hex())
    with serial.Serial("COM8", 115200, timeout=0.2) as port:
        time.sleep(0.2)
        port.reset_input_buffer()
        port.write(phrase_sample_frame(t3, ba, 0))
        port.flush()
        time.sleep(0.05)
        port.write(command_frame(0x06))
        port.flush()
        time.sleep(0.05)
        port.reset_input_buffer()

        print("--- 04-style single phrase ---")
        port.write(phrase_sample_frame(t3, ba, 0))
        port.flush()
        time.sleep(0.08)
        port.write(command_frame(0x07))
        port.flush()
        wait64(port, "train_t3")
        port.write(phrase_probe_frame(t3, 0))
        port.flush()
        wait64(port, "probe_t3")

        print("--- reset W ---")
        port.write(command_frame(0x06))
        port.flush()
        time.sleep(0.05)
        port.reset_input_buffer()

        print("--- multi-turn one episode ---")
        port.write(command_frame(0x08))
        port.flush()
        time.sleep(0.03)
        port.write(phrase_probe_frame(t1, 0))
        port.flush()
        wait64(port, "bind_t1")
        port.write(phrase_probe_frame(t2, 1))
        port.flush()
        wait64(port, "bind_t2")
        port.write(phrase_sample_frame(t3, ba, 1))
        port.flush()
        time.sleep(0.08)
        port.write(command_frame(0x07))
        port.flush()
        wait64(port, "train_hist")
        port.write(command_frame(0x08))
        port.flush()
        time.sleep(0.03)
        port.write(phrase_probe_frame(t1, 0))
        port.flush()
        wait64(port, "p1")
        port.write(phrase_probe_frame(t2, 1))
        port.flush()
        wait64(port, "p2")
        port.write(phrase_probe_frame(t3, 1))
        port.flush()
        wait64(port, "p3")


if __name__ == "__main__":
    main()

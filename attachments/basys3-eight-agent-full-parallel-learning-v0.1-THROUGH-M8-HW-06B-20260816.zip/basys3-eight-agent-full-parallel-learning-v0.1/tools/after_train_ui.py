"""M8-HW-06A host UI: TRAIN then AFTER single-turn. No LLM. No conversation claim.

    set PYTHONPATH=.
    python tools/after_train_ui.py COM8
    python tools/after_train_ui.py --offline
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from python.m8_hw05_phrase_reference import (
    BASIN_R1,
    PHRASE_P1,
    PHRASE_P2,
    encode_tokens,
)
from python.m8_hw06a_reference import (
    AfterTrainLatch,
    LocalBasinDecoder,
    format_provenance,
    provenance,
    run_after_gate,
)


def print_turn(user_text: str, encoded, fpga_out: int, decoded: str, block: dict) -> None:
    print()
    print(f"user> {user_text}")
    print(f"ENCODED            {list(encoded)}")
    print(f"FPGA OUT           0x{fpga_out:02X}")
    print(f"DECODED            {decoded if decoded else '(no known basin)'}")
    print()
    print(format_provenance(block))
    print()


def run_offline() -> int:
    ref = run_after_gate()
    print("OFFLINE golden (no COM). Not a board claim.")
    print(ref["provenance_text"])
    for turn in ref["turns"]:
        print_turn(
            turn["text"],
            encode_tokens(turn["text"]),
            turn["out"],
            turn["decoded"],
            ref["provenance"],
        )
    return 0 if ref["pass"] else 2


def run_board(port_name: str, baud: int) -> int:
    try:
        import serial
    except ImportError as exc:
        raise SystemExit("pip install pyserial") from exc

    from python.m8_hw04_temporal_reference import TRAIN_REPS
    from python.uart_frames import command_frame, phrase_probe_frame, phrase_sample_frame
    from tools.board_scorer_m8_hw06a import (
        CMD_T_RESET,
        CMD_T_TRAIN,
        probe_tokens,
        send,
        train_phrase,
    )

    latch = AfterTrainLatch()
    dec = LocalBasinDecoder()
    r1 = dec.register_target(BASIN_R1)
    t1 = encode_tokens(PHRASE_P1)
    t2 = encode_tokens(PHRASE_P2)

    print(f"Open {port_name} — SW11 ON, SW10 OFF, SW13 OFF")
    print("TRAIN then type a phrase. AFTER latch is one-way. Type /quit")
    with serial.Serial(port_name, baud, timeout=0.2) as port:
        import time

        time.sleep(0.15)
        port.reset_input_buffer()
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)
        latch.note_sample()
        train_phrase(port, t1, r1, TRAIN_REPS)
        latch.note_train()
        latch.note_sample()
        train_phrase(port, t2, r1, TRAIN_REPS)
        latch.note_train()
        latch.enter_after()
        print("AFTER latch ON. Teacher/Learn disconnected. Freeze ON.")
        block = provenance(weight_writes=0, llm_calls=0)
        print(format_provenance(block))
        while True:
            try:
                line = input("user> ").strip()
            except EOFError:
                break
            if not line or line in {"/quit", "/exit"}:
                break
            if line.startswith("/"):
                print("AFTER: only user phrases. No train commands.")
                continue
            latch.note_probe()
            rec = probe_tokens(port, encode_tokens(line))
            out = 0 if rec is None else int(rec.get("out") or 0)
            print_turn(line, encode_tokens(line), out, dec.decode(out), block)
    return 0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port", nargs="?", default="")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--offline", action="store_true")
    args = ap.parse_args()
    if args.offline or not args.port:
        raise SystemExit(run_offline())
    raise SystemExit(run_board(args.port, args.baud))


if __name__ == "__main__":
    main()

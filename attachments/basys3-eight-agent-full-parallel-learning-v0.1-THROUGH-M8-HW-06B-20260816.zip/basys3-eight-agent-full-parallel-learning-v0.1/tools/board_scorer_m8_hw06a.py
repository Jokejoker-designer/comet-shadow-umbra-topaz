"""M8-HW-06A board scorer: TRAIN then AFTER teacher-free single-turn.

Reuse m8hw04.bit. No LLM. Not conversation.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw03_dense_reference import matrix_sha256
from python.m8_hw04_temporal_reference import TRAIN_REPS
from python.m8_hw05_phrase_reference import (
    BASIN_R1,
    PHRASE_DISTRACTOR,
    PHRASE_P1,
    PHRASE_P2,
    encode_basin,
    encode_tokens,
)
from python.m8_hw06a_reference import (
    AfterTrainLatch,
    LocalBasinDecoder,
    format_provenance,
    provenance,
    run_after_gate,
)
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    matrix_from_pages,
    parse_frame,
    phrase_probe_frame,
    phrase_sample_frame,
    xor14,
)

CMD_DUMP = 0x03
CMD_T_RESET = 0x06
CMD_T_TRAIN = 0x07


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61, 0x62, 0x63, 0x64):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    return parse_frame(frame)
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def wait_temp(port, seconds: float = 3.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.3)
        if rec and rec.get("ok") and rec.get("kind") == 0x64:
            return rec
    return None


def collect_dump(port, seconds: float = 8.0) -> dict[int, list[int]]:
    pages: dict[int, list[int]] = {}
    deadline = time.time() + seconds
    while time.time() < deadline and len(pages) < 16:
        rec = read_frame(port, 0.4)
        if rec and rec.get("ok") and rec.get("kind") == 0x5D:
            pages[int(rec["page"])] = list(rec["weights"])
            print(f"  dump page {rec['page']} ({len(pages)}/16)", flush=True)
    return pages


def train_phrase(port, tokens, basin: int, reps: int) -> list:
    send(port, phrase_sample_frame(tokens, basin))
    time.sleep(0.05)
    events = []
    for i in range(reps):
        send(port, command_frame(CMD_T_TRAIN))
        ev = wait_temp(port)
        events.append(ev)
        print(
            f"  TRAIN {i + 1} tokens={list(tokens)} teacher={basin} "
            f"out={None if ev is None else ev.get('out')}",
            flush=True,
        )
    return events


def probe_tokens(port, tokens):
    send(port, phrase_probe_frame(tokens))
    return wait_temp(port)


def dump_sha(port, latch: AfterTrainLatch) -> tuple[str | None, list[list[int]] | None]:
    latch.note_dump()
    send(port, command_frame(CMD_DUMP))
    pages = collect_dump(port)
    if len(pages) < 16:
        return None, None
    mat = matrix_from_pages(pages)
    return matrix_sha256(mat), mat


def out_of(rec) -> int | None:
    return None if rec is None else rec.get("out")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--reps", type=int, default=TRAIN_REPS)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-06A/run_001"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "board").mkdir(exist_ok=True)
    (args.out / "replay").mkdir(exist_ok=True)

    gold = run_after_gate(reps=args.reps)
    latch = AfterTrainLatch()
    dec = LocalBasinDecoder()
    r1 = dec.register_target(BASIN_R1)
    t1 = encode_tokens(PHRASE_P1)
    t2 = encode_tokens(PHRASE_P2)
    td = encode_tokens(PHRASE_DISTRACTOR)
    assert r1 == encode_basin(BASIN_R1)

    transcript: list[str] = []
    print("Open", args.port, "— SW11 ON, SW10 OFF, SW13 OFF (A5 62 arms temporal)")
    print("Reuse m8hw04.bit. 06A AFTER = teacher-free single-turn. Not conversation.")
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.15)
        port.reset_input_buffer()
        # Arm temporal_sel with A5 62 before RESET (same order as M8-HW-05).
        latch.note_sample()
        send(port, phrase_sample_frame(t1, r1))
        time.sleep(0.08)
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)

        print("=== TRAIN (teacher legal) ===")
        train_phrase(port, t1, r1, args.reps)
        latch.note_train()
        latch.note_sample()
        train_phrase(port, t2, r1, args.reps)
        latch.note_train()

        print("=== AFTER latch ===")
        latch.enter_after()
        sha_before, mat_before = dump_sha(port, latch)
        print("SHA before AFTER infer", sha_before)

        turns = {}
        for name, tokens, text in (
            ("P1", t1, PHRASE_P1),
            ("P2", t2, PHRASE_P2),
            ("D", td, PHRASE_DISTRACTOR),
        ):
            latch.note_probe()
            rec = probe_tokens(port, tokens)
            out = out_of(rec)
            label = dec.decode(out or 0)
            turns[name] = {"rec": rec, "out": out, "decoded": label, "text": text}
            block = provenance(weight_writes=0, llm_calls=dec.llm_calls)
            line = (
                f"user> {text}\n"
                f"ENCODED            {list(tokens)}\n"
                f"FPGA OUT           {None if out is None else hex(out)}\n"
                f"DECODED            {label if label else '(no known basin)'}\n\n"
                f"{format_provenance(block)}\n"
            )
            print(line)
            transcript.append(line)

        sha_after, mat_after = dump_sha(port, latch)
        print("SHA after AFTER infer", sha_after)

    after_illegal = 0
    try:
        latch.note_train()
    except RuntimeError:
        after_illegal += 1
    try:
        latch.note_sample()
    except RuntimeError:
        after_illegal += 1

    gates = {
        "p1_out_is_r1": turns["P1"]["out"] == r1,
        "p1_decodes": turns["P1"]["decoded"] == BASIN_R1,
        "p2_decodes": turns["P2"]["decoded"] == BASIN_R1,
        "distractor_not_r1_text": turns["D"]["decoded"] != BASIN_R1,
        "sha_present": sha_before is not None and sha_after is not None,
        "weights_frozen": sha_before is not None and sha_before == sha_after,
        "llm_zero": dec.llm_calls == 0,
        "after_forbids_train_and_sample": after_illegal == 2,
        "gold_pass": gold["pass"],
    }
    passed = all(gates.values())
    block = provenance(weight_writes=0, llm_calls=0)
    verdict = {
        "pass": passed,
        "gates": gates,
        "outs": {k: v["out"] for k, v in turns.items()},
        "decoded": {k: v["decoded"] for k, v in turns.items()},
        "sha_before": sha_before,
        "sha_after": sha_after,
        "r1": r1,
        "provenance": block,
        "bitstream": "basys3_eight_agent_m8hw04.bit",
        "claim": (
            "TEACHER_FREE_AFTER_TRAIN_SIMPLE_INTERACTION_BOARD_VALIDATED"
            if passed
            else "M8_HW_06A_BOARD_NOT_PASS"
        ),
    }
    (args.out / "replay" / "score.json").write_text(
        json.dumps(verdict, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    (args.out / "ui_transcript.txt").write_text(
        "M8-HW-06A AFTER-TRAIN INTERACTION  (not conversation)\n\n"
        + "\n".join(transcript)
        + "\n"
        + format_provenance(block)
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps(verdict, indent=2, ensure_ascii=False))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

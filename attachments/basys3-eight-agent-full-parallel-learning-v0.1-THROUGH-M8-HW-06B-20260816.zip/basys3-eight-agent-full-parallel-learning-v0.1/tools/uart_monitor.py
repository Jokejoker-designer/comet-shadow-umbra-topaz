from __future__ import annotations
import argparse, time
try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

FRAME_LEN = 15


def signed16(lo: int, hi: int) -> int:
    value = lo | (hi << 8)
    return value - 0x10000 if value & 0x8000 else value


def read_frame(port):
    state = 0
    idle = 0
    while True:
        b = port.read(1)
        if not b:
            idle += 1
            if idle >= 2:
                return None
            continue
        idle = 0
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                chk = 0
                for x in frame[:14]:
                    chk ^= x
                if chk == frame[14]:
                    return frame
                state = 0
            else:
                state = 1 if v == 0xA5 else 0


def format_frame(f: bytes) -> str:
    if f[1] == 0x5C:
        return (
            f"RESULT before_mis={f[2]|(f[3]<<8)} after_mis={f[4]|(f[5]<<8)} "
            f"before_hits={f[6]} after_hits={f[7]} routes={f[8]:08b} "
            f"final={(f[9]>>7)&1} freeze={(f[9]>>6)&1} phase={f[9]&0xF} "
            f"updates={f[10]|(f[11]<<8)} tick={f[12]|(f[13]<<8)}"
        )
    if f[1] == 0x5D:
        return (
            f"DUMP snap={f[2]} page={f[4]} "
            f"w={signed16(f[5], f[6])},{signed16(f[7], f[8])},"
            f"{signed16(f[9], f[10])},{signed16(f[11], f[12])} "
            f"phase={f[13]&0xF}"
        )
    if f[1] == 0x5E:
        seed = f[2] | (f[3] << 8) | (f[4] << 16) | (f[5] << 24)
        perm = list(f[6:14])
        return f"SESSION seed={seed} perm={perm}"
    w = signed16(f[8], f[9])
    fl = f[13]
    return (
        f"tick={f[2]|(f[3]<<8):5d} updates={f[4]|(f[5]<<8):5d} "
        f"mismatch={f[6]|(f[7]<<8):5d} weight={w:6d} hex={w&0xFFFF:04X} "
        f"in=0x{f[10]:02X} out=0x{f[11]:02X} "
        f"auto={(fl>>6)&1} learn={(fl>>5)&1} freeze={(fl>>4)&1}"
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--seconds", type=float, default=0)
    ap.add_argument("--max-frames", type=int, default=0)
    args = ap.parse_args()
    deadline = time.time() + args.seconds if args.seconds else None
    seen = 0
    with serial.Serial(args.port, 115200, timeout=0.4) as ser:
        print(f"Listening on {args.port} @ 115200")
        while True:
            if deadline and time.time() >= deadline:
                print(f"STOP seconds={args.seconds} frames={seen}")
                return
            f = read_frame(ser)
            if f is None:
                continue
            print(format_frame(f), flush=True)
            seen += 1
            if args.max_frames and seen >= args.max_frames:
                print(f"STOP max-frames={args.max_frames}")
                return


if __name__ == "__main__":
    main()

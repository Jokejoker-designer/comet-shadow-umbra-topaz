"""M8-HW-03 board scorer: BEFORE → one dense TRAIN → AFTER → FREEZE."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw03_dense_reference import (
    STIM_A,
    STIM_B,
    TEACH_A,
    matrix_sha256,
    one_dense_train,
    run_controls,
)
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    dense_sample_frame,
    matrix_from_pages,
    parse_frame,
    xor14,
)

CMD_RESET = 0x02
CMD_DUMP = 0x03
CMD_DENSE_TRAIN = 0x04
CMD_FREEZE_INFER = 0x05


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    rec = parse_frame(frame)
                    rec["raw_hex"] = frame.hex()
                    return rec
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def collect_dump(port, log, seconds: float = 8.0) -> dict[int, list[int]]:
    pages: dict[int, list[int]] = {}
    deadline = time.time() + seconds
    while time.time() < deadline and len(pages) < 16:
        rec = read_frame(port, 0.4)
        if not rec or not rec.get("ok"):
            continue
        log.append(rec)
        if rec["kind"] == 0x5D:
            pages[int(rec["page"])] = list(rec["weights"])
            print(f"  dump page {rec['page']} snap={rec.get('snapshot')} ({len(pages)}/16)", flush=True)
    return pages


def wait_event(port, log, seconds: float = 4.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.4)
        if not rec or not rec.get("ok"):
            continue
        log.append(rec)
        if rec["kind"] == 0x61:
            return rec
    return None


def write_csv(path: Path, mat: list[list[int]]) -> None:
    path.write_text("\n".join(",".join(str(v) for v in row) for row in mat) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-03/run_001"))
    args = ap.parse_args()
    out = args.out
    for sub in ("board", "matrices", "replay"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    gold = run_controls()
    log: list[dict] = []
    print("Open", args.port, "115200 — SW11 ON, SW12 ON, SW10 OFF, LED15 ON")
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.2)
        port.reset_input_buffer()

        print("LOAD Dense-A first so FPGA enters dense_sel, then RESET + DUMP BEFORE")
        send(port, dense_sample_frame(STIM_A, TEACH_A, 8))
        rec = read_frame(port, 1.0)
        if rec:
            log.append(rec)
        send(port, command_frame(CMD_RESET))
        time.sleep(0.05)
        send(port, command_frame(CMD_DUMP))
        pages_b = collect_dump(port, log)
        print(f"BEFORE pages={len(pages_b)}")

        print("LOAD Dense-A", hex(STIM_A), hex(TEACH_A))
        send(port, dense_sample_frame(STIM_A, TEACH_A, 8))
        rec = read_frame(port, 1.0)
        if rec:
            log.append(rec)
        send(port, command_frame(CMD_DENSE_TRAIN))
        ev = wait_event(port, log, 6.0)
        print("  event", None if ev is None else ev.get("changed_cell_count"))
        time.sleep(0.05)
        send(port, command_frame(CMD_DUMP))
        pages_a = collect_dump(port, log)
        print(f"AFTER pages={len(pages_a)}")

        print("FREEZE + 32 infer")
        send(port, command_frame(CMD_FREEZE_INFER))
        time.sleep(3.0)
        send(port, command_frame(CMD_DUMP))
        pages_f = collect_dump(port, log)
        print(f"FREEZE pages={len(pages_f)}")

        print("RESET + Dense-B")
        send(port, command_frame(CMD_RESET))
        time.sleep(0.05)
        send(port, dense_sample_frame(STIM_B, TEACH_A, 8))
        send(port, command_frame(CMD_DENSE_TRAIN))
        ev_b = wait_event(port, log, 6.0)
        send(port, command_frame(CMD_DUMP))
        pages_bb = collect_dump(port, log)
        print(f"B pages={len(pages_bb)} event={None if ev_b is None else ev_b.get('changed_cell_count')}")

    (out / "board" / "uart.jsonl").write_text(
        "\n".join(json.dumps({k: v for k, v in r.items() if k != "raw"}) for r in log) + "\n",
        encoding="utf-8",
    )

    mats = {}
    if len(pages_b) == 16:
        mats["before"] = matrix_from_pages(pages_b)
    if len(pages_a) == 16:
        mats["after_a"] = matrix_from_pages(pages_a)
    if len(pages_f) == 16:
        mats["freeze"] = matrix_from_pages(pages_f)
    if len(pages_bb) == 16:
        mats["after_b"] = matrix_from_pages(pages_bb)
    for name, mat in mats.items():
        write_csv(out / "matrices" / f"{name}.csv", mat)

    ga = gold["dense_a"]
    gb = gold["dense_b"]
    delta_ok = False
    changed_cells = 0
    if "after_a" in mats and "before" in mats:
        for d in range(8):
            for s in range(8):
                if mats["after_a"][d][s] != mats["before"][d][s]:
                    changed_cells += 1
        delta_ok = mats["after_a"] == ga["expected_after"]

    ev_ch = None if ev is None else int(ev.get("changed_cell_count") or -1)
    evb_ch = None if ev_b is None else int(ev_b.get("changed_cell_count") or -1)

    gates = {
        "pages_before_16": len(pages_b) == 16,
        "pages_after_16": len(pages_a) == 16,
        "pages_freeze_16": len(pages_f) == 16,
        "pages_b_16": len(pages_bb) == 16,
        "before_neutral": "before" in mats and mats["before"] == ga["expected_before"],
        "event_changed_64": ev_ch == 64,
        "host_delta_64": changed_cells == 64,
        "after_matches_python": delta_ok,
        "after_sha_match": "after_a" in mats and matrix_sha256(mats["after_a"]) == ga["matrix_sha256"],
        "freeze_bit_exact": "freeze" in mats and "after_a" in mats and mats["freeze"] == mats["after_a"],
        "b_event_64": evb_ch == 64,
        "b_matches_python": "after_b" in mats and mats["after_b"] == gb["expected_after"],
    }
    passed = all(gates.values())
    verdict = {
        "pass": passed,
        "gates": gates,
        "event_changed": ev_ch,
        "host_changed": changed_cells,
        "event_b": evb_ch,
        "sha_a": None if "after_a" not in mats else matrix_sha256(mats["after_a"]),
        "sha_python_a": ga["matrix_sha256"],
        "claim": (
            "64_SYNAPSES_SIMULTANEOUSLY_ACTIVE_FULL_PARALLEL_PLASTICITY_BOARD_VALIDATED"
            if passed
            else "M8_HW_03_BOARD_NOT_PASS"
        ),
    }
    (out / "replay" / "score.json").write_text(json.dumps(verdict, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(verdict, indent=2))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

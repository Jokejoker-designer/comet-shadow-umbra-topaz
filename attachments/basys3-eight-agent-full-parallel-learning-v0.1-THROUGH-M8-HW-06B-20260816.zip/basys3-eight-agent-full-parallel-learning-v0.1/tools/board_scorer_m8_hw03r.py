"""M8-HW-03R: random mixed-polarity dense sessions on the same bitstream."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw03_dense_reference import matrix_sha256, neutral_matrix, one_dense_train
from python.m8_hw03r_sessions import session_pair
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    dense_sample_frame,
    matrix_from_pages,
    parse_frame,
    xor14,
)

CMD_RESET = 0x02
CMD_DUMP = 0x03
CMD_DENSE_TRAIN = 0x04
CMD_FREEZE_INFER = 0x05


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    rec = parse_frame(frame)
                    return rec
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def collect_dump(port, seconds: float = 6.0) -> dict[int, list[int]]:
    pages: dict[int, list[int]] = {}
    deadline = time.time() + seconds
    while time.time() < deadline and len(pages) < 16:
        rec = read_frame(port, 0.3)
        if not rec or not rec.get("ok"):
            continue
        if rec["kind"] == 0x5D:
            pages[int(rec["page"])] = list(rec["weights"])
    return pages


def wait_event(port, seconds: float = 4.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.3)
        if rec and rec.get("ok") and rec["kind"] == 0x61:
            return rec
    return None


def one_session(port, seed: int) -> dict:
    stim, teacher = session_pair(seed)
    gold = one_dense_train(neutral_matrix(), stim, teacher)
    send(port, dense_sample_frame(stim, teacher, 8))
    time.sleep(0.02)
    send(port, command_frame(CMD_RESET))
    time.sleep(0.04)
    send(port, command_frame(CMD_DUMP))
    pages_b = collect_dump(port)
    send(port, dense_sample_frame(stim, teacher, 8))
    time.sleep(0.02)
    send(port, command_frame(CMD_DENSE_TRAIN))
    ev = wait_event(port)
    send(port, command_frame(CMD_DUMP))
    pages_a = collect_dump(port)
    send(port, command_frame(CMD_FREEZE_INFER))
    time.sleep(0.25)
    send(port, command_frame(CMD_DUMP))
    pages_f = collect_dump(port)

    before = matrix_from_pages(pages_b) if len(pages_b) == 16 else None
    after = matrix_from_pages(pages_a) if len(pages_a) == 16 else None
    freeze = matrix_from_pages(pages_f) if len(pages_f) == 16 else None
    ev_ch = None if ev is None else int(ev.get("changed_cell_count") or -1)
    gates = {
        "pages": len(pages_b) == 16 and len(pages_a) == 16 and len(pages_f) == 16,
        "before_neutral": before == gold["expected_before"],
        "event_64": ev_ch == 64,
        "after_python": after == gold["expected_after"],
        "freeze_exact": freeze is not None and after is not None and freeze == after,
    }
    ok = all(gates.values())
    return {
        "seed": seed,
        "stim": stim,
        "teacher": teacher,
        "pass": ok,
        "gates": gates,
        "event_changed": ev_ch,
        "before_sha": None if before is None else matrix_sha256(before),
        "after_sha": None if after is None else matrix_sha256(after),
        "freeze_sha": None if freeze is None else matrix_sha256(freeze),
        "python_sha": gold["matrix_sha256"],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--count", type=int, default=32)
    ap.add_argument("--base-seed", type=int, default=2026081432)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-03R/run_032"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    rows = []
    print(f"M8-HW-03R n={args.count} COM {args.port} SW11+SW12 ON SW10+SW13 OFF")
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.15)
        port.reset_input_buffer()
        send(port, dense_sample_frame(0xB4, 0x6B, 8))
        time.sleep(0.05)
        for i in range(args.count):
            seed = args.base_seed + i
            rec = one_session(port, seed)
            rows.append(rec)
            mark = "PASS" if rec["pass"] else "FAIL"
            print(
                f"[{i+1:03d}/{args.count}] {mark} seed={seed} "
                f"stim=0x{rec['stim']:02X} teach=0x{rec['teacher']:02X} "
                f"ch={rec['event_changed']} sha={(rec['after_sha'] or '')[:12]}",
                flush=True,
            )
            if not rec["pass"]:
                print("  gates", rec["gates"], flush=True)

    n_ok = sum(1 for r in rows if r["pass"])
    verdict = {
        "pass": n_ok == args.count,
        "passed": n_ok,
        "total": args.count,
        "base_seed": args.base_seed,
        "claim": (
            f"M8_HW_03R_{args.count}_OF_{args.count}_PASS"
            if n_ok == args.count
            else f"M8_HW_03R_{n_ok}_OF_{args.count}_FAIL"
        ),
        "sessions": rows,
    }
    (args.out / "score.json").write_text(json.dumps(verdict, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: verdict[k] for k in ("pass", "passed", "total", "claim")}, indent=2))
    raise SystemExit(0 if verdict["pass"] else 2)


if __name__ == "__main__":
    main()

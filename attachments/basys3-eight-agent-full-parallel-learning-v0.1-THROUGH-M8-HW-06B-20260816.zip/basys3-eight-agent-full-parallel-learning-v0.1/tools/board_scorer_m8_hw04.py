"""M8-HW-04 board scorer: train A,B,C→X then probe ABC/ACB/BAC/AB."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw04_temporal_reference import SYM_A, SYM_B, SYM_C, SYM_X, TRAIN_REPS, run_first_gate
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    parse_frame,
    temporal_probe_frame,
    temporal_sample_frame,
    xor14,
)

CMD_DUMP = 0x03
CMD_T_RESET = 0x06
CMD_T_TRAIN = 0x07


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61, 0x62, 0x63, 0x64):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    return parse_frame(frame)
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def wait_temp(port, seconds: float = 3.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.3)
        if rec and rec.get("ok") and rec.get("kind") == 0x64:
            return rec
    return None


def probe(port, n: int, s0: int, s1: int, s2: int = 0) -> dict | None:
    send(port, temporal_probe_frame(n, s0, s1, s2))
    return wait_temp(port)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--reps", type=int, default=TRAIN_REPS)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-04/run_001"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "board").mkdir(exist_ok=True)
    gold = run_first_gate(reps=args.reps)

    print("Open", args.port, "— SW11 ON, SW10 OFF, SW13 OFF (A5 62 arms temporal)")
    results = {}
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.15)
        port.reset_input_buffer()
        send(port, temporal_sample_frame(SYM_A, SYM_B, SYM_C, SYM_X))
        time.sleep(0.05)
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)
        print(f"TRAIN x{args.reps} A,B,C -> X")
        for i in range(args.reps):
            send(port, command_frame(CMD_T_TRAIN))
            ev = wait_temp(port)
            print(f"  train {i+1} ctx={None if ev is None else ev.get('ctx')} out={None if ev is None else ev.get('out')}", flush=True)
        results["ABC"] = probe(port, 3, SYM_A, SYM_B, SYM_C)
        print("ABC", results["ABC"])
        results["ACB"] = probe(port, 3, SYM_A, SYM_C, SYM_B)
        print("ACB", results["ACB"])
        results["BAC"] = probe(port, 3, SYM_B, SYM_A, SYM_C)
        print("BAC", results["BAC"])
        results["AB"] = probe(port, 2, SYM_A, SYM_B, 0)
        print("AB ", results["AB"])
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)
        results["FORGET"] = probe(port, 3, SYM_A, SYM_B, SYM_C)
        print("FORGET", results["FORGET"])

    def out_of(name: str) -> int | None:
        rec = results.get(name)
        return None if rec is None else rec.get("out")

    gates = {
        "abc_is_x": out_of("ABC") == SYM_X,
        "acb_not_x": out_of("ACB") is not None and out_of("ACB") != SYM_X,
        "bac_not_x": out_of("BAC") is not None and out_of("BAC") != SYM_X,
        "ab_not_x": out_of("AB") is not None and out_of("AB") != SYM_X,
        "forget_not_x": out_of("FORGET") is not None and out_of("FORGET") != SYM_X,
    }
    passed = all(gates.values())
    verdict = {
        "pass": passed,
        "gates": gates,
        "outs": {k: out_of(k) for k in ("ABC", "ACB", "BAC", "AB", "FORGET")},
        "gold_pass": gold["pass"],
        "claim": "TEMPORAL_SEQUENCE_MEMORY_BOARD_VALIDATED" if passed else "M8_HW_04_BOARD_NOT_PASS",
    }
    (args.out / "replay").mkdir(exist_ok=True)
    (args.out / "replay" / "score.json").write_text(json.dumps(verdict, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(verdict, indent=2))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

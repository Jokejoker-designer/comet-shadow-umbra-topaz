"""M8-HW-05 board scorer: two host-encoded phrases → one learned basin.

Reuses m8hw04.bit temporal UART (A5 62/63/64). No new bitstream.
Phrases never leave the host encoder.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

try:
    import serial
except ImportError as exc:
    raise SystemExit("pip install pyserial") from exc

from python.m8_hw04_temporal_reference import TRAIN_REPS
from python.m8_hw05_phrase_reference import (
    BASIN_R1,
    BASIN_R2,
    PHRASE_DISTRACTOR,
    PHRASE_P1,
    PHRASE_P2,
    encode_basin,
    encode_tokens,
    run_first_gate,
)
from python.uart_frames import (
    FRAME_LEN,
    command_frame,
    parse_frame,
    phrase_probe_frame,
    phrase_sample_frame,
    xor14,
)

CMD_T_RESET = 0x06
CMD_T_TRAIN = 0x07


def read_frame(port, timeout_s: float):
    deadline = time.time() + timeout_s
    state = 0
    while time.time() < deadline:
        b = port.read(1)
        if not b:
            continue
        v = b[0]
        if state == 0:
            state = 1 if v == 0xA5 else 0
        elif state == 1:
            if v in (0x5A, 0x5C, 0x5D, 0x5E, 0x60, 0x61, 0x62, 0x63, 0x64):
                rest = port.read(FRAME_LEN - 2)
                if len(rest) != FRAME_LEN - 2:
                    state = 0
                    continue
                frame = bytes([0xA5, v]) + rest
                if xor14(frame) == frame[14]:
                    return parse_frame(frame)
                state = 0
            else:
                state = 1 if v == 0xA5 else 0
    return None


def send(port, frame: bytes) -> None:
    port.write(frame)
    port.flush()


def wait_temp(port, seconds: float = 3.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        rec = read_frame(port, 0.3)
        if rec and rec.get("ok") and rec.get("kind") == 0x64:
            return rec
    return None


def train_phrase(port, tokens, basin: int, reps: int) -> list:
    send(port, phrase_sample_frame(tokens, basin))
    time.sleep(0.05)
    events = []
    for i in range(reps):
        send(port, command_frame(CMD_T_TRAIN))
        ev = wait_temp(port)
        events.append(ev)
        print(
            f"  train {i + 1} tokens={list(tokens)} basin={basin} "
            f"ctx={None if ev is None else ev.get('ctx')} "
            f"out={None if ev is None else ev.get('out')}",
            flush=True,
        )
    return events


def probe_tokens(port, tokens):
    send(port, phrase_probe_frame(tokens))
    return wait_temp(port)


def out_of(rec) -> int | None:
    return None if rec is None else rec.get("out")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--reps", type=int, default=TRAIN_REPS)
    ap.add_argument("--out", type=Path, default=Path("results/M8-HW-05/run_001"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "board").mkdir(exist_ok=True)
    gold = run_first_gate(reps=args.reps)
    t1 = encode_tokens(PHRASE_P1)
    t2 = encode_tokens(PHRASE_P2)
    td = encode_tokens(PHRASE_DISTRACTOR)
    r1 = encode_basin(BASIN_R1)
    r2 = encode_basin(BASIN_R2)

    print("Open", args.port, "— SW11 ON, SW10 OFF, SW13 OFF (A5 62 arms temporal)")
    print("Reuse m8hw04.bit. Host encoder only. No HELLO in RTL.")
    print("P1", PHRASE_P1, list(t1), "P2", PHRASE_P2, list(t2), "D", list(td))
    print("R1", hex(r1), "R2", hex(r2))
    results = {}
    with serial.Serial(args.port, args.baud, timeout=0.2) as port:
        time.sleep(0.15)
        port.reset_input_buffer()
        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)

        print(f"TRAIN only P1 x{args.reps} -> R1")
        train_phrase(port, t1, r1, args.reps)
        results["P1_ONLY_P1"] = probe_tokens(port, t1)
        results["P1_ONLY_P2"] = probe_tokens(port, t2)
        print("P1_ONLY_P1", results["P1_ONLY_P1"])
        print("P1_ONLY_P2", results["P1_ONLY_P2"])

        print(f"TRAIN P2 x{args.reps} -> R1 (weights kept)")
        train_phrase(port, t2, r1, args.reps)
        results["BOTH_P1"] = probe_tokens(port, t1)
        results["BOTH_P2"] = probe_tokens(port, t2)
        results["DISTRACTOR"] = probe_tokens(port, td)
        print("BOTH_P1", results["BOTH_P1"])
        print("BOTH_P2", results["BOTH_P2"])
        print("DISTRACTOR", results["DISTRACTOR"])

        send(port, command_frame(CMD_T_RESET))
        time.sleep(0.05)
        results["FORGET"] = probe_tokens(port, t1)
        print("FORGET", results["FORGET"])

        print(f"REMAP P1+P2 x{args.reps} -> R2")
        train_phrase(port, t1, r2, args.reps)
        train_phrase(port, t2, r2, args.reps)
        results["REMAP_P1"] = probe_tokens(port, t1)
        results["REMAP_P2"] = probe_tokens(port, t2)
        print("REMAP_P1", results["REMAP_P1"])
        print("REMAP_P2", results["REMAP_P2"])

    gates = {
        "p1_only_hits_r1": out_of(results["P1_ONLY_P1"]) == r1,
        "p1_only_p2_misses": out_of(results["P1_ONLY_P2"]) is not None
        and out_of(results["P1_ONLY_P2"]) != r1,
        "both_p1_is_r1": out_of(results["BOTH_P1"]) == r1,
        "both_p2_is_r1": out_of(results["BOTH_P2"]) == r1,
        "distractor_not_r1": out_of(results["DISTRACTOR"]) is not None
        and out_of(results["DISTRACTOR"]) != r1,
        "forget_not_r1": out_of(results["FORGET"]) is not None
        and out_of(results["FORGET"]) != r1,
        "remap_p1_is_r2": out_of(results["REMAP_P1"]) == r2,
        "remap_p2_is_r2": out_of(results["REMAP_P2"]) == r2,
        "remap_not_old_r1": out_of(results["REMAP_P1"]) != r1,
    }
    passed = all(gates.values())
    verdict = {
        "pass": passed,
        "gates": gates,
        "outs": {k: out_of(v) for k, v in results.items()},
        "expected": {"R1": r1, "R2": r2, "tokens": {"P1": list(t1), "P2": list(t2), "D": list(td)}},
        "gold_pass": gold["pass"],
        "bitstream": "basys3_eight_agent_m8hw04.bit",
        "claim": "PHRASE_BASIN_ASSOCIATION_BOARD_VALIDATED" if passed else "M8_HW_05_BOARD_NOT_PASS",
    }
    (args.out / "replay").mkdir(exist_ok=True)
    (args.out / "replay" / "score.json").write_text(
        json.dumps(verdict, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(verdict, indent=2))
    raise SystemExit(0 if passed else 2)


if __name__ == "__main__":
    main()

# Validation

## Python

```bat
set PYTHONPATH=.
python -m pytest -q tests
```

Legacy golden-model tests + `tests/test_route_gate8.py`.
Those tests are **not** a remapping board proof.

## M8-HW-01 (closed 2026-08-14)

Vivado 2026.1 / `xc7a35tcpg236-1`:

- `BASYS3_BUILD_PASS` WNS **+103.692 ns**
- bit `build/out/basys3_eight_agent.bit` (2,192,225 bytes)
- program Digilent `210183BF7B31A` startup HIGH

COM8 after SW11 + BTNU, **cyclic** teacher only:

| Phase | Evidence |
|-------|----------|
| EVAL_BEFORE 1–32 | `W=64=0040`, `out=00` |
| TRAIN 33 | LTP `64→72` |
| First route 233 | `in=01 out=02`, `W=272` |
| HOLD 1057+ | `W=1088=0440`, updates frozen 1024 |
| Frozen cyclic | **650 / 650** |

Verdict: `8_AGENT_CYCLIC_LEARNING_CONVERGENCE_DEMONSTRATED`.

**Not** `GENUINE_ASSOCIATIVE_LEARNING`. **Not** conversation.

## M8-HW-02 … M8-HW-04

Closed on silicon. See `VALIDATION.json` and `results/MILESTONE_CHECKLIST.md`.

## M8-HW-05 (closed 2026-08-14)

Same `m8hw04.bit` `DEEFE548…`. Host encoder. COM8:

| Gate | out |
|------|-----|
| `xin chào` + `hello` joint | **0x88** |
| `hello` after P1-only | **0** |
| `tạm biệt` | **0x77** |
| RESET | **0** |
| remap | **0xCC** |

`PHRASE_BASIN_ASSOCIATION_BOARD_VALIDATED`. **Not** conversation.


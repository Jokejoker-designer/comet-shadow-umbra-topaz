from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl"

forbidden = [
    r"\bHELLO\b", r"\bGOODBYE\b", r"\bASK_NAME\b", r"\bRESPONSE\b",
    r"\bAGENT0_ROLE\b", r"\bAGENT1_ROLE\b", r"prompt_to_response",
    r"xin chào", r"chào bạn", r"tạm biệt", r"rất vui",
]

bad = []
for path in RTL.rglob("*.sv"):
    text = path.read_text(encoding="utf-8", errors="replace")
    for pat in forbidden:
        if re.search(pat, text, flags=re.I):
            bad.append((str(path.relative_to(ROOT)), pat))

if bad:
    print("ANTI-HARDCODE FAIL")
    for row in bad:
        print(row)
    sys.exit(1)

print("ANTI-HARDCODE PASS: no semantic role/response table markers in RTL")

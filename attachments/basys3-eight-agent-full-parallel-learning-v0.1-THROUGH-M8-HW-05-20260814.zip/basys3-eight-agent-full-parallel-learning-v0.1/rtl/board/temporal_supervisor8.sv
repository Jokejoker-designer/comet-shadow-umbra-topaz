`timescale 1ns/1ps
// Host-stepped A,B,C train / 2- or 3-symbol probe.
// Symbol bytes come from registers. No compiled mapping.
module temporal_supervisor8 (
    input  logic clk,
    input  logic rst_n,
    input  logic enable,
    input  logic sample_valid,
    input  logic [7:0] sym_a,
    input  logic [7:0] sym_b,
    input  logic [7:0] sym_c,
    input  logic [7:0] target,
    input  logic train_cmd,
    input  logic reset_cmd,
    input  logic probe_cmd,
    input  logic [7:0] probe_n,
    input  logic [7:0] probe_s0,
    input  logic [7:0] probe_s1,
    input  logic [7:0] probe_s2,
    output logic clear_ctx,
    output logic reset_weights,
    output logic step,
    output logic learn,
    output logic [7:0] stim,
    output logic [7:0] teacher,
    output logic event_strobe,
    output logic [3:0] phase,
    output logic [7:0] snapshot_id
);
    typedef enum logic [3:0] {
        ST_IDLE  = 4'd0,
        ST_CLR   = 4'd1,
        ST_S0    = 4'd2,
        ST_S1    = 4'd3,
        ST_S2    = 4'd4,
        ST_EVT   = 4'd5
    } state_t;

    state_t state;
    logic doing_train;
    logic two_only;
    logic [7:0] s0, s1, s2;

    assign phase = state;

    always_comb begin
        clear_ctx = 1'b0;
        step = 1'b0;
        learn = 1'b0;
        stim = 8'd0;
        teacher = 8'd0;
        if (enable && reset_cmd)
            clear_ctx = 1'b1;
        else if (enable) begin
            unique case (state)
                ST_CLR: clear_ctx = 1'b1;
                ST_S0: begin
                    stim = s0;
                    step = 1'b1;
                end
                ST_S1: begin
                    stim = s1;
                    step = 1'b1;
                end
                ST_S2: begin
                    stim = s2;
                    step = 1'b1;
                    learn = doing_train;
                    teacher = doing_train ? target : 8'd0;
                end
                default: ;
            endcase
        end
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            reset_weights <= 1'b0;
            event_strobe <= 1'b0;
            snapshot_id <= 8'd1;
            doing_train <= 1'b0;
            two_only <= 1'b0;
            s0 <= 8'd0;
            s1 <= 8'd0;
            s2 <= 8'd0;
        end else begin
            reset_weights <= 1'b0;
            event_strobe <= 1'b0;
            if (!enable) begin
                state <= ST_IDLE;
            end else if (reset_cmd) begin
                reset_weights <= 1'b1;
                snapshot_id <= 8'd1;
                state <= ST_IDLE;
            end else begin
                unique case (state)
                    ST_IDLE: begin
                        if (train_cmd && sample_valid) begin
                            doing_train <= 1'b1;
                            two_only <= 1'b0;
                            s0 <= sym_a;
                            s1 <= sym_b;
                            s2 <= sym_c;
                            state <= ST_CLR;
                        end else if (probe_cmd) begin
                            doing_train <= 1'b0;
                            two_only <= (probe_n == 8'd2);
                            s0 <= probe_s0;
                            s1 <= probe_s1;
                            s2 <= probe_s2;
                            state <= ST_CLR;
                        end
                    end
                    ST_CLR: state <= ST_S0;
                    ST_S0: state <= ST_S1;
                    ST_S1: state <= two_only ? ST_EVT : ST_S2;
                    ST_S2: state <= ST_EVT;
                    ST_EVT: begin
                        event_strobe <= 1'b1;
                        snapshot_id <= snapshot_id + 8'd1;
                        state <= ST_IDLE;
                    end
                    default: state <= ST_IDLE;
                endcase
            end
        end
    end
endmodule

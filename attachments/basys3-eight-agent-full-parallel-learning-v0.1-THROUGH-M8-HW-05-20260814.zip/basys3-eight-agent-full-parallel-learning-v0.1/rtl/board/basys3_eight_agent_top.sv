`timescale 1ns/1ps
module basys3_eight_agent_top #(
    parameter int DEBOUNCE_BITS = 17,
    parameter int AUTO_INTERVAL_CYCLES = 625000,
    parameter int STRETCH_CYCLES = 625000,
    parameter int EVAL_TICKS = 32,
    parameter int TRAIN_TICKS_REMAP = 256,
    parameter int TRAIN_TICKS_CYCLIC = 1024
) (
    input  logic clk,
    input  logic [15:0] sw,
    input  logic btnC,
    input  logic btnU,
    input  logic btnL,
    input  logic btnR,
    input  logic btnD,
    output logic [15:0] led,
    output logic [6:0] seg,
    output logic dp,
    output logic [3:0] an,
    output logic RsTx,
    input  logic RsRx
);
    logic core_clk, clk_locked, core_rst_n, btnL_sync;
    logic [15:0] sw_sync;
    logic start_manual, btnU_pulse, clear_state_pulse, telemetry_manual, unused;
    logic auto_start;
    logic [7:0] auto_source, score_teacher;
    logic [2:0] auto_phase;
    logic [31:0] auto_epochs;
    logic [7:0] effective_source, core_teacher;
    logic effective_start, effective_learn, effective_freeze;
    logic signed [15:0] selected_weight;
    logic signed [1023:0] weights_packed;
    logic busy, done, update_applied;
    logic [7:0] encoded_spikes, output_spikes;
    logic [31:0] tick_count, update_count, mismatch_count;
    logic done_visible, update_visible, telemetry_busy, dump_busy, dump_done;
    logic [7:0] telemetry_flags;
    logic trainer_enable, sup_learn, sup_freeze, sup_clear, result_strobe;
    logic [3:0] sup_phase;
    logic [15:0] before_mismatch, after_mismatch, before_hits, after_hits, forget_hits;
    logic [7:0] before_acc, after_acc, route_pass;
    logic freeze_pass, final_pass;
    logic sup_reset_w, dump_start;
    logic [7:0] snapshot_id;
    logic rx_valid;
    logic [7:0] rx_data;
    logic session_valid, session_load_pulse, cmd_start, cmd_reset, cmd_dump;
    logic cmd_dense_train, cmd_freeze_infer, dense_valid, dense_load_pulse;
    logic [7:0] dense_stim, dense_teacher, dense_lr;
    logic [31:0] session_seed;
    logic [63:0] perm_packed;
    logic session_echo_hold;
    logic cyclic_mode, dense_sel, temporal_sel;
    logic temporal_valid, temporal_load_pulse, cmd_t_reset, cmd_t_train, probe_cmd;
    logic [7:0] sym_a, sym_b, sym_c, target_x, probe_n, probe_s0, probe_s1, probe_s2;
    logic t_clear, t_reset_w, t_step, t_learn, t_event;
    logic [7:0] t_stim, t_teacher, t_ctx, t_out, t_snap;
    logic [3:0] t_phase;
    logic signed [1023:0] t_weights;
    logic start_cmd;
    logic [6:0] changed_cell_count;
    logic dens_start, dens_learn, dens_freeze, dens_clear, dens_reset_w, dens_event;
    logic [7:0] dens_source, dens_score_teacher, dens_snap, dens_last_stim, dens_last_teacher;
    logic [3:0] dens_phase;
    logic [6:0] dens_last_changed;
    logic [7:0] active_snapshot;
    logic [3:0] active_phase;

    // SW10 = cyclic M8-HW-01. SW12 = M8-HW-03 dense. Default both 0 = M8-HW-02 remap.
    assign cyclic_mode = sw_sync[10];
    // SW14 or A5 62 arms temporal. Temporal wins over dense.
    assign temporal_sel = (sw_sync[14] || temporal_valid) && !sw_sync[10];
    assign dense_sel = (sw_sync[12] || dense_valid) && !sw_sync[10] && !temporal_sel;

    basys3_clock_gen clock_i (.clk100(clk), .rst(btnL), .clk_core(core_clk), .locked(clk_locked));
    sync_bits #(.WIDTH(16)) sw_sync_i (.clk(core_clk), .rst_n(clk_locked), .async_in(sw), .sync_out(sw_sync));
    sync_bits #(.WIDTH(1)) rst_sync_i (.clk(core_clk), .rst_n(clk_locked), .async_in(btnL), .sync_out(btnL_sync));
    assign core_rst_n = clk_locked && !btnL_sync;

    button_conditioner #(.COUNTER_BITS(DEBOUNCE_BITS)) bc_c (.clk(core_clk), .rst_n(core_rst_n), .button_async(btnC), .level(unused), .pulse(start_manual));
    button_conditioner #(.COUNTER_BITS(DEBOUNCE_BITS)) bc_u (.clk(core_clk), .rst_n(core_rst_n), .button_async(btnU), .level(), .pulse(btnU_pulse));
    button_conditioner #(.COUNTER_BITS(DEBOUNCE_BITS)) bc_d (.clk(core_clk), .rst_n(core_rst_n), .button_async(btnD), .level(), .pulse(clear_state_pulse));
    button_conditioner #(.COUNTER_BITS(DEBOUNCE_BITS)) bc_r (.clk(core_clk), .rst_n(core_rst_n), .button_async(btnR), .level(), .pulse(telemetry_manual));

    uart_rx uart_rx_i (
        .clk(core_clk), .rst_n(core_rst_n), .rx(RsRx),
        .data(rx_data), .valid(rx_valid)
    );
    host_link8 host_i (
        .clk(core_clk), .rst_n(core_rst_n),
        .rx_valid(rx_valid), .rx_data(rx_data),
        .session_valid(session_valid), .session_load_pulse(session_load_pulse),
        .session_seed(session_seed), .perm_packed(perm_packed),
        .cmd_start(cmd_start), .cmd_reset(cmd_reset), .cmd_dump(cmd_dump),
        .cmd_dense_train(cmd_dense_train), .cmd_freeze_infer(cmd_freeze_infer),
        .dense_valid(dense_valid), .dense_load_pulse(dense_load_pulse),
        .dense_stim(dense_stim), .dense_teacher(dense_teacher), .dense_lr(dense_lr),
        .temporal_valid(temporal_valid), .temporal_load_pulse(temporal_load_pulse),
        .sym_a(sym_a), .sym_b(sym_b), .sym_c(sym_c), .target_x(target_x),
        .cmd_t_reset(cmd_t_reset), .cmd_t_train(cmd_t_train),
        .probe_cmd(probe_cmd), .probe_n(probe_n),
        .probe_s0(probe_s0), .probe_s1(probe_s1), .probe_s2(probe_s2)
    );

    assign start_cmd = cyclic_mode ? btnU_pulse : cmd_start;

    eval_supervisor8 #(
        .EVAL_TICKS(EVAL_TICKS),
        .TRAIN_TICKS_REMAP(TRAIN_TICKS_REMAP),
        .TRAIN_TICKS_CYCLIC(TRAIN_TICKS_CYCLIC)
    ) supervisor_i (
        .clk(core_clk), .rst_n(core_rst_n), .enable(sw_sync[11] && !dense_sel && !temporal_sel),
        .cyclic_mode(cyclic_mode), .session_valid(session_valid),
        .start_cmd(start_cmd),
        .reset_cmd((!cyclic_mode) && (cmd_reset || btnU_pulse)),
        .core_done(done),
        .source_spikes(auto_source), .score_teacher(score_teacher),
        .output_spikes(output_spikes), .sw_freeze(sw_sync[9]),
        .uart_idle(!telemetry_busy && !dump_busy),
        .dump_done(dump_done),
        .trainer_enable(trainer_enable), .learn_enable(sup_learn),
        .freeze_weights(sup_freeze), .clear_pulse(sup_clear),
        .reset_weights(sup_reset_w), .dump_start(dump_start),
        .snapshot_id(snapshot_id), .phase(sup_phase),
        .before_hits(before_hits), .after_hits(after_hits),
        .forget_hits(forget_hits),
        .before_mismatch(before_mismatch), .after_mismatch(after_mismatch),
        .before_acc(before_acc), .after_acc(after_acc),
        .route_pass(route_pass), .freeze_pass(freeze_pass),
        .final_pass(final_pass), .result_strobe(result_strobe)
    );

    dense_supervisor8 dense_sup_i (
        .clk(core_clk), .rst_n(core_rst_n), .enable(sw_sync[11] && dense_sel && !temporal_sel),
        .sample_valid(dense_valid), .stim(dense_stim), .teacher(dense_teacher),
        .train_cmd(cmd_dense_train), .freeze_infer_cmd(cmd_freeze_infer),
        .reset_cmd(cmd_reset || btnU_pulse),
        .core_busy(busy), .core_done(done),
        .changed_from_core(changed_cell_count),
        .source_spikes(dens_source), .score_teacher(dens_score_teacher),
        .start_pulse(dens_start), .learn_enable(dens_learn),
        .freeze_weights(dens_freeze), .clear_pulse(dens_clear),
        .reset_weights(dens_reset_w), .event_strobe(dens_event),
        .snapshot_id(dens_snap), .phase(dens_phase),
        .last_changed(dens_last_changed),
        .last_stim(dens_last_stim), .last_teacher(dens_last_teacher)
    );

    temporal_supervisor8 temp_sup_i (
        .clk(core_clk), .rst_n(core_rst_n), .enable(sw_sync[11] && temporal_sel),
        .sample_valid(temporal_valid),
        .sym_a(sym_a), .sym_b(sym_b), .sym_c(sym_c), .target(target_x),
        .train_cmd(cmd_t_train), .reset_cmd(cmd_t_reset || cmd_reset),
        .probe_cmd(probe_cmd), .probe_n(probe_n),
        .probe_s0(probe_s0), .probe_s1(probe_s1), .probe_s2(probe_s2),
        .clear_ctx(t_clear), .reset_weights(t_reset_w),
        .step(t_step), .learn(t_learn), .stim(t_stim), .teacher(t_teacher),
        .event_strobe(t_event), .phase(t_phase), .snapshot_id(t_snap)
    );

    temporal_context8 temp_core_i (
        .clk(core_clk), .rst_n(core_rst_n),
        .clear_ctx(t_clear), .reset_weights(t_reset_w),
        .step(t_step), .learn(t_learn),
        .stim(t_stim), .teacher(t_teacher),
        .ctx(t_ctx), .out_spikes(t_out), .weights_packed(t_weights)
    );

    auto_trainer8 #(.INTERVAL_CYCLES(AUTO_INTERVAL_CYCLES)) trainer_i (
        .clk(core_clk), .rst_n(core_rst_n), .enable(trainer_enable),
        .cyclic_mode(cyclic_mode), .perm_packed(perm_packed),
        .core_busy(busy), .core_done(done), .start_pulse(auto_start),
        .source_spikes(auto_source), .score_teacher(score_teacher),
        .phase(auto_phase), .epochs(auto_epochs)
    );

    // Teacher isolation: core never sees teacher bits outside TRAIN.
    always_comb begin
        if (temporal_sel) begin
            effective_source = t_stim;
            core_teacher = 8'h00;
            effective_start = 1'b0;
            effective_learn = 1'b0;
            effective_freeze = 1'b1;
            active_snapshot = t_snap;
            active_phase = t_phase;
        end else if (dense_sel) begin
            effective_source = dens_source;
            core_teacher = (dens_learn && !dens_freeze) ? dens_score_teacher : 8'h00;
            effective_start = dens_start;
            effective_learn = dens_learn;
            effective_freeze = dens_freeze;
            active_snapshot = dens_snap;
            active_phase = dens_phase;
        end else begin
            effective_source = sw_sync[11] ? auto_source : sw_sync[7:0];
            core_teacher = (sw_sync[11] && sup_learn && !sup_freeze) ? score_teacher : 8'h00;
            effective_start = sw_sync[11] ? auto_start : start_manual;
            effective_learn = sw_sync[11] ? sup_learn : sw_sync[8];
            effective_freeze = sw_sync[11] ? sup_freeze : sw_sync[9];
            active_snapshot = snapshot_id;
            active_phase = sup_phase;
        end
    end

    eight_agent_snn_core core_i (
        .clk(core_clk), .rst_n(core_rst_n), .start(effective_start),
        .clear_state(clear_state_pulse | sup_clear | dens_clear),
        .reset_weights(btnU_pulse | sup_reset_w | dens_reset_w),
        .learn_enable(effective_learn), .supervised_mode(1'b1),
        .freeze_weights(effective_freeze), .dense_mode(dense_sel),
        .direct_spikes(effective_source), .teacher_spikes(core_teacher),
        .threshold(16'sd512), .leak_shift(4'd3),
        .cfg_dst(sw_sync[15:13]), .cfg_src(sw_sync[8:6]),
        .cfg_rdata(selected_weight),
        .busy(busy), .done(done),
        .encoded_spikes(encoded_spikes), .output_spikes(output_spikes),
        .update_applied(update_applied),
        .tick_count(tick_count), .update_count(update_count),
        .mismatch_count(mismatch_count),
        .weights_packed(weights_packed),
        .changed_cell_count(changed_cell_count)
    );

    pulse_stretcher #(.CYCLES(STRETCH_CYCLES)) stretch_done (
        .clk(core_clk), .rst_n(core_rst_n), .pulse_in(done), .level_out(done_visible));
    pulse_stretcher #(.CYCLES(STRETCH_CYCLES)) stretch_update (
        .clk(core_clk), .rst_n(core_rst_n), .pulse_in(update_applied), .level_out(update_visible));

    sevenseg_hex4 display_i (
        .clk(core_clk), .rst_n(core_rst_n),
        .value(temporal_sel ? {8'd0, t_ctx} : (dense_sel ? {9'd0, changed_cell_count} : selected_weight)),
        .seg(seg), .dp(dp), .an(an)
    );

    always_ff @(posedge core_clk) begin
        if (!core_rst_n) session_echo_hold <= 1'b0;
        else if (session_load_pulse) session_echo_hold <= 1'b1;
        else if (!telemetry_busy && !dump_busy) session_echo_hold <= 1'b0;
    end

    assign telemetry_flags = {clk_locked, sw_sync[11], effective_learn, effective_freeze,
                              update_applied, done, busy, session_valid};
    telemetry_packet_tx telemetry_i (
        .clk(core_clk), .rst_n(core_rst_n),
        .trigger(done | telemetry_manual),
        .tick_count(tick_count), .update_count(update_count),
        .mismatch_count(mismatch_count), .selected_weight(selected_weight),
        .encoded_spikes(encoded_spikes),
        .output_spikes(temporal_sel ? t_out : output_spikes),
        .flags(telemetry_flags), .sup_phase(active_phase),
        .result_trigger(result_strobe && !dense_sel && !temporal_sel),
        .before_mismatch(before_mismatch), .after_mismatch(after_mismatch),
        .before_acc(before_acc), .after_acc(after_acc),
        .route_pass(route_pass), .freeze_pass(freeze_pass), .final_pass(final_pass),
        .dump_start(dump_start | cmd_dump), .snapshot_id(active_snapshot),
        .weights_packed(temporal_sel ? t_weights : weights_packed),
        .session_echo(session_echo_hold && !dense_sel && !temporal_sel),
        .session_seed(session_seed), .perm_packed(perm_packed),
        .dense_event(dens_event && !temporal_sel),
        .dense_stim(dens_last_stim), .dense_teacher(dens_last_teacher),
        .changed_cell_count(dens_last_changed),
        .dense_learn(dens_learn), .dense_freeze(dens_freeze),
        .temp_event(t_event), .temp_ctx(t_ctx), .temp_out(t_out),
        .temp_target(target_x),
        .tx(RsTx), .packet_busy(telemetry_busy),
        .dump_busy(dump_busy), .dump_done(dump_done)
    );

    always_comb begin
        led = '0;
        led[7:0] = temporal_sel ? t_out : output_spikes;
        led[8] = temporal_sel ? temporal_valid : (dense_sel ? dense_valid : session_valid);
        led[9] = telemetry_busy | dump_busy;
        led[10] = done_visible;
        led[11] = update_visible;
        led[12] = effective_freeze;
        led[13] = effective_learn;
        led[14] = sw_sync[11];
        led[15] = clk_locked;
    end

`ifndef SYNTHESIS
    always @(posedge core_clk) if (core_rst_n) begin
        if (!(effective_learn && !effective_freeze) && (core_teacher != 8'h00))
            $error("teacher isolation violated: core_teacher=%02h phase=%0d", core_teacher, active_phase);
        if (dense_sel && dens_event && (dens_last_changed != 7'd64) && (dens_last_changed != 7'd0))
            $error("dense changed_cell_count illegal %0d", dens_last_changed);
    end
`endif
endmodule

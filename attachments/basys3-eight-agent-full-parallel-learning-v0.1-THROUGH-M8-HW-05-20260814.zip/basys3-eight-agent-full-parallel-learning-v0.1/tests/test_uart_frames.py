from python.session_permutation import permutation
from python.uart_frames import (
    command_frame,
    dense_sample_frame,
    parse_frame,
    phrase_probe_frame,
    phrase_sample_frame,
    session_frame,
    xor14,
)


def test_session_roundtrip():
    perm = permutation(2026081401)
    frame = session_frame(2026081401, perm)
    assert len(frame) == 15
    assert xor14(frame) == frame[14]
    rec = parse_frame(frame)
    assert rec["ok"]
    assert rec["kind"] == 0x5E
    assert rec["seed"] == 2026081401
    assert rec["perm"] == list(perm)


def test_command_checksum():
    frame = command_frame(1)
    assert parse_frame(frame)["ok"]
    assert frame[1] == 0x5F
    assert frame[2] == 1


def test_dense_sample_frame():
    frame = dense_sample_frame(0xB4, 0x6B, 8)
    rec = parse_frame(frame)
    assert rec["ok"]
    assert rec["kind"] == 0x60
    assert rec["stim"] == 0xB4
    assert rec["teacher"] == 0x6B
    assert rec["lr"] == 8


def test_phrase_frames_are_temporal_host_bytes():
    sample = phrase_sample_frame((80, 90, 238), 0x88)
    rec = parse_frame(sample)
    assert rec["ok"]
    assert rec["kind"] == 0x62
    assert rec["a"] == 80 and rec["b"] == 90 and rec["c"] == 238
    assert rec["x"] == 0x88
    probe = parse_frame(phrase_probe_frame((141, 34, 204)))
    assert probe["ok"]
    assert probe["kind"] == 0x63
    assert probe["n"] == 3
    assert probe["s0"] == 141 and probe["s1"] == 34 and probe["s2"] == 204

set script_dir [file normalize [file dirname [info script]]]
set root_dir [file normalize [file join $script_dir ..]]
set build_dir [file join $root_dir build vivado]
set out_dir [file join $root_dir build out]
file mkdir $build_dir
file mkdir $out_dir

set part_name xc7a35tcpg236-1
if {[llength [get_parts -quiet $part_name]] == 0} {
    puts stderr "ERROR: Vivado installation does not contain $part_name."
    exit 2
}

create_project -force basys3_eight_agent $build_dir -part $part_name
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]

set rtl_files [list \
    [file join $root_dir rtl core snn_math_pkg.sv] \
    [file join $root_dir rtl core pulse_density_encoder.sv] \
    [file join $root_dir rtl core lif_agent.sv] \
    [file join $root_dir rtl core attention_gate8.sv] \
    [file join $root_dir rtl core stdp_matrix8.sv] \
    [file join $root_dir rtl core eight_agent_snn_core.sv] \
    [file join $root_dir rtl core temporal_context8.sv] \
    [file join $root_dir rtl board basys3_clock_gen.sv] \
    [file join $root_dir rtl board sync_bits.sv] \
    [file join $root_dir rtl board button_conditioner.sv] \
    [file join $root_dir rtl board pulse_stretcher.sv] \
    [file join $root_dir rtl board session_map8.sv] \
    [file join $root_dir rtl board auto_trainer8.sv] \
    [file join $root_dir rtl board eval_supervisor8.sv] \
    [file join $root_dir rtl board dense_supervisor8.sv] \
    [file join $root_dir rtl board temporal_supervisor8.sv] \
    [file join $root_dir rtl board sevenseg_hex4.sv] \
    [file join $root_dir rtl board uart_tx.sv] \
    [file join $root_dir rtl board uart_rx.sv] \
    [file join $root_dir rtl board host_link8.sv] \
    [file join $root_dir rtl board telemetry_packet_tx.sv] \
    [file join $root_dir rtl board basys3_eight_agent_top.sv]]

add_files -norecurse $rtl_files
add_files -fileset constrs_1 -norecurse [file join $root_dir constraints basys3_eight_agent.xdc]
set_property top basys3_eight_agent_top [current_fileset]
update_compile_order -fileset sources_1

puts "=== SYNTHESIS ==="
synth_design -top basys3_eight_agent_top -part $part_name -flatten_hierarchy rebuilt
write_checkpoint -force [file join $out_dir post_synth.dcp]
report_utilization -hierarchical -file [file join $out_dir utilization_synth.rpt]
report_timing_summary -delay_type max -max_paths 20 -file [file join $out_dir timing_synth.rpt]

puts "=== IMPLEMENTATION ==="
opt_design
place_design
phys_opt_design
write_checkpoint -force [file join $out_dir post_place.dcp]
route_design
phys_opt_design
write_checkpoint -force [file join $out_dir post_route.dcp]
report_timing_summary -delay_type min_max -max_paths 100 -file [file join $out_dir timing_route.rpt]
report_utilization -hierarchical -file [file join $out_dir utilization_route.rpt]
report_power -file [file join $out_dir power_route.rpt]
report_drc -file [file join $out_dir drc_route.rpt]
report_methodology -file [file join $out_dir methodology_route.rpt]
report_design_analysis -congestion -file [file join $out_dir congestion_route.rpt]

set max_path [get_timing_paths -quiet -delay_type max -max_paths 1]
set wns [get_property SLACK [lindex $max_path 0]]
puts "POST_ROUTE_WNS=$wns"
set drc_count [llength [get_drc_violations -quiet]]
puts "POST_ROUTE_DRC_COUNT=$drc_count"
set frozen_m8hw02 [file join $out_dir basys3_eight_agent_m8hw02.bit]
set frozen_m8hw03 [file join $out_dir basys3_eight_agent_m8hw03.bit]
if {![file exists $frozen_m8hw02] || ![file exists $frozen_m8hw03]} {
    puts stderr "ERROR: frozen M8-HW-02/03 bitstream missing; refuse to build."
    exit 5
}
write_bitstream -force [file join $out_dir basys3_eight_agent_m8hw04.bit]
if {$wns < 0.0} {
    puts stderr "ERROR: timing is not closed; WNS=$wns"
    exit 4
}
puts "BASYS3_BUILD_PASS bitstream=[file join $out_dir basys3_eight_agent_m8hw04.bit] WNS=$wns"
# DSP pipeline DRC warnings do not fail the bit (same as 4-agent board).
